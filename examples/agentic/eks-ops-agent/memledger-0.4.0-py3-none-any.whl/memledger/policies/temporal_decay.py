"""Temporal decay policy — demote stale memories over time."""

from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Any
import logging

logger = logging.getLogger(__name__)


@dataclass
class TemporalDecayPolicy:
    """Policy for time-based confidence decay."""
    decay_rate_per_day: float = 0.01      # Confidence drops by this per day without access
    staleness_ttl_days: int = 90          # Memories older than this are considered stale
    archive_threshold: float = 0.1        # Below this confidence -> archive
    refresh_on_access: bool = True        # Accessing a memory resets its decay timer

    def compute_decay(
        self,
        original_confidence: float,
        created_at: datetime | None,
        last_accessed_at: datetime | None = None,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        """Compute the decayed confidence for a memory.

        Returns:
            {
                "original_confidence": float,
                "decayed_confidence": float,
                "days_since_access": int,
                "is_stale": bool,
                "should_archive": bool,
                "decay_amount": float,
            }
        """
        if now is None:
            now = datetime.now(timezone.utc)

        # Use last_accessed_at if available, else created_at
        reference_time = last_accessed_at or created_at
        if reference_time is None:
            reference_time = now

        # Ensure timezone-aware comparison
        if reference_time.tzinfo is None:
            reference_time = reference_time.replace(tzinfo=timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)

        days_since_access = max(0, (now - reference_time).days)
        decay_amount = min(self.decay_rate_per_day * days_since_access, original_confidence * 0.8)  # Cap at 80% decay
        decayed_confidence = max(0.0, original_confidence - decay_amount)

        is_stale = days_since_access >= self.staleness_ttl_days
        should_archive = decayed_confidence < self.archive_threshold

        return {
            "original_confidence": original_confidence,
            "decayed_confidence": round(decayed_confidence, 4),
            "days_since_access": days_since_access,
            "is_stale": is_stale,
            "should_archive": should_archive,
            "decay_amount": round(decay_amount, 4),
        }
