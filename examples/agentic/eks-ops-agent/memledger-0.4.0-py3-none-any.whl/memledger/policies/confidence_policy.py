"""Confidence-based retrieval gating.

Memories below min_threshold are filtered from results.
Memories below flag_threshold are returned but marked with a warning.
This prevents low-confidence memories from being treated as ground truth.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional
import logging

logger = logging.getLogger(__name__)


@dataclass
class ConfidencePolicy:
    """Policy for confidence-based memory retrieval gating."""

    min_threshold: float = 0.4  # Filter out below this
    flag_threshold: float = 0.6  # Flag between min and this
    include_attribution: bool = True  # Return full attribution metadata

    def evaluate(self, confidence: float) -> str:
        """Evaluate a memory's confidence against the policy.

        Returns: "PASS" | "FLAG" | "FILTER"
        """
        if confidence < self.min_threshold:
            return "FILTER"
        elif confidence < self.flag_threshold:
            return "FLAG"
        return "PASS"

    def format_signal(self, confidence: float, created_by: str = "unknown") -> str:
        """Format a confidence signal string for agent prompts.

        This string gets injected into the agent's prompt template
        so it can make informed decisions about memory trust.
        """
        status = self.evaluate(confidence)
        if status == "PASS":
            return f"High confidence ({confidence:.2f}) from {created_by}"
        elif status == "FLAG":
            return (
                f"Low confidence ({confidence:.2f}) from {created_by}"
                " -- hedge your decision"
            )
        else:
            return f"Filtered ({confidence:.2f}) -- below trust threshold"


def apply_confidence_gating(
    records: list,  # list of MemoryRecord
    policy: ConfidencePolicy,
) -> tuple[list, list, list]:
    """Apply confidence gating to a list of retrieved memories.

    Returns:
        (passed, flagged, filtered) -- three lists of records
    """
    passed = []
    flagged = []
    filtered = []

    for record in records:
        confidence = record.importance if record.importance is not None else 0.5
        status = policy.evaluate(confidence)

        if status == "PASS":
            passed.append(record)
        elif status == "FLAG":
            flagged.append(record)
        else:
            filtered.append(record)
            logger.info(
                "Confidence gating: filtered [%s] (confidence=%.2f < %.2f)",
                record.id[:8],
                confidence,
                policy.min_threshold,
            )

    return passed, flagged, filtered
