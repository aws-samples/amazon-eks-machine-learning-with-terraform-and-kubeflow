"""Conflict surfacing — detect and flag contradictory memories."""

from __future__ import annotations
import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ConflictResult:
    """Result of a conflict check."""
    has_conflict: bool = False
    existing_memory_id: str | None = None
    existing_agent: str | None = None
    similarity: float = 0.0
    action: str = "none"  # none | flag | supersede | reject
    reason: str = ""


def check_conflict(
    new_content: str,
    new_agent: str,
    existing_records: list,  # list of MemoryRecord
    similarity_threshold: float = 0.7,
) -> ConflictResult:
    """Check if new content conflicts with existing memories.

    Uses content overlap heuristics (for deterministic mode) or
    embedding similarity (when available).
    """
    for record in existing_records:
        # Simple keyword overlap check (deterministic fallback)
        new_words = set(new_content.lower().split())
        existing_words = set(record.content.lower().split())

        if not new_words or not existing_words:
            continue

        overlap = len(new_words & existing_words) / max(len(new_words | existing_words), 1)

        if overlap >= similarity_threshold:
            # Check if values differ (crude: different numbers or negation)
            has_diff = _detect_value_difference(new_content, record.content)

            if has_diff:
                return ConflictResult(
                    has_conflict=True,
                    existing_memory_id=record.id,
                    existing_agent=record.created_by,
                    similarity=overlap,
                    action="flag",
                    reason=f"Contradicts [{record.id[:8]}] by {record.created_by} (overlap: {overlap:.2f})",
                )

    return ConflictResult()


def _detect_value_difference(text_a: str, text_b: str) -> bool:
    """Crude check: do two texts contain different numeric values for the same metric?"""
    import re

    nums_a = set(re.findall(r'\b\d+\b', text_a))
    nums_b = set(re.findall(r'\b\d+\b', text_b))

    # If both have numbers and they differ, it's a potential conflict
    if nums_a and nums_b and nums_a != nums_b:
        return True

    return False


# ── F12: Position-Bias Instrumentation ─────────────────────────

@dataclass
class PositionBiasEvent:
    """Records a position-bias check on a pairwise judge call."""
    memory_a_id: str
    memory_b_id: str
    verdict_ab: str  # judge verdict with (A, B) ordering
    verdict_ba: str  # judge verdict with (B, A) ordering
    agreed: bool  # True if both orderings returned the same verdict
    judge_id: str = "conflict_resolution"


class PositionBiasTracker:
    """Tracks position-bias rate across pairwise judge calls.

    For every conflict judge call, run the judge in both orderings:
      - (memory_A, memory_B)
      - (memory_B, memory_A)
    Log when verdicts disagree. Aggregate into a running metric.

    Usage:
        tracker = PositionBiasTracker()

        # Wrap a judge function
        async def my_judge(text_a, text_b) -> str:
            return "conflict" or "no_conflict"

        verdict = await tracker.run_paired(my_judge, text_a, text_b, id_a, id_b)
        print(f"Position-bias rate: {tracker.bias_rate:.1%}")
    """

    def __init__(self):
        self._events: list[PositionBiasEvent] = []

    @property
    def total_checks(self) -> int:
        return len(self._events)

    @property
    def disagreements(self) -> int:
        return sum(1 for e in self._events if not e.agreed)

    @property
    def bias_rate(self) -> float:
        """Fraction of checks where ordering changed the verdict."""
        if not self._events:
            return 0.0
        return self.disagreements / self.total_checks

    def summary(self) -> str:
        """One-line summary for demo slides."""
        if not self._events:
            return "No judge calls recorded."
        return (
            f"Judge position-bias rate: {self.bias_rate:.1%} "
            f"across {self.total_checks} checks "
            f"({self.disagreements} disagreements)"
        )

    async def run_paired(
        self,
        judge_fn,
        text_a: str,
        text_b: str,
        id_a: str = "",
        id_b: str = "",
    ) -> str:
        """Run the judge in both orderings and log the result.

        Args:
            judge_fn: Async callable (text_a, text_b) -> verdict string
            text_a, text_b: The two texts to compare
            id_a, id_b: Memory IDs for logging

        Returns:
            The verdict from the primary (A, B) ordering.
        """
        import asyncio

        # Run both orderings
        verdict_ab, verdict_ba = await asyncio.gather(
            judge_fn(text_a, text_b),
            judge_fn(text_b, text_a),
        )

        agreed = verdict_ab == verdict_ba
        event = PositionBiasEvent(
            memory_a_id=id_a,
            memory_b_id=id_b,
            verdict_ab=str(verdict_ab),
            verdict_ba=str(verdict_ba),
            agreed=agreed,
        )
        self._events.append(event)

        if not agreed:
            logger.warning(
                "Position bias detected: (%s, %s) → %s but (%s, %s) → %s",
                id_a[:8], id_b[:8], verdict_ab, id_b[:8], id_a[:8], verdict_ba,
            )

        return verdict_ab

    def to_otel_attributes(self) -> dict[str, Any]:
        """Return attributes for OTEL span emission."""
        return {
            "memledger.judge.position_bias_rate": self.bias_rate,
            "memledger.judge.total_checks": self.total_checks,
            "memledger.judge.disagreements": self.disagreements,
        }

    def events_json(self) -> list[dict]:
        """Serialize events for logging/export."""
        return [
            {
                "memory_a": e.memory_a_id,
                "memory_b": e.memory_b_id,
                "verdict_ab": e.verdict_ab,
                "verdict_ba": e.verdict_ba,
                "agreed": e.agreed,
            }
            for e in self._events
        ]
