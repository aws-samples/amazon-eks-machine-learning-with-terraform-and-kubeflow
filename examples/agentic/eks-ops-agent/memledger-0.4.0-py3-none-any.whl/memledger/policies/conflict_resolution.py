"""Conflict surfacing — detect and flag contradictory memories."""

from __future__ import annotations
import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ConflictResult:
    """Result of a conflict check."""
    has_conflict: bool = False
    existing_memory_id: str | None = None
    existing_agent: str | None = None
    similarity: float = 0.0
    action: str = "none"  # none | flag | supersede | reject
    reason: str = ""


def check_conflict(
    new_content: str,
    new_agent: str,
    existing_records: list,  # list of MemoryRecord
    similarity_threshold: float = 0.7,
) -> ConflictResult:
    """Check if new content conflicts with existing memories.

    Uses content overlap heuristics (for deterministic mode) or
    embedding similarity (when available).
    """
    for record in existing_records:
        # Simple keyword overlap check (deterministic fallback)
        new_words = set(new_content.lower().split())
        existing_words = set(record.content.lower().split())

        if not new_words or not existing_words:
            continue

        overlap = len(new_words & existing_words) / max(len(new_words | existing_words), 1)

        if overlap >= similarity_threshold:
            # Check if values differ (crude: different numbers or negation)
            has_diff = _detect_value_difference(new_content, record.content)

            if has_diff:
                return ConflictResult(
                    has_conflict=True,
                    existing_memory_id=record.id,
                    existing_agent=record.created_by,
                    similarity=overlap,
                    action="flag",
                    reason=f"Contradicts [{record.id[:8]}] by {record.created_by} (overlap: {overlap:.2f})",
                )

    return ConflictResult()


def _detect_value_difference(text_a: str, text_b: str) -> bool:
    """Crude check: do two texts contain different numeric values for the same metric?"""
    import re

    nums_a = set(re.findall(r'\b\d+\b', text_a))
    nums_b = set(re.findall(r'\b\d+\b', text_b))

    # If both have numbers and they differ, it's a potential conflict
    if nums_a and nums_b and nums_a != nums_b:
        return True

    return False
