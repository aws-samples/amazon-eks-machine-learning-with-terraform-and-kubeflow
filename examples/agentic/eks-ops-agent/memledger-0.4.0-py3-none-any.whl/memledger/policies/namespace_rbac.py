"""Cross-Namespace RBAC — memory sharing policies.

Memories scoped to namespaces. Cross-namespace reads gated by
declarative policy. Violations logged and denied.

In production on EKS: agent identity comes from kagent ServiceAccount
via IRSA. Locally: agent_id string matching.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import fnmatch
import logging

logger = logging.getLogger(__name__)


@dataclass
class AccessRule:
    """A single access rule for a namespace."""
    agent_pattern: str  # glob pattern: "ops-agent", "research-*", "*"
    permissions: set[str] = field(default_factory=lambda: {"read"})  # read, write, admin


@dataclass
class NamespacePolicy:
    """Access policy for a namespace."""
    namespace: str  # e.g., "/sensitive/hr" or "/shared/knowledge/*"
    rules: list[AccessRule] = field(default_factory=list)
    min_confidence_for_cross_read: float = 0.0  # minimum confidence to read cross-namespace
    default_permissions: set[str] = field(default_factory=lambda: {"read"})  # default if no rule matches


@dataclass
class AccessDecision:
    """Result of an access check."""
    allowed: bool
    agent_id: str
    namespace: str
    operation: str  # read, write, admin
    matched_rule: str = ""  # which rule matched
    reason: str = ""


class NamespaceRBAC:
    """Namespace-based access control for multi-agent memory sharing.

    Usage:
        rbac = NamespaceRBAC()
        rbac.set_policy(NamespacePolicy(
            namespace="/sensitive/hr",
            rules=[
                AccessRule(agent_pattern="hr-agent", permissions={"read", "write"}),
                AccessRule(agent_pattern="*", permissions=set()),  # deny all others
            ],
        ))

        decision = rbac.check_access("ops-agent", "/sensitive/hr", "read")
        if not decision.allowed:
            # Log denial, return empty results
            pass
    """

    def __init__(self):
        self._policies: dict[str, NamespacePolicy] = {}

    def set_policy(self, policy: NamespacePolicy) -> None:
        """Set or update a namespace policy."""
        self._policies[policy.namespace] = policy
        logger.info("RBAC policy set for namespace %s (%d rules)", policy.namespace, len(policy.rules))

    def remove_policy(self, namespace: str) -> None:
        """Remove a namespace policy."""
        self._policies.pop(namespace, None)

    def get_policy(self, namespace: str) -> NamespacePolicy | None:
        """Get the policy for a namespace (exact match or wildcard)."""
        # Exact match first
        if namespace in self._policies:
            return self._policies[namespace]

        # Wildcard match — find most specific
        best_match: NamespacePolicy | None = None
        best_length = 0
        for pattern, policy in self._policies.items():
            if fnmatch.fnmatch(namespace, pattern) and len(pattern) > best_length:
                best_match = policy
                best_length = len(pattern)

        return best_match

    def check_access(
        self,
        agent_id: str,
        namespace: str,
        operation: str = "read",
    ) -> AccessDecision:
        """Check if an agent has access to a namespace for an operation.

        Returns AccessDecision with allowed=True/False and reason.
        """
        policy = self.get_policy(namespace)

        # No policy → allow with default permissions
        if policy is None:
            return AccessDecision(
                allowed=True,
                agent_id=agent_id,
                namespace=namespace,
                operation=operation,
                matched_rule="no_policy",
                reason="No policy defined for namespace — default allow",
            )

        # Check rules in order (first match wins)
        for rule in policy.rules:
            if fnmatch.fnmatch(agent_id, rule.agent_pattern):
                allowed = operation in rule.permissions
                return AccessDecision(
                    allowed=allowed,
                    agent_id=agent_id,
                    namespace=namespace,
                    operation=operation,
                    matched_rule=f"pattern={rule.agent_pattern}, perms={rule.permissions}",
                    reason=f"{'Allowed' if allowed else 'Denied'} by rule: {rule.agent_pattern}",
                )

        # No matching rule → use default permissions
        allowed = operation in policy.default_permissions
        return AccessDecision(
            allowed=allowed,
            agent_id=agent_id,
            namespace=namespace,
            operation=operation,
            matched_rule="default",
            reason=f"{'Allowed' if allowed else 'Denied'} by default policy",
        )

    def list_policies(self) -> list[dict[str, Any]]:
        """List all namespace policies."""
        return [
            {
                "namespace": p.namespace,
                "rules": [{"pattern": r.agent_pattern, "permissions": list(r.permissions)} for r in p.rules],
                "default_permissions": list(p.default_permissions),
            }
            for p in self._policies.values()
        ]
