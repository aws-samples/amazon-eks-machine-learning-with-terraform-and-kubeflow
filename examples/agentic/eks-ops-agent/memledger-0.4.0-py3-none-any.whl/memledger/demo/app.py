"""Memledger Demo Dashboard — Streamlit app that displays memory state in real time.

Run alongside `engram demo --step N` commands. The dashboard polls the
SQLite demo database and auto-refreshes to show changes as they happen.

Usage:
    engram demo --ui          # starts this app
    # or directly:
    streamlit run src/engram/demo/app.py

Requires: pip install streamlit
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import streamlit as st

# ── Page config ────────────────────────────────────────────────────

st.set_page_config(
    page_title="Memledger Demo",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ── Styling ────────────────────────────────────────────────────────

st.markdown(
    """
    <style>
    .stApp { background-color: #0f1419; }
    .memory-card {
        background: #1a1f2e;
        border: 1px solid #2d3548;
        border-radius: 10px;
        padding: 1rem;
        margin-bottom: 0.8rem;
    }
    .badge {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 10px;
        font-size: 0.8rem;
        font-weight: 600;
        margin-right: 0.3rem;
    }
    .badge-semantic { background: #1e4a3a; color: #9ece6a; border: 1px solid #9ece6a; }
    .badge-episodic { background: #3a1e4a; color: #bb9af7; border: 1px solid #bb9af7; }
    .badge-procedural { background: #4a3a1e; color: #e0af68; border: 1px solid #e0af68; }
    .badge-active { background: #1e4a3a; color: #9ece6a; border: 1px solid #9ece6a; }
    .badge-deprecated { background: #4a3a1e; color: #e0af68; border: 1px solid #e0af68; }
    .badge-promoted { background: #1e3a4a; color: #7aa2f7; border: 1px solid #7aa2f7; }
    .score-bar {
        height: 8px;
        border-radius: 4px;
        background: #232938;
    }
    .score-fill {
        height: 100%;
        border-radius: 4px;
    }
    .audit-entry {
        font-family: monospace;
        font-size: 0.85rem;
        padding: 0.3rem 0;
        border-bottom: 1px solid #2d3548;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# ── Database connection ────────────────────────────────────────────

DEMO_DB = Path.home() / ".engram" / "demo.db"
DEMO_STATE = Path.home() / ".engram" / "demo-state.json"
DEMO_DIMENSIONS = 64


class FakeEmbedder:
    def __init__(self, dimensions=DEMO_DIMENSIONS):
        self._dimensions = dimensions

    async def embed_single(self, text):
        h = hashlib.sha256(text.encode()).digest()
        return [(h[i % len(h)] / 255.0) - 0.5 for i in range(self._dimensions)]

    async def embed(self, texts):
        return [await self.embed_single(t) for t in texts]


@st.cache_resource
def get_event_loop():
    loop = asyncio.new_event_loop()
    return loop


def run_async(coro):
    loop = get_event_loop()
    return loop.run_until_complete(coro)


def get_engram():
    from memledger import Memledger
    from memledger.models import EmbeddingConfig

    async def _create():
        if not DEMO_DB.exists():
            return None
        e = await Memledger.create(
            backend_name="sqlite",
            backend_config={"path": str(DEMO_DB), "dimensions": DEMO_DIMENSIONS},
            embedding_config=EmbeddingConfig(provider="fake", model="fake", dimensions=DEMO_DIMENSIONS),
        )
        e._embedder = FakeEmbedder()
        return e

    return run_async(_create())


def load_state():
    if DEMO_STATE.exists():
        return json.loads(DEMO_STATE.read_text())
    return {}


# ── Data loading ───────────────────────────────────────────────────


def load_memories(engram):
    if engram is None:
        return []

    async def _load():
        active = await engram.get_by_status("active")
        deprecated = await engram.get_by_status("deprecated")
        return active + deprecated

    return run_async(_load())


def load_stats(engram):
    if engram is None:
        return {}
    return run_async(engram.stats())


def load_lineage(engram, record_id):
    if engram is None:
        return None
    return run_async(engram.get_lineage(record_id))


# ── Rendering ──────────────────────────────────────────────────────


def render_memory_card(rec, selected_id=None):
    is_selected = rec.id == selected_id
    border_color = "#7aa2f7" if is_selected else "#2d3548"

    type_badge = f'<span class="badge badge-{rec.record_type.value}">{rec.record_type.value}</span>'
    status_badge = f'<span class="badge badge-{rec.status.value}">{rec.status.value}</span>'

    promoted_badge = ""
    if rec.created_by == "engram:auto_promote":
        promoted_badge = '<span class="badge badge-promoted">auto-promoted</span>'

    score_html = ""
    if rec.score is not None:
        pct = max(0, min(100, rec.score * 100))
        score_html = f'<div style="margin-top:0.3rem;font-size:0.8rem;color:#8b94a8;">Score: {rec.score:.3f}</div>'

    st.markdown(
        f"""
        <div class="memory-card" style="border-color: {border_color};">
            <div style="display:flex;justify-content:space-between;align-items:center;">
                <div>
                    {type_badge} {status_badge} {promoted_badge}
                    <span style="color:#8b94a8;font-size:0.8rem;margin-left:0.5rem;">[{rec.id[:8]}]</span>
                </div>
                <div style="color:#8b94a8;font-size:0.8rem;">
                    success: {rec.success_count} | access: {rec.access_count}
                </div>
            </div>
            <div style="margin-top:0.5rem;color:#e6e9ef;font-size:0.95rem;">
                {rec.content[:200]}{'...' if len(rec.content) > 200 else ''}
            </div>
            {score_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_lineage(lineage):
    if lineage is None or "error" in lineage:
        st.info("Select a memory to view its lineage.")
        return

    rec = lineage["record"]

    st.markdown(f"**Record:** `{rec['id'][:8]}` — {rec['record_type']} | {rec['status']}")
    st.markdown(f"**Confidence:** {lineage.get('confidence', 'N/A')}")

    if lineage.get("created_by"):
        st.markdown(f"**Created by:** {lineage['created_by']}")

    chain = lineage.get("supersedes_chain", [])
    if chain:
        st.markdown("**Supersession chain:**")
        for s in chain:
            st.markdown(f"  ← `{s['id'][:8]}` {s['content'][:50]}... ({s['status']})")

    derived = lineage.get("derived_records", [])
    if derived:
        st.markdown("**Derived records:**")
        for d in derived:
            st.markdown(f"  → `{d['id'][:8]}` {d['content'][:50]}...")

    # Mermaid diagram
    mermaid_lines = ["```mermaid", "flowchart LR"]
    root_short = rec["id"][:8]
    mermaid_lines.append(f'    ROOT["{root_short}<br/>{rec["record_type"]}<br/>{rec["status"]}"]')
    mermaid_lines.append("    style ROOT stroke:#7aa2f7,color:#7aa2f7,fill:none,stroke-width:2px")

    prev = "ROOT"
    for i, s in enumerate(chain):
        node = f"S{i}"
        mermaid_lines.append(f'    {node}["{s["id"][:8]}<br/>{s["status"]}"]')
        mermaid_lines.append(f"    style {node} stroke:#e0af68,color:#e0af68,fill:none,stroke-width:1px")
        mermaid_lines.append(f"    {prev} -.->|supersedes| {node}")
        prev = node

    for i, d in enumerate(derived):
        node = f"D{i}"
        mermaid_lines.append(f'    {node}["{d["id"][:8]}<br/>derived"]')
        mermaid_lines.append(f"    style {node} stroke:#9ece6a,color:#9ece6a,fill:none,stroke-width:1px")
        mermaid_lines.append(f"    ROOT ==>|derived| {node}")

    mermaid_lines.append("```")
    st.markdown("\n".join(mermaid_lines))


# ── Main app ───────────────────────────────────────────────────────


def main():
    st.title("🧠 Memledger Demo Dashboard")
    st.markdown("*Real-time memory state — run `engram demo --step N` in your terminal*")

    engram = get_engram()

    if engram is None:
        st.warning("No demo data found. Run `engram demo --step 1` to start.")
        st.stop()

    memories = load_memories(engram)
    stats = load_stats(engram)
    state = load_state()

    # ── Stats bar ──────────────────────────────────────────────
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Memories", stats.get("total_count", 0))
    with col2:
        by_type = stats.get("by_record_type", {})
        st.metric("Semantic", by_type.get("semantic", 0))
    with col3:
        st.metric("Episodic", by_type.get("episodic", 0))
    with col4:
        st.metric("Procedural", by_type.get("procedural", 0))

    st.divider()

    # ── Main content ───────────────────────────────────────────
    left, right = st.columns([3, 2])

    with left:
        st.subheader("Memories")
        if not memories:
            st.info("No memories yet. Run `engram demo --step 1`.")
        else:
            # Track selected memory
            selected_id = st.session_state.get("selected_id")
            for rec in sorted(memories, key=lambda r: r.created_at or datetime.min, reverse=True):
                col_card, col_btn = st.columns([10, 1])
                with col_card:
                    render_memory_card(rec, selected_id)
                with col_btn:
                    if st.button("→", key=f"sel_{rec.id}", help="View lineage"):
                        st.session_state.selected_id = rec.id
                        st.rerun()

    with right:
        tab1, tab2, tab3 = st.tabs(["Lineage", "Score Details", "Audit"])

        with tab1:
            selected_id = st.session_state.get("selected_id")
            if selected_id:
                lineage = load_lineage(engram, selected_id)
                render_lineage(lineage)
            else:
                st.info("Click → on a memory to view its lineage.")

        with tab2:
            selected_id = st.session_state.get("selected_id")
            if selected_id:
                rec = run_async(engram.get(selected_id))
                if rec:
                    st.markdown(f"**Record:** `{rec.id[:8]}`")
                    st.markdown(f"**Score:** {rec.score or 'N/A'}")
                    st.markdown(f"**Success count:** {rec.success_count}")
                    st.markdown(f"**Failure count:** {rec.failure_count}")
                    st.markdown(f"**Access count:** {rec.access_count}")
                    st.markdown(f"**Importance:** {rec.importance}")

                    if rec.supersedes:
                        st.markdown(f"**Supersedes:** `{rec.supersedes[:8]}`")
                    if rec.derived_from:
                        st.markdown(f"**Derived from:** {[d[:8] for d in rec.derived_from]}")
                    if rec.created_by:
                        st.markdown(f"**Created by:** {rec.created_by}")
            else:
                st.info("Click → on a memory to view score details.")

        with tab3:
            st.markdown("**Audit Log**")
            st.markdown("*Audit entries are per-session. Run `engram demo --all` for a connected audit trail.*")
            entries = engram.audit.recent(20)
            if entries:
                for entry in reversed(entries):
                    st.markdown(
                        f'<div class="audit-entry">{entry.summary()}</div>',
                        unsafe_allow_html=True,
                    )
            else:
                st.caption("No audit entries in this session.")

    # Auto-refresh every 2 seconds
    time.sleep(2)
    st.rerun()


if __name__ == "__main__":
    main()
