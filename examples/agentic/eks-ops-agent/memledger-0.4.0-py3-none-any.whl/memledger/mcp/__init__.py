"""Memledger MCP server — exposes memory as MCP tools."""
