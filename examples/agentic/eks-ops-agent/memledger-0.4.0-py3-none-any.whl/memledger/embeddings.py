"""Embedding provider using litellm — compatible with kagent's LiteLLM usage."""

from __future__ import annotations

import logging

from memledger.models import EmbeddingConfig

logger = logging.getLogger(__name__)


class EmbeddingProvider:
    """Generates vector embeddings using litellm.

    Supported providers: OpenAI, Bedrock, Anthropic.
    """

    # litellm requires provider prefix for non-OpenAI models
    _PROVIDER_PREFIXES = {
        "bedrock": "bedrock/",
        "anthropic": "anthropic/",
    }

    def __init__(self, config: EmbeddingConfig) -> None:
        self._config = config
        self._dimensions = config.dimensions

        # Prepend litellm provider prefix if the model doesn't already have one
        model = config.model
        prefix = self._PROVIDER_PREFIXES.get(config.provider, "")
        if prefix and not model.startswith(prefix):
            model = f"{prefix}{model}"
        self._model = model

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts. Returns list of embedding vectors."""
        import litellm

        response = await litellm.aembedding(
            model=self._model,
            input=texts,
            dimensions=self._dimensions,
        )

        embeddings = [item["embedding"] for item in response.data]
        return embeddings

    async def embed_single(self, text: str) -> list[float]:
        """Embed a single text. Convenience wrapper."""
        results = await self.embed([text])
        return results[0]

    @property
    def dimensions(self) -> int:
        return self._dimensions
