"""Memory-specific OTEL span instrumentation.

Emits spans with memledger.memory.* attributes that the Memory Attribution
Integrity evaluator reads. Compatible with both CloudWatch (AgentCore) and
Phoenix (RAGAS) consumption.

Every memory operation (read/write/outcome) emits a span with:
- memledger.memory.id
- memledger.memory.type (semantic | episodic | procedural)
- memledger.memory.confidence (float 0-1)
- memledger.memory.source_agent_id
- memledger.memory.session_id
- memledger.memory.parent_ids (JSON array, up to 5)
- memledger.memory.namespace
- memledger.memory.operation (add | search | outcome | lineage)
"""

from __future__ import annotations
from contextlib import asynccontextmanager
from typing import Any, Optional
import json
import logging

logger = logging.getLogger(__name__)

_tracer = None


def _get_tracer():
    global _tracer
    if _tracer is not None:
        return _tracer
    try:
        from opentelemetry import trace
        _tracer = trace.get_tracer("memledger.memory", "1.0.0")
        return _tracer
    except ImportError:
        logger.debug("opentelemetry not installed -- memory spans disabled")
        return None


def emit_memory_span(
    operation: str,
    memory_id: str,
    memory_type: str = "semantic",
    confidence: float = 0.7,
    source_agent_id: str = "",
    session_id: str = "",
    parent_ids: list[str] | None = None,
    namespace: str = "/",
    extra_attrs: dict[str, Any] | None = None,
) -> Any:
    """Emit a single OTEL span for a memory operation.

    Returns the span (or None if OTEL is not available).
    """
    tracer = _get_tracer()
    if tracer is None:
        return None

    hedged = extra_attrs.pop("hedged", False) if extra_attrs else False
    attrs = {
        "memledger.memory.id": memory_id,
        "memledger.memory.type": memory_type,
        "memledger.memory.confidence": confidence,
        "memledger.memory.source_agent_id": source_agent_id,
        "memledger.memory.session_id": session_id or "",
        "memledger.memory.parent_ids": json.dumps(parent_ids[:5] if parent_ids else []),
        "memledger.memory.namespace": namespace,
        "memledger.memory.operation": operation,
        "memledger.memory.hedged": bool(hedged),
    }

    # OpenInference semantic conventions
    if operation in ("search", "recall"):
        attrs["openinference.span.kind"] = "RETRIEVER"
    elif operation in ("add", "ingest"):
        attrs["openinference.span.kind"] = "CHAIN"
    else:
        attrs["openinference.span.kind"] = "CHAIN"

    if extra_attrs:
        for k, v in extra_attrs.items():
            if isinstance(v, (str, int, float, bool)):
                attrs[k] = v

    span = tracer.start_span(f"memledger.memory.{operation}", attributes=attrs)
    return span


@asynccontextmanager
async def memory_span(
    operation: str,
    memory_id: str = "",
    memory_type: str = "semantic",
    confidence: float = 0.7,
    source_agent_id: str = "",
    session_id: str = "",
    parent_ids: list[str] | None = None,
    namespace: str = "/",
    extra_attrs: dict[str, Any] | None = None,
):
    """Async context manager for memory operation spans.

    Usage:
        async with memory_span("add", memory_id="abc", confidence=0.85):
            await engram.add(...)
    """
    span = emit_memory_span(
        operation=operation,
        memory_id=memory_id,
        memory_type=memory_type,
        confidence=confidence,
        source_agent_id=source_agent_id,
        session_id=session_id,
        parent_ids=parent_ids,
        namespace=namespace,
        extra_attrs=extra_attrs,
    )

    try:
        yield span
    except Exception as e:
        if span:
            span.set_attribute("error", True)
            span.set_attribute("error.message", str(e)[:200])
        raise
    finally:
        if span:
            span.end()


def setup_otel_pipeline(
    service_name: str = "memledger",
    exporter: str = "otlp",  # otlp | console | none
    endpoint: str | None = None,
    dual_export: bool = False,  # Export to both CloudWatch and Phoenix
    phoenix_endpoint: str = "http://localhost:6006/v1/traces",
) -> bool:
    """Configure the OTEL pipeline for memory trace export.

    Args:
        service_name: Service name in traces
        exporter: Primary exporter type
        endpoint: OTLP endpoint (default from OTEL_EXPORTER_OTLP_ENDPOINT env)
        dual_export: If True, export to both primary and Phoenix
        phoenix_endpoint: Phoenix OTLP endpoint (only if dual_export=True)

    Returns True if setup succeeded.
    """
    try:
        import os
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter

        resource = Resource.create({"service.name": service_name})
        provider = TracerProvider(resource=resource)

        if exporter == "otlp":
            from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
            ep = endpoint or os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317")
            provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint=ep)))
            logger.info("OTEL: exporting to %s", ep)

            if dual_export:
                # Also export to Phoenix
                try:
                    phoenix_exporter = OTLPSpanExporter(endpoint=phoenix_endpoint)
                    provider.add_span_processor(BatchSpanProcessor(phoenix_exporter))
                    logger.info("OTEL: dual export to Phoenix at %s", phoenix_endpoint)
                except Exception as e:
                    logger.warning("OTEL: Phoenix dual export failed: %s", e)

        elif exporter == "console":
            provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))

        elif exporter == "none":
            return False

        trace.set_tracer_provider(provider)

        # Reset cached tracer so it picks up the new provider
        global _tracer
        _tracer = None

        # Try to install LangGraph instrumentation
        try:
            from openinference.instrumentation.langgraph import LangGraphInstrumentor
            LangGraphInstrumentor().instrument()
            logger.info("OTEL: LangGraph instrumentation enabled")
        except ImportError:
            logger.debug("OTEL: openinference-instrumentation-langgraph not installed")

        return True

    except ImportError:
        logger.warning("OTEL setup failed -- opentelemetry SDK not installed")
        return False
    except Exception as e:
        logger.warning("OTEL setup failed: %s", e)
        return False
