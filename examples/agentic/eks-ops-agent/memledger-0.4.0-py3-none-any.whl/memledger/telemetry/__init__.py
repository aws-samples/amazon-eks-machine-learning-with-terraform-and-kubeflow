"""Memledger telemetry — OTEL instrumentation, memory spans, and export pipeline."""

from memledger.telemetry.instrument import instrument_engram, setup_engram_telemetry

__all__ = [
    "instrument_engram",
    "setup_engram_telemetry",
]
