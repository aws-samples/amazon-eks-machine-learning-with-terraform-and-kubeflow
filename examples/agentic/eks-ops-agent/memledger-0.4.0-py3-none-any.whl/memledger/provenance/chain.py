"""Chain threading — tracks how knowledge flows between agents."""

from __future__ import annotations
import json
import logging
from typing import TYPE_CHECKING, Any, Optional
from datetime import datetime, timezone

from memledger.provenance.models import AttributionChain, ChainHop

if TYPE_CHECKING:
    from memledger.memledger import Memledger

logger = logging.getLogger(__name__)

MAX_ACTIVE_CHAIN_HOPS = 5
MAX_COLD_CHAIN_HOPS = 100  # Unlimited in cold storage


async def build_chain(
    engram: "Memledger",
    memory_id: str,
    direction: str = "upstream",
    max_hops: int = MAX_ACTIVE_CHAIN_HOPS,
) -> AttributionChain:
    """Build the attribution chain for a memory.

    Walks parent_memories (upstream) or derived_from references (downstream)
    to construct the full provenance graph.

    Args:
        memledger: Memledger instance for memory lookups
        memory_id: Starting memory
        direction: "upstream" walks parents, "downstream" walks children
        max_hops: Maximum chain depth (default 5 for active, 100 for cold storage)

    Returns:
        AttributionChain with hops, depth, min confidence, agents involved
    """
    visited: set[str] = set()
    chain_hops: list[ChainHop] = []
    agents: set[str] = set()
    min_conf = 1.0
    truncated = False

    async def _walk_upstream(current_id: str, hop: int) -> None:
        nonlocal min_conf, truncated

        if current_id in visited or hop > max_hops:
            if hop > max_hops:
                truncated = True
            return
        visited.add(current_id)

        record = await engram.get(current_id)
        if not record:
            return

        conf = record.confidence if record.confidence is not None else 0.5
        agent = record.created_by or "unknown"

        chain_hops.append(ChainHop(
            memory_id=current_id,
            agent_id=agent,
            confidence=conf,
            timestamp=record.created_at.isoformat() if record.created_at else "",
            hop_number=hop,
            action="derived" if hop > 0 else "origin",
        ))

        agents.add(agent)
        min_conf = min(min_conf, conf)

        # Walk parents
        parent_ids = record.derived_from or []
        for parent_id in parent_ids:
            await _walk_upstream(parent_id, hop + 1)

    async def _walk_downstream(current_id: str, hop: int) -> None:
        nonlocal min_conf, truncated

        if current_id in visited or hop > max_hops:
            if hop > max_hops:
                truncated = True
            return
        visited.add(current_id)

        record = await engram.get(current_id)
        if not record:
            return

        conf = record.confidence if record.confidence is not None else 0.5
        agent = record.created_by or "unknown"

        chain_hops.append(ChainHop(
            memory_id=current_id,
            agent_id=agent,
            confidence=conf,
            timestamp=record.created_at.isoformat() if record.created_at else "",
            hop_number=hop,
            action="derived",
        ))

        agents.add(agent)
        min_conf = min(min_conf, conf)

        # Walk children (find memories where derived_from contains current_id)
        downstream = await engram.get_downstream(current_id, max_depth=1)
        for child in downstream:
            await _walk_downstream(child.id, hop + 1)

    # Build the chain
    if direction == "upstream":
        await _walk_upstream(memory_id, 0)
    elif direction == "downstream":
        await _walk_downstream(memory_id, 0)
    elif direction == "both":
        await _walk_upstream(memory_id, 0)
        # Reset visited for downstream but keep the upstream hops
        downstream_visited = visited.copy()
        await _walk_downstream(memory_id, 0)

    # Sort by hop number
    chain_hops.sort(key=lambda h: h.hop_number)

    # Generate cold storage JSON (full chain, no truncation)
    cold_storage = json.dumps([h.model_dump() for h in chain_hops])

    return AttributionChain(
        root_memory_id=memory_id,
        chain=chain_hops[:MAX_ACTIVE_CHAIN_HOPS],  # Truncate active chain
        chain_depth=len(chain_hops),
        min_confidence=min_conf if chain_hops else 0.0,
        agents_involved=sorted(agents),
        truncated=truncated,
        full_chain_json=cold_storage,
    )


def propagate_attribution(
    parent_attribution: dict[str, Any],
    child_agent_id: str,
    child_confidence: float,
) -> dict[str, Any]:
    """Propagate attribution from a parent memory to a child.

    When Agent B reads Agent A's memory and derives a new one,
    the child automatically inherits the parent's attribution chain.

    Returns the attribution dict to store on the child memory.
    """
    parent_chain = parent_attribution.get("chain", [])

    # Append parent as a hop
    new_hop = {
        "memory_id": parent_attribution.get("memory_id", ""),
        "agent_id": parent_attribution.get("source_agent_id", "unknown"),
        "confidence": parent_attribution.get("confidence", 0.5),
        "hop_number": len(parent_chain),
    }

    child_chain = parent_chain + [new_hop]

    return {
        "source_agent_id": child_agent_id,
        "confidence": child_confidence,
        "chain": child_chain[:MAX_ACTIVE_CHAIN_HOPS],
        "full_chain": child_chain,  # cold storage
    }


def truncate_chain(chain: list[ChainHop], max_hops: int = MAX_ACTIVE_CHAIN_HOPS) -> list[ChainHop]:
    """Truncate a chain to max_hops, keeping the most recent hops."""
    if len(chain) <= max_hops:
        return chain
    return chain[-max_hops:]
