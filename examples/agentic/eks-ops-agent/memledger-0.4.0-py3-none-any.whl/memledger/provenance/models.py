"""Pydantic models for memory attribution and provenance chains."""

from __future__ import annotations
from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel, Field
import uuid


class AttributionRecord(BaseModel):
    """Attribution metadata attached to every memory write."""
    source_agent_id: str                    # Who created this memory
    confidence: float = 0.7                 # 0.0-1.0 confidence at write time
    session_id: Optional[str] = None        # Which agent session produced this
    turn_context: Optional[str] = None      # Which turn/step in the session
    source: Optional[str] = None            # Where the knowledge came from (docs, API, inference)
    parent_memory_ids: list[str] = Field(default_factory=list)  # What this was derived from
    timestamp: datetime = Field(default_factory=lambda: datetime.now())

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_agent_id": self.source_agent_id,
            "confidence": self.confidence,
            "session_id": self.session_id,
            "turn_context": self.turn_context,
            "source": self.source,
            "parent_memory_ids": self.parent_memory_ids,
            "timestamp": self.timestamp.isoformat(),
        }


class ChainHop(BaseModel):
    """One hop in an attribution chain."""
    memory_id: str
    agent_id: str
    confidence: float
    timestamp: str
    hop_number: int
    action: str = "derived"  # derived | superseded | promoted | read


class AttributionChain(BaseModel):
    """Full attribution chain for a memory, showing its provenance lineage."""
    root_memory_id: str
    chain: list[ChainHop] = Field(default_factory=list)
    chain_depth: int = 0
    min_confidence: float = 1.0
    agents_involved: list[str] = Field(default_factory=list)
    truncated: bool = False  # True if chain exceeds max_hops and was truncated
    full_chain_json: Optional[str] = None  # Complete chain in cold storage (JSONB)


class ProvenanceQuery(BaseModel):
    """Query parameters for provenance lookups."""
    memory_id: str
    direction: str = "upstream"  # upstream (parents) | downstream (children) | both
    max_hops: int = 5
    include_cold_storage: bool = False
