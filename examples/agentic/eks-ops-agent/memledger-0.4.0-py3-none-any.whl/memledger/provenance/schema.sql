-- Attribution schema additions for engram trust layer
-- Run against Aurora PostgreSQL with pgvector extension

-- Add attribution columns to agent_memory table
ALTER TABLE agent_memory ADD COLUMN IF NOT EXISTS session_id TEXT;
ALTER TABLE agent_memory ADD COLUMN IF NOT EXISTS turn_context TEXT;
ALTER TABLE agent_memory ADD COLUMN IF NOT EXISTS source TEXT;
ALTER TABLE agent_memory ADD COLUMN IF NOT EXISTS confidence REAL DEFAULT 0.7;
ALTER TABLE agent_memory ADD COLUMN IF NOT EXISTS attribution_chain JSONB DEFAULT '[]'::jsonb;

-- Index for chain queries
CREATE INDEX IF NOT EXISTS idx_agent_memory_created_by ON agent_memory(created_by);
CREATE INDEX IF NOT EXISTS idx_agent_memory_session_id ON agent_memory(session_id);
CREATE INDEX IF NOT EXISTS idx_agent_memory_confidence ON agent_memory(confidence);

-- GIN index for JSONB attribution chain queries
CREATE INDEX IF NOT EXISTS idx_agent_memory_attribution_chain ON agent_memory USING GIN(attribution_chain);

-- Audit log table for access tracking and policy violations
CREATE TABLE IF NOT EXISTS memory_audit_log (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    operation TEXT NOT NULL,  -- read, write, denied, conflict, cascade
    memory_id TEXT,
    agent_id TEXT,
    namespace TEXT,
    details JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp ON memory_audit_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_log_agent ON memory_audit_log(agent_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_operation ON memory_audit_log(operation);
