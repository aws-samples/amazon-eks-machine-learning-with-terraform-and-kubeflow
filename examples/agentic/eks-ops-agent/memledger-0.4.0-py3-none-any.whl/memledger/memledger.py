"""Memledger — the main entry point.

Usage:
    engram = await Memledger.from_config("engram.yaml")
    await engram.add("User prefers Python", namespace="/users/u1/prefs")
    results = await engram.search("programming language preference", namespace="/users/u1")
"""

from __future__ import annotations

import logging
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import yaml

from memledger.backends.base import BackendProvider
from memledger.embeddings import EmbeddingProvider
from memledger.models import (
    BackendConfig,
    EmbeddingConfig,
    MemledgerConfig,
    EpisodicRecord,
    MemoryRecord,
    MemoryStatus,
    ProceduralRecord,
    RecordType,
    SearchResult,
    SemanticRecord,
)
from memledger.strategies.audit import AuditLog
from memledger.strategies.scoring import ScoringConfig, compute_final_score

logger = logging.getLogger(__name__)

# Backend registry — maps provider names to classes
_BACKEND_REGISTRY: dict[str, type[BackendProvider]] = {}
_BUILTIN_BACKENDS_REGISTERED = False


def register_backend(name: str, backend_cls: type[BackendProvider]) -> None:
    """Register a custom backend provider.

    Use this to add third-party backends (S3 Vectors, Milvus, Redis, etc.)
    without modifying engram source code:

        from memledger.memledger import register_backend
        from my_package import MilvusBackend

        register_backend("milvus", MilvusBackend)
        engram = await Memledger.create(backend_name="milvus", ...)
    """
    _BACKEND_REGISTRY[name] = backend_cls


def _register_builtin_backends() -> None:
    """Lazily register built-in backends."""
    global _BUILTIN_BACKENDS_REGISTERED
    if _BUILTIN_BACKENDS_REGISTERED:
        return
    _BUILTIN_BACKENDS_REGISTERED = True

    try:
        from memledger.backends.pgvector import PgVectorBackend

        _BACKEND_REGISTRY.setdefault("pgvector", PgVectorBackend)
    except ImportError:
        pass

    try:
        from memledger.backends.opensearch import OpenSearchBackend

        _BACKEND_REGISTRY.setdefault("opensearch", OpenSearchBackend)
    except ImportError:
        pass

    try:
        from memledger.backends.sqlite import SQLiteBackend

        _BACKEND_REGISTRY.setdefault("sqlite", SQLiteBackend)
    except ImportError:
        pass

    try:
        from memledger.backends.dynamodb import DynamoDBBackend

        _BACKEND_REGISTRY.setdefault("dynamodb", DynamoDBBackend)
    except ImportError:
        pass

    try:
        from memledger.backends.composition import CompositionRouter

        _BACKEND_REGISTRY.setdefault("composition", CompositionRouter)
    except ImportError:
        pass


class LifecycleHooks:
    """Callbacks fired on memory operations.

    Register hooks to react to memory events:
        engram.hooks.on_add.append(lambda record: print(f"New: {record.id}"))
        engram.hooks.on_outcome.append(lambda record_id, success: ...)
    """

    def __init__(self) -> None:
        self.on_add: list = []
        self.on_update: list = []
        self.on_delete: list = []
        self.on_status_change: list = []
        self.on_outcome: list = []
        self.on_conflict: list = []
        self.on_promote: list = []

    async def _fire(self, hooks: list, *args: Any, **kwargs: Any) -> None:
        for hook in hooks:
            try:
                result = hook(*args, **kwargs)
                if hasattr(result, "__await__"):
                    await result
            except Exception as e:
                logger.warning("Hook error: %s", e)


class Memledger:
    """Pluggable memory layer for AI agents.

    Five methods. One class. Works with any backend.

        engram = await Memledger.from_config("engram.yaml")
        await engram.add("some fact", namespace="/agents/sre")
        results = await engram.search("relevant query")
        await engram.update(record_id, metadata={"reviewed": True})
        await engram.delete(record_id)
        await engram.close()
    """

    def __init__(
        self,
        backend: BackendProvider,
        embedder: EmbeddingProvider,
        config: MemledgerConfig,
    ) -> None:
        self._backend = backend
        self._embedder = embedder
        self._config = config
        self.audit = AuditLog()
        self.hooks = LifecycleHooks()

        # Build pluggable intelligence strategies (v0.3.1+).
        # If config.strategies is None, build_strategies returns deterministic
        # defaults that preserve v0.3.0 behavior exactly.
        from memledger.strategies import build_strategies

        self._strategies = build_strategies(config.strategies, rerank_fn=self._rerank)

    # ── Factory Methods ──────────────────────────────────────────

    @classmethod
    async def from_config(cls, config_path: str | Path) -> "Memledger":
        """Create Memledger from a YAML config file.

        Config file supports ${ENV_VAR} interpolation.
        """
        path = Path(config_path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")

        raw = path.read_text()

        # Simple env var interpolation: ${VAR_NAME} or ${VAR_NAME:default}
        def _replace_env(match: re.Match) -> str:
            var = match.group(1)
            if ":" in var:
                name, default = var.split(":", 1)
                return os.environ.get(name, default)
            return os.environ.get(var, match.group(0))

        raw = re.sub(r"\$\{([^}]+)\}", _replace_env, raw)

        data = yaml.safe_load(raw)
        engram_config = MemledgerConfig(**data)

        return await cls.create(
            backend_name=engram_config.default_backend,
            backend_config=engram_config.backends.get(
                engram_config.default_backend, BackendConfig(provider=engram_config.default_backend)
            ).config,
            embedding_config=engram_config.embeddings,
            engram_config=engram_config,
        )

    @classmethod
    async def create(
        cls,
        backend_name: str = "pgvector",
        backend_config: Optional[dict[str, Any]] = None,
        embedding_config: Optional[EmbeddingConfig] = None,
        engram_config: Optional[MemledgerConfig] = None,
        *,
        # Convenience params for quick setup
        connection_string: Optional[str] = None,
        embedding_model: str = "text-embedding-3-small",
        embedding_dimensions: int = 1024,
    ) -> "Memledger":
        """Create Memledger programmatically.

        Quick start:
            engram = await Memledger.create(
                backend_name="pgvector",
                connection_string="postgresql://user:pass@host:5432/db",
            )
        """
        _register_builtin_backends()

        if backend_name not in _BACKEND_REGISTRY:
            available = list(_BACKEND_REGISTRY.keys())
            raise ValueError(
                f"Unknown backend '{backend_name}'. "
                f"Available: {available}. "
                f"Install extras: pip install engram[{backend_name}]"
            )

        # Build config
        if backend_config is None:
            backend_config = {}
        if connection_string:
            backend_config["connection_string"] = connection_string

        if embedding_config is None:
            embedding_config = EmbeddingConfig(
                model=embedding_model,
                dimensions=embedding_dimensions,
            )

        if engram_config is None:
            engram_config = MemledgerConfig(
                embeddings=embedding_config,
                default_backend=backend_name,
            )

        # Ensure dimensions are consistent
        backend_config.setdefault("dimensions", embedding_config.dimensions)

        # Initialize backend
        if backend_name == "composition":
            # Multi-backend composition: initialize primary and search backends,
            # then pass them to the CompositionRouter
            primary_name = backend_config.get("primary", "dynamodb")
            search_name = backend_config.get("search", "opensearch")
            sync_mode = backend_config.get("sync", "inline")

            if primary_name not in _BACKEND_REGISTRY:
                raise ValueError(f"Unknown primary backend: {primary_name}")
            if search_name not in _BACKEND_REGISTRY:
                raise ValueError(f"Unknown search backend: {search_name}")

            # Get backend configs from engram_config.backends
            primary_cfg = {}
            search_cfg = {}
            if engram_config and engram_config.backends:
                if primary_name in engram_config.backends:
                    primary_cfg = engram_config.backends[primary_name].config
                if search_name in engram_config.backends:
                    search_cfg = engram_config.backends[search_name].config
            primary_cfg.setdefault("dimensions", embedding_config.dimensions)
            search_cfg.setdefault("dimensions", embedding_config.dimensions)

            # Initialize both backends
            primary_cls = _BACKEND_REGISTRY[primary_name]
            primary = primary_cls()
            await primary.initialize(primary_cfg)

            search_cls = _BACKEND_REGISTRY[search_name]
            search = search_cls()
            await search.initialize(search_cfg)

            # Initialize the composition router
            backend_cls = _BACKEND_REGISTRY["composition"]
            backend = backend_cls()
            await backend.initialize(
                {
                    "primary_backend": primary,
                    "search_backend": search,
                    "sync": sync_mode,
                }
            )

            logger.info(
                "Memledger initialized with composition: primary=%s, search=%s",
                primary_name,
                search_name,
            )
        else:
            backend_cls = _BACKEND_REGISTRY[backend_name]
            backend = backend_cls()
            await backend.initialize(backend_config)
            logger.info("Memledger initialized with backend=%s", backend_name)

        # Initialize embedder
        embedder = EmbeddingProvider(embedding_config)

        return cls(backend=backend, embedder=embedder, config=engram_config)

    # ── Public API (5 methods) ───────────────────────────────────

    async def add(
        self,
        content: str,
        *,
        record_type: RecordType = RecordType.SEMANTIC,
        namespace: str = "/",
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        importance: float = 0.5,
        metadata: Optional[dict[str, Any]] = None,
        record_id: Optional[str] = None,
        supersedes: Optional[str] = None,
        derived_from: Optional[list[str]] = None,
        created_by: Optional[str] = None,
        workflow_id: Optional[str] = None,
        triggered_by: Optional[str] = None,
        turn_context: Optional[str] = None,
        confidence: float = 0.5,
        hedged: bool = False,
        **typed_fields: Any,
    ) -> str:
        """Store a memory. Returns the record ID.

        Args:
            content: The text content to store.
            record_type: One of RecordType.SEMANTIC, EPISODIC, PROCEDURAL.
            namespace: Hierarchical path for scoping.
            agent_id: ID of the agent storing this memory.
            user_id: ID of the user this memory relates to.
            session_id: Session identifier.
            importance: 0.0-1.0 write-time hint; usage patterns override over time.
            metadata: Arbitrary key-value metadata.
            record_id: Optional explicit ID (auto-generated if omitted).
            supersedes: ID of memory this one replaces (marks old as deprecated).
            derived_from: IDs of source memories this was derived from.
            created_by: Agent or tool that created this memory (provenance).
            workflow_id: Workflow or pipeline run that produced this memory.
            triggered_by: Input or event that caused this memory to be created.
            turn_context: Which turn/step in the session produced this memory.
            **typed_fields: Extra fields for typed records.
        """
        if self._config.strict_provenance and not created_by:
            raise ValueError("created_by is required (strict_provenance=True)")

        embedding = await self._embedder.embed_single(content)

        _metadata = metadata or {}

        base_kwargs: dict[str, Any] = dict(
            content=content,
            embedding=embedding,
            namespace=namespace,
            agent_id=agent_id,
            user_id=user_id,
            session_id=session_id,
            importance=importance,
            metadata=_metadata,
            supersedes=supersedes,
            derived_from=derived_from or [],
            created_by=created_by,
            workflow_id=workflow_id,
            triggered_by=triggered_by,
            confidence=confidence,
            turn_context=turn_context,
            hedged=hedged,
        )

        # If this memory supersedes another, deprecate the old one
        if supersedes:
            await self._backend.update(supersedes, status="deprecated")

        # WritePolicyStrategy: ask the configured strategy whether to store.
        # The default (AlwaysStore) returns should_store=True, so v0.3.0
        # behavior is unchanged. LLM-driven gating opts in via config.
        # NOTE: we use a lightweight pseudo-record for the gating call to
        # avoid building the full typed record before deciding to drop it.
        from memledger.models import SemanticRecord as _PreSemantic

        _candidate = _PreSemantic(
            content=content,
            namespace=namespace,
            metadata=metadata or {},
            agent_id=agent_id,
            user_id=user_id,
            session_id=session_id,
            importance=importance,
        )
        decision = await self._strategies.write_policy.should_store(_candidate)
        if not decision.should_store:
            self.audit.log(
                "write_skipped",
                namespace=namespace,
                content=content[:60],
                reason=decision.reason,
            )
            logger.info("Write skipped by policy: %s", decision.reason)
            return ""  # caller gets empty id; existing tests pass an id back

        # ImportanceStrategy: ask the configured strategy for the write-time
        # score. The default (FixedImportance) returns the caller-provided
        # `importance` value (or 0.5 if absent), preserving v0.3.0 behavior.
        # LLM-driven importance scoring opts in via config.
        scored_importance = await self._strategies.importance.score(_candidate)
        # If a strategy returns the FixedImportance default we keep the
        # caller's explicit hint (so add(..., importance=0.9) still wins).
        # LLM strategies override.
        from memledger.strategies.policies import FixedImportance

        if not isinstance(self._strategies.importance, FixedImportance):
            base_kwargs["importance"] = scored_importance

        # Build the correct typed record
        if record_type == RecordType.EPISODIC:
            record: MemoryRecord = EpisodicRecord(
                **base_kwargs,
                event_time=typed_fields.get("event_time"),
                duration_ms=typed_fields.get("duration_ms"),
                outcome=typed_fields.get("outcome"),
                actors=typed_fields.get("actors", []),
            )
        elif record_type == RecordType.PROCEDURAL:
            record = ProceduralRecord(
                **base_kwargs,
                steps=typed_fields.get("steps", []),
                preconditions=typed_fields.get("preconditions", []),
                tools_required=typed_fields.get("tools_required", []),
            )
        else:
            record = SemanticRecord(
                **base_kwargs,
                source=typed_fields.get("source"),
            )

        if record_id:
            record.id = record_id

        # Conflict detection — check for high-similarity existing memories
        conflict = None
        try:
            existing = await self._backend.search_vector(
                embedding=embedding,
                top_k=1,
                namespace=namespace,
            )
            if existing:
                logger.info(
                    "Conflict check: nearest=%s score=%.3f content='%s'",
                    existing[0].id[:8],
                    existing[0].score or 0,
                    existing[0].content[:60],
                )
            if existing and existing[0].score and existing[0].score > self._config.conflict_threshold:
                if existing[0].id != record.id:  # not an upsert
                    conflict = {
                        "existing_id": existing[0].id,
                        "existing_content": existing[0].content[:200],
                        "similarity": round(existing[0].score, 3),
                    }
                    self.audit.log(
                        "conflict_detected",
                        record_id=record.id,
                        namespace=namespace,
                        content=content[:60],
                        existing_id=conflict["existing_id"],
                        similarity=conflict["similarity"],
                    )
                    await self.hooks._fire(self.hooks.on_conflict, record, existing[0])

                    # ConflictResolverStrategy: ask the configured strategy
                    # what to do. The default (HookOnly) returns
                    # action="store_anyway", preserving v0.3.0 behavior.
                    # LLM-driven resolvers opt in via config.
                    resolution = await self._strategies.conflict_resolver.resolve(
                        new_record=record,
                        existing_record=existing[0],
                        similarity=existing[0].score,
                    )
                    self.audit.log(
                        "conflict_resolved",
                        record_id=record.id,
                        action=resolution.action,
                        reason=resolution.reason,
                    )
                    if resolution.action == "supersede" and resolution.supersede_id:
                        await self._backend.update(resolution.supersede_id, status="deprecated")
                        record.supersedes = resolution.supersede_id
                    elif resolution.action == "merge" and resolution.merged_content:
                        record.content = resolution.merged_content
                        # Re-embed because content changed
                        record.embedding = await self._embedder.embed_single(resolution.merged_content)
                    elif resolution.action == "reject_new":
                        logger.info(
                            "Conflict resolver rejected new record: %s",
                            resolution.reason,
                        )
                        return existing[0].id  # caller gets the existing id
                    # "store_anyway" and "accept_both" both fall through
                    # and store the new record as normal.
        except Exception as e:
            logger.debug("Conflict detection skipped: %s", e)

        ids = await self._backend.add([record])
        stored_id = ids[0]

        # Audit log
        self.audit.log(
            "add",
            record_id=stored_id,
            agent_id=agent_id or created_by,
            namespace=namespace,
            content=content[:60],
            record_type=record_type.value,
            has_supersedes=bool(supersedes),
            conflict=conflict,
        )

        # Fire hooks
        await self.hooks._fire(self.hooks.on_add, record)

        return stored_id

    async def add_record(self, record: MemoryRecord) -> str:
        """Store a pre-built typed record. Returns the record ID.

        Use this when you need full control over the record object:
            record = EpisodicRecord(
                content="Pod crashed at 3am",
                event_time=datetime(2026, 3, 15),
                outcome="Restarted successfully",
            )
            record_id = await engram.add_record(record)
        """
        if record.embedding is None:
            record.embedding = await self._embedder.embed_single(record.content)

        ids = await self._backend.add([record])
        return ids[0]

    def _rerank(
        self,
        records: list[MemoryRecord],
        scoring_config: Optional[ScoringConfig] = None,
    ) -> list[MemoryRecord]:
        """Rerank search results using policy-based scoring.

        Combines the backend's similarity score with usage signals
        (success_rate, recency, frequency, importance) to produce a
        final score. Records are re-sorted by final_score descending.
        """
        if not records:
            return records

        cfg = scoring_config or ScoringConfig()

        for record in records:
            cosine = record.score if record.score is not None else 0.5
            record.score = compute_final_score(
                cosine_score=cosine,
                access_count=record.access_count,
                success_count=record.success_count,
                failure_count=record.failure_count,
                last_accessed_at=record.last_accessed_at,
                importance=record.importance,
                config=cfg,
            )

        records.sort(key=lambda r: r.score or 0, reverse=True)

        if records:
            logger.info(
                "Reranked %d records: top=%s score=%.3f (success=%d, access=%d)",
                len(records),
                records[0].id[:8],
                records[0].score or 0,
                records[0].success_count,
                records[0].access_count,
            )

        return records

    async def search(
        self,
        query: str,
        *,
        namespace: Optional[str] = None,
        top_k: int = 5,
        record_type: Optional[RecordType] = None,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
        confidence_policy: Optional[dict[str, Any]] = None,
    ) -> SearchResult:
        """Search memories by semantic similarity. Returns ranked results."""
        start = time.monotonic()

        embedding = await self._embedder.embed_single(query)

        # Build filters
        combined_filters = filters or {}
        if agent_id:
            combined_filters["agent_id"] = agent_id
        if user_id:
            combined_filters["user_id"] = user_id
        if record_type:
            combined_filters["record_type"] = record_type.value

        records = await self._backend.search_vector(
            embedding=embedding,
            top_k=top_k,
            namespace=namespace,
            filters=combined_filters if combined_filters else None,
        )

        # RerankerStrategy: default (PolicyRerank) wraps self._rerank, so
        # v0.3.0 behavior is unchanged. LLM-driven rerankers opt in via config.
        records = await self._strategies.reranker.rerank(query, records)

        # Track access for scoring + lineage
        if records and hasattr(self._backend, "record_access"):
            await self._backend.record_access(
                [r.id for r in records],
                accessed_by=agent_id,
            )

        # Cross-agent attribution: append a structured access event to each
        # returned record (in-memory only for this iteration — backend
        # persistence of the structured form is pending).
        if agent_id and records:
            timestamp = datetime.now(timezone.utc).isoformat()
            for record in records:
                access_event = {
                    "agent_id": agent_id,
                    "timestamp": timestamp,
                    "query": query[:200] if query else None,
                    "outcome": None,  # filled in later by record_outcome
                }
                record.accessed_by.append(access_event)

        elapsed = (time.monotonic() - start) * 1000

        self.audit.log(
            "search",
            namespace=namespace,
            agent_id=agent_id,
            query=query[:60],
            results=len(records),
            search_time_ms=round(elapsed, 2),
        )

        search_result = SearchResult(
            records=records,
            query=query,
            backend=self._config.default_backend,
            search_time_ms=round(elapsed, 2),
        )

        # Apply confidence gating if policy specified
        if confidence_policy:
            from memledger.policies.confidence_policy import (
                ConfidencePolicy,
                apply_confidence_gating,
            )

            policy = ConfidencePolicy(**confidence_policy)
            passed, flagged, filtered = apply_confidence_gating(
                search_result.records, policy
            )

            # Mark flagged records with metadata
            for r in flagged:
                r.metadata = dict(r.metadata or {})
                r.metadata["_confidence_flag"] = "LOW"
                r.metadata["_confidence_signal"] = policy.format_signal(
                    r.importance or 0.5, r.created_by or "unknown"
                )

            # Return passed + flagged (filtered are dropped), with gating metadata
            search_result.records = passed + flagged
            search_result.metadata = {
                **(search_result.metadata or {}),
                "confidence_gating": {
                    "passed": len(passed),
                    "flagged": len(flagged),
                    "filtered": len(filtered),
                    "policy": {
                        "min": policy.min_threshold,
                        "flag": policy.flag_threshold,
                    },
                },
            }

            # Log filtering for OTEL
            if filtered:
                logger.info(
                    "Confidence gating: %d passed, %d flagged, %d filtered",
                    len(passed),
                    len(flagged),
                    len(filtered),
                )

        return search_result

    async def search_hybrid(
        self,
        query: str,
        *,
        namespace: Optional[str] = None,
        top_k: int = 5,
        record_type: Optional[RecordType] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> SearchResult:
        """Hybrid search: vector + text combined with RRF.

        Only supported on OpenSearch backend. Falls back to vector search
        on backends that don't support hybrid.
        """
        start = time.monotonic()

        embedding = await self._embedder.embed_single(query)

        combined_filters = filters or {}
        if record_type:
            combined_filters["record_type"] = record_type.value

        # Use hybrid if backend supports it, otherwise fall back to vector search
        if hasattr(self._backend, "search_hybrid"):
            records = await self._backend.search_hybrid(
                query=query,
                embedding=embedding,
                top_k=top_k,
                namespace=namespace,
                filters=combined_filters if combined_filters else None,
            )
        else:
            records = await self._backend.search_vector(
                embedding=embedding,
                top_k=top_k,
                namespace=namespace,
                filters=combined_filters if combined_filters else None,
            )

        # RerankerStrategy: default (PolicyRerank) wraps self._rerank, so
        # v0.3.0 behavior is unchanged. LLM-driven rerankers opt in via config.
        records = await self._strategies.reranker.rerank(query, records)

        # Track access for scoring
        if records and hasattr(self._backend, "record_access"):
            await self._backend.record_access([r.id for r in records])

        elapsed = (time.monotonic() - start) * 1000

        return SearchResult(
            records=records,
            query=query,
            backend=self._config.default_backend,
            search_time_ms=round(elapsed, 2),
        )

    async def recall_context(
        self,
        query: str,
        *,
        namespace: Optional[str] = None,
        top_k: int = 5,
    ) -> Any:  # returns ContextualRecall
        """Composite retrieval: find episodes, suggest procedures, flag failures.

        Three parallel vector searches in a single call. No LLM, no complex logic.
        Returns a ContextualRecall with similar_episodes, suggested_procedures,
        and known_failures grouped by type.

        Usage:
            context = await engram.recall_context("pod OOM kills", namespace="/incidents")
            print(context.summary())
        """
        from memledger.strategies.retrieval import ContextualRecall

        start = time.monotonic()

        embedding = await self._embedder.embed_single(query)

        # Three parallel searches by record type + one for failures
        import asyncio

        episodes_task = self._backend.search_vector(
            embedding=embedding,
            top_k=top_k,
            namespace=namespace,
            filters={"record_type": RecordType.EPISODIC.value},
        )
        procedures_task = self._backend.search_vector(
            embedding=embedding,
            top_k=top_k,
            namespace=namespace,
            filters={"record_type": RecordType.PROCEDURAL.value},
        )
        failures_task = self._backend.search_vector(
            embedding=embedding,
            top_k=top_k,
            namespace=namespace,
            filters={"outcome": "failure"},
        )

        episodes, procedures, failures = await asyncio.gather(
            episodes_task,
            procedures_task,
            failures_task,
        )

        # Track access for all retrieved records
        all_ids = [r.id for r in episodes + procedures + failures]
        if all_ids and hasattr(self._backend, "record_access"):
            await self._backend.record_access(all_ids)

        elapsed = (time.monotonic() - start) * 1000

        return ContextualRecall(
            similar_episodes=episodes,
            suggested_procedures=procedures,
            known_failures=failures,
            query=query,
            search_time_ms=round(elapsed, 2),
        )

    async def _resolve_record_id(
        self,
        record_id: Optional[str],
        description: Optional[str],
        namespace: Optional[str] = None,
    ) -> Optional[str]:
        """Resolve a record ID from either an exact ID or a description.

        LLM agents are unreliable with exact UUIDs. This helper lets any
        ID-based method accept a description fallback:
        - If record_id is given and the record exists, use it.
        - If record_id is given but the record does NOT exist, fall through
          to description search (the agent may have a truncated/wrong ID).
        - If only description is given, search for the best match.
        - Returns None if nothing can be resolved.
        """
        # Try exact ID first
        if record_id:
            existing = await self._backend.get(record_id)
            if existing is not None:
                return record_id
            logger.debug("record_id=%s not found, falling back to description search", record_id)

        # Fall back to description-based search
        if description:
            results = await self.search(query=description, namespace=namespace, top_k=1)
            if results.records:
                resolved = results.records[0].id
                logger.debug("Resolved description '%s' to record %s", description[:60], resolved)
                return resolved

        return None

    async def record_outcome(
        self,
        record_id: Optional[str] = None,
        success: bool = True,
        *,
        description: Optional[str] = None,
        namespace: Optional[str] = None,
    ) -> bool:
        """Record whether a memory was helpful (success) or not (failure).

        Call this after using a memory to improve future scoring:
            await engram.record_outcome(record_id, success=True)  # by exact ID
            await engram.record_outcome(description="OOM fix", success=False)  # by description

        Args:
            record_id: Exact record ID (optional if description is provided).
            success: True if the memory was useful, False if misleading.
            description: Text description to find the memory by semantic search.
                         Used as fallback when record_id is missing or invalid.
            namespace: Optional namespace to scope the description search.
        """
        resolved = await self._resolve_record_id(record_id, description, namespace)
        if resolved is None:
            logger.warning("record_outcome: could not resolve record (id=%s, desc=%s)", record_id, description)
            return False

        if hasattr(self._backend, "record_outcome"):
            result = await self._backend.record_outcome(resolved, success)
        else:
            return False

        if not result:
            return False

        # Audit
        self.audit.log(
            "outcome",
            record_id=resolved,
            success=success,
            result="success_count updated",
        )
        await self.hooks._fire(self.hooks.on_outcome, resolved, success)

        # Auto-promotion: episodic → procedural after threshold successes
        if success:
            await self._check_auto_promote(resolved, threshold=self._config.auto_promote_threshold)

        return True

    async def _check_auto_promote(
        self,
        record_id: str,
        threshold: int = 3,
    ) -> Optional[str]:
        """Auto-promote episodic memory to procedural after threshold successes.

        When an episodic memory (incident/event) is used successfully enough
        times, it becomes proven knowledge — promote it to a procedural
        memory (runbook) automatically.

        Returns the new procedural record ID, or None if not promoted.
        """
        record = await self._backend.get(record_id)
        if record is None:
            return None

        # Only promote episodic → procedural
        if record.record_type != RecordType.EPISODIC:
            return None

        if record.success_count < threshold:
            return None

        # Check if already promoted (avoid duplicates)
        if record.metadata.get("_promoted"):
            return None

        # Create procedural record derived from this episodic
        procedural_content = f"Proven procedure (from {record.success_count} successful uses): {record.content}"
        proc_id = await self.add(
            content=procedural_content,
            record_type=RecordType.PROCEDURAL,
            namespace=record.namespace,
            agent_id=record.agent_id,
            derived_from=[record.id],
            created_by="engram:auto_promote",
            triggered_by=f"success_count reached {record.success_count}",
            importance=0.8,  # high importance — proven by usage
        )

        # Mark original as promoted (prevent duplicate promotions)
        await self._backend.update(record_id, metadata={**record.metadata, "_promoted": proc_id})

        self.audit.log(
            "promote",
            record_id=record_id,
            result=f"episodic → procedural [{proc_id[:8]}]",
            success_count=record.success_count,
        )
        await self.hooks._fire(self.hooks.on_promote, record, proc_id)

        logger.info(
            "Auto-promoted episodic [%s] → procedural [%s] (success_count=%d)",
            record_id[:8],
            proc_id[:8],
            record.success_count,
        )

        return proc_id

    async def update(
        self,
        record_id: Optional[str] = None,
        *,
        description: Optional[str] = None,
        namespace: Optional[str] = None,
        **kwargs: Any,
    ) -> bool:
        """Update a memory record. Returns True if found.

        Accepts either an exact record_id or a description for semantic lookup:
            await engram.update(record_id, metadata={"reviewed": True})
            await engram.update(description="OOM fix procedure", status="deprecated")

        Args:
            record_id: Exact record ID (optional if description is provided).
            description: Text description to find the memory by semantic search.
            namespace: Optional namespace to scope the description search.
            **kwargs: Fields to update on the matched record.
        """
        resolved = await self._resolve_record_id(record_id, description, namespace)
        if resolved is None:
            logger.warning("update: could not resolve record (id=%s, desc=%s)", record_id, description)
            return False
        result = await self._backend.update(resolved, **kwargs)
        if result:
            self.audit.log("update", record_id=resolved, **{k: str(v)[:60] for k, v in kwargs.items()})
            await self.hooks._fire(self.hooks.on_update, resolved, kwargs)
        return result

    async def delete(
        self,
        record_id: Optional[str] = None,
        *,
        description: Optional[str] = None,
        namespace: Optional[str] = None,
    ) -> bool:
        """Delete a memory record. Returns True if found.

        Accepts either an exact record_id or a description for semantic lookup:
            await engram.delete(record_id)
            await engram.delete(description="outdated OOM fix")

        Args:
            record_id: Exact record ID (optional if description is provided).
            description: Text description to find the memory by semantic search.
            namespace: Optional namespace to scope the description search.
        """
        resolved = await self._resolve_record_id(record_id, description, namespace)
        if resolved is None:
            logger.warning("delete: could not resolve record (id=%s, desc=%s)", record_id, description)
            return False
        result = await self._backend.delete(resolved)
        if result:
            self.audit.log("delete", record_id=resolved, result="archived")
            await self.hooks._fire(self.hooks.on_delete, resolved)
        return result

    async def close(self) -> None:
        """Clean up all connections."""
        await self._backend.close()
        logger.info("Memledger closed.")

    # ── Convenience Methods ──────────────────────────────────────

    async def get(
        self,
        record_id: Optional[str] = None,
        *,
        description: Optional[str] = None,
        namespace: Optional[str] = None,
    ) -> Optional[MemoryRecord]:
        """Get a single record by ID or description.

        Accepts either an exact record_id or a description for semantic lookup:
            record = await engram.get(record_id)
            record = await engram.get(description="OOM fix procedure")

        Args:
            record_id: Exact record ID (optional if description is provided).
            description: Text description to find the memory by semantic search.
            namespace: Optional namespace to scope the description search.
        """
        resolved = await self._resolve_record_id(record_id, description, namespace)
        if resolved is None:
            return None
        return await self._backend.get(resolved)

    async def health(self) -> bool:
        """Check backend connectivity."""
        return await self._backend.health_check()

    async def list_namespaces(self) -> list[str]:
        """List all distinct namespaces in memory.

        Use this to understand what knowledge domains are populated:
            namespaces = await engram.list_namespaces()
            # → ["/incidents/eks-prod", "/runbooks", "/learnings"]
        """
        return await self._backend.list_namespaces()

    async def stats(self, namespace: Optional[str] = None) -> dict[str, Any]:
        """Return memory statistics, optionally scoped to a namespace.

        Use this for meta-memory — understanding what you know before searching:
            stats = await engram.stats(namespace="/incidents")
            # → {total_count: 47, by_record_type: {episodic: 30, ...}, ...}
        """
        return await self._backend.stats(namespace)

    @property
    def backend_name(self) -> str:
        return self._config.default_backend

    # ── Batch APIs (for lifecycle and consolidation) ─────────────

    async def get_by_session(self, session_id: str) -> list[MemoryRecord]:
        """Get all memories from a specific session.

        Used by the knowledge consolidation pipeline:
            memories = await engram.get_by_session("sess-abc123")
            # → process, extract knowledge, write back to shared namespace
        """
        return await self._backend.get_by_session(session_id)

    async def get_by_timerange(
        self,
        start: Any,
        end: Any,
        namespace: Optional[str] = None,
    ) -> list[MemoryRecord]:
        """Get memories created within a time range.

        Used for scoring refresh and consolidation:
            recent = await engram.get_by_timerange(yesterday, now)
        """
        return await self._backend.get_by_timerange(start, end, namespace)

    async def get_stale(
        self,
        days: int = 30,
        min_access: int = 0,
        namespace: Optional[str] = None,
    ) -> list[MemoryRecord]:
        """Find active memories not accessed in N days.

        Used by the lifecycle management batch:
            stale = await engram.get_stale(days=30)
            await engram.bulk_update_status([m.id for m in stale], "expired")
        """
        return await self._backend.get_stale(days, min_access, namespace)

    async def get_by_status(
        self,
        status: str,
        namespace: Optional[str] = None,
    ) -> list[MemoryRecord]:
        """Get memories with a specific lifecycle status.

        Used to find expired memories past grace period for archival:
            expired = await engram.get_by_status("expired")
        """
        return await self._backend.get_by_status(status, namespace)

    async def bulk_update_status(self, record_ids: list[str], status: str) -> int:
        """Update status for multiple records. Returns count updated.

        Used for batch lifecycle transitions:
            count = await engram.bulk_update_status(ids, "expired")
        """
        return await self._backend.bulk_update_status(record_ids, status)

    async def bulk_archive(self, record_ids: list[str]) -> int:
        """Archive multiple records (soft delete). Returns count archived."""
        return await self._backend.bulk_archive(record_ids)

    # ── Lineage / Provenance ─────────────────────────────────────

    async def get_lineage(
        self,
        record_id: str,
        *,
        description: Optional[str] = None,
        namespace: Optional[str] = None,
        depth: int = 5,
    ) -> dict[str, Any]:
        """Trace the provenance chain for a memory.

        Returns the full lineage: who created it, who used it, what it
        superseded, and what was derived from it.

        Example:
            lineage = await engram.get_lineage(record_id)
            # → {
            #     "record": <MemoryRecord>,
            #     "created_by": "eks-ops-agent",
            #     "workflow_id": "session-abc123",
            #     "triggered_by": "user asked about OOM fixes",
            #     "accessed_by": ["k8s-agent", "monitoring-agent"],
            #     "supersedes_chain": [<deprecated record>, ...],
            #     "derived_records": [<records derived from this one>, ...],
            # }

        Args:
            record_id: ID of the memory to trace.
            description: Fallback description for ID resolution.
            namespace: Fallback namespace for ID resolution.
            depth: Max depth for traversing supersedes/derived chains.
        """
        resolved = await self._resolve_record_id(record_id, description, namespace)
        if resolved is None:
            return {"error": "Record not found", "record_id": record_id}

        record = await self._backend.get(resolved)
        if record is None:
            return {"error": "Record not found", "record_id": resolved}

        result: dict[str, Any] = {
            "record": {
                "id": record.id,
                "content": record.content[:200],
                "record_type": record.record_type.value,
                "status": record.status.value,
                "created_at": record.created_at.isoformat() if record.created_at else None,
            },
            "created_by": record.created_by,
            "workflow_id": record.workflow_id,
            "triggered_by": record.triggered_by,
            "accessed_by": record.accessed_by,
        }

        # Trace supersedes chain (backward — what did this replace?)
        supersedes_chain = []
        current_supersedes = record.supersedes
        for _ in range(depth):
            if not current_supersedes:
                break
            ancestor = await self._backend.get(current_supersedes)
            if ancestor is None:
                break
            supersedes_chain.append(
                {
                    "id": ancestor.id,
                    "content": ancestor.content[:200],
                    "status": ancestor.status.value,
                    "created_by": ancestor.created_by,
                }
            )
            current_supersedes = ancestor.supersedes
        result["supersedes_chain"] = supersedes_chain

        # Find derived records (forward — what was created from this?)
        # Search for records whose derived_from contains this record's ID
        derived = []
        all_active = await self._backend.get_by_status("active")
        for r in all_active:
            if record.id in (r.derived_from or []):
                derived.append(
                    {
                        "id": r.id,
                        "content": r.content[:200],
                        "created_by": r.created_by,
                    }
                )
        result["derived_records"] = derived

        # Compute current confidence
        from memledger.strategies.scoring import compute_confidence

        result["confidence"] = compute_confidence(
            created_at=record.created_at,
            last_accessed_at=record.last_accessed_at,
            success_count=record.success_count,
            failure_count=record.failure_count,
        )

        return result

    # ── Cross-agent attribution ──────────────────────────────────

    async def get_attribution(self, memory_id: str) -> dict[str, Any]:
        """Return cross-agent attribution for a memory.

        Aggregates the structured access events stored on
        MemoryRecord.accessed_by (populated by search() when an agent_id is
        supplied) into a per-agent summary: total use count, last-used
        timestamp, and the original creator.
        """
        record = await self.get(memory_id)
        if not record:
            return {"error": "memory not found"}

        # Aggregate accesses by agent. Older records may contain plain
        # agent-id strings from backend record_access; treat those as a
        # single access with no timestamp so legacy data is still counted.
        by_agent: dict[str, dict[str, Any]] = {}
        for event in record.accessed_by:
            if isinstance(event, dict):
                agent = event.get("agent_id")
                ts = event.get("timestamp")
            elif isinstance(event, str):
                agent = event
                ts = None
            else:
                continue
            if not agent:
                continue
            if agent not in by_agent:
                by_agent[agent] = {"agent_id": agent, "count": 0, "last_used": None}
            by_agent[agent]["count"] += 1
            if ts and (
                by_agent[agent]["last_used"] is None or ts > by_agent[agent]["last_used"]
            ):
                by_agent[agent]["last_used"] = ts

        return {
            "memory_id": memory_id,
            "creator": record.created_by,
            "users": sorted(by_agent.values(), key=lambda x: x["count"], reverse=True),
            "total_accesses": len(record.accessed_by),
        }

    async def get_attribution_chain(
        self,
        memory_id: str,
        direction: str = "upstream",
        max_hops: int = 5,
    ) -> dict[str, Any]:
        """Get the full attribution chain for a memory.

        Walks the provenance graph to show how knowledge flowed between agents.
        Active chain capped at 5 hops; full chain in cold storage JSONB.
        """
        from memledger.provenance.chain import build_chain
        chain = await build_chain(self, memory_id, direction=direction, max_hops=max_hops)
        return chain.model_dump()

    # ── Cascading invalidation ───────────────────────────────────

    async def get_downstream(
        self,
        memory_id: str,
        max_depth: int = 5,
    ) -> list[MemoryRecord]:
        """Find all memories that derive (transitively) from this one.

        Walks the derived_from relationship forward up to `max_depth`,
        scanning active and deprecated records per hop.
        """
        visited: set[str] = set()
        downstream: list[MemoryRecord] = []

        async def _walk(current_id: str, depth: int) -> None:
            if current_id in visited or depth > max_depth:
                return
            visited.add(current_id)

            # Find memories whose derived_from contains current_id. No backend
            # primitive for this yet — scan active + deprecated pools.
            all_active = await self.get_by_status("active")
            deprecated = await self.get_by_status("deprecated")

            for record in all_active + deprecated:
                if record.id == current_id:
                    continue
                if current_id in (record.derived_from or []):
                    # Avoid duplicating a record already collected via another path.
                    if record.id not in visited:
                        downstream.append(record)
                        await _walk(record.id, depth + 1)

        await _walk(memory_id, 0)
        return downstream

    async def plan_cascade(
        self,
        memory_id: str,
        new_memory_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Plan a cascade for a superseded memory.

        Returns suggested actions per downstream memory:
          - auto_deprecate: sole parent superseded, safe to invalidate
          - flag_for_review: multi-parent dependency, human should decide
          - no_action: no clear derived_from link (defensive)
        """
        downstream = await self.get_downstream(memory_id)

        plan: dict[str, Any] = {
            "source_memory_id": memory_id,
            "new_memory_id": new_memory_id,
            "downstream_count": len(downstream),
            "actions": [],
        }

        for record in downstream:
            parent_count = len(record.derived_from or [])
            if parent_count == 1:
                action = "auto_deprecate"
                reason = "Sole parent superseded — directly invalidated"
            elif parent_count > 1:
                action = "flag_for_review"
                reason = f"Has {parent_count} parents; manual review needed"
            else:
                action = "no_action"
                reason = "No clear dependency"

            plan["actions"].append(
                {
                    "memory_id": record.id,
                    "memory_type": record.record_type.value
                    if hasattr(record.record_type, "value")
                    else str(record.record_type),
                    "action": action,
                    "reason": reason,
                    "current_status": record.status.value
                    if hasattr(record.status, "value")
                    else str(record.status),
                }
            )

        return plan

    async def execute_cascade(self, plan: dict[str, Any]) -> dict[str, list[str]]:
        """Execute a cascade plan — deprecate or flag downstream memories.

        Returns buckets of affected record ids: deprecated, flagged, skipped.
        """
        results: dict[str, list[str]] = {
            "deprecated": [],
            "flagged": [],
            "skipped": [],
        }

        for action_spec in plan.get("actions", []):
            memory_id = action_spec["memory_id"]
            action = action_spec["action"]

            if action == "auto_deprecate":
                await self.update(memory_id, status=MemoryStatus.DEPRECATED.value)
                results["deprecated"].append(memory_id)
            elif action == "flag_for_review":
                record = await self.get(memory_id)
                if record:
                    metadata = dict(record.metadata or {})
                    metadata["needs_review"] = True
                    metadata["cascade_source"] = plan.get("source_memory_id")
                    await self.update(memory_id, metadata=metadata)
                    results["flagged"].append(memory_id)
            else:
                results["skipped"].append(memory_id)

        self.audit.log(
            "cascade_executed",
            source_memory_id=plan.get("source_memory_id"),
            deprecated=len(results["deprecated"]),
            flagged=len(results["flagged"]),
            skipped=len(results["skipped"]),
        )

        return results

    # ── PII detection for ingest safety ────────────────────────

    _PII_PATTERNS = [
        r'\b\d{3}-\d{2}-\d{4}\b',           # SSN
        r'\b\d{16}\b',                        # Credit card
        r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',  # Email
        r'(?i)\b(salary|compensation|ssn|social security)\b.*\$?\d',  # Salary/SSN mentions with numbers
        r'(?i)\bapi[_\s]?key\b.*[A-Za-z0-9]{20,}',  # API keys
    ]

    @staticmethod
    def _contains_pii(text: str) -> bool:
        for pattern in Memledger._PII_PATTERNS:
            if re.search(pattern, text):
                return True
        return False

    # ── Ingest: LLM-driven extraction (primary write API) ──────

    async def ingest(
        self,
        context: str,
        *,
        agent_id: str,
        namespace: str = "/",
        strategy: str = "llm",
        max_extractions: int = 10,
        min_confidence: float = 0.5,
        metadata: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Extract and store memories from unstructured context using LLM.

        This is the RECOMMENDED primary write API. Give engram a block of
        unstructured text (conversation history, reasoning trace, tool output),
        and the LLM decides what's worth remembering, classifies the type,
        and assigns confidence.

        For structured output where the agent already knows what to store,
        use engram.add() directly.

        Args:
            context: Unstructured text to extract memories from.
            agent_id: ID of the agent providing the context (required for provenance).
            namespace: Namespace to store extracted memories in.
            strategy: Extraction strategy — "llm" (default) or "deterministic" (fallback).
            max_extractions: Maximum number of memories to extract per call.
            min_confidence: Minimum confidence threshold for storing an extraction.
            metadata: Additional metadata to attach to all extracted memories.

        Returns:
            {
                "strategy_used": "llm" | "deterministic",
                "extractions": [
                    {"content": str, "record_type": str, "confidence": float,
                     "pattern_name": str, "memory_id": str}
                ],
                "memory_ids": [str, ...],
                "total_extracted": int,
                "total_stored": int,  # may be less than extracted if below min_confidence
            }
        """
        import asyncio
        import json as _json
        import re as _re

        logger.info("engram.ingest: extracting from %d chars of context (strategy=%s)", len(context), strategy)

        extractions: list[dict[str, Any]] = []
        strategy_used = strategy

        # ── LLM extraction ───────────────────────────────────────
        if strategy == "llm":
            try:
                import litellm

                prompt = (
                    "Extract structured memories from this conversation/context. "
                    "For each extractable piece of knowledge, classify as:\n"
                    "- semantic: a fact, preference, or piece of reference knowledge\n"
                    "- episodic: an event, experience, or incident that happened\n"
                    "- procedural: a step-by-step process, runbook, or how-to\n\n"
                    "IMPORTANT: Do NOT extract personally identifiable information (PII) including: "
                    "names, social security numbers, salary/compensation, race, gender, health data, "
                    "addresses, phone numbers, email addresses, credentials, API keys, or any data "
                    "that would violate data privacy regulations if shared across agents. "
                    "If the context contains PII, extract the knowledge WITHOUT the PII. "
                    "For example, 'Customer prefers aggressive scaling' NOT 'John Smith (SSN 123-45-6789) prefers aggressive scaling'.\n\n"
                    "Return a JSON array. Each item: "
                    '{"content": "...", "record_type": "semantic|episodic|procedural", '
                    '"confidence": 0.0-1.0, "pattern_name": "what_pattern_matched"}\n\n'
                    f"Context:\n{context[:8000]}"  # cap to avoid huge prompts
                )

                model = os.environ.get("ENGRAM_LLM_MODEL", "anthropic/claude-sonnet-4-20250514")
                response = await asyncio.wait_for(
                    litellm.acompletion(
                        model=model,
                        messages=[{"role": "user", "content": prompt}],
                        temperature=0.0,
                        response_format={"type": "json_object"},
                    ),
                    timeout=15,
                )

                raw = response.choices[0].message.content
                parsed = _json.loads(raw) if raw else []

                # Handle both bare array and {"extractions": [...]}
                if isinstance(parsed, dict) and "extractions" in parsed:
                    parsed = parsed["extractions"]
                if isinstance(parsed, list):
                    for item in parsed[:max_extractions]:
                        if isinstance(item, dict) and "content" in item:
                            rt = item.get("record_type", "semantic")
                            if rt not in ("semantic", "episodic", "procedural"):
                                rt = "semantic"
                            conf = float(item.get("confidence", 0.7))
                            extractions.append({
                                "content": item["content"],
                                "record_type": rt,
                                "confidence": conf,
                                "pattern_name": item.get("pattern_name", "llm_extraction"),
                            })

                strategy_used = "llm"
                logger.info("LLM extracted %d memories from context", len(extractions))

            except Exception as e:
                logger.warning("LLM extraction failed (%s), falling back to deterministic", e)
                strategy_used = "deterministic"
                # Fall through to deterministic

        # ── Deterministic fallback ───────────────────────────────
        if strategy == "deterministic" or (strategy == "llm" and not extractions):
            strategy_used = "deterministic" if not extractions else strategy_used
            # Simple pattern matching
            _SEMANTIC_TRIGGERS = [r"(?i)\b(prefers?|wants?|needs?|always|never|should be|default is)\b"]
            _EPISODIC_TRIGGERS = [r"(?i)\b(caused by|resulted in|outage|incident|fixed by|resolved)\b"]
            _PROCEDURAL_TRIGGERS = [r"(?i)\b(step \d|procedure|runbook|first.*then|1\)|checklist)\b"]

            sentences = _re.split(r"[.!?\n]+", context)
            for sentence in sentences:
                sentence = sentence.strip()
                if len(sentence) < 20:
                    continue

                rt = None
                pattern = "unknown"
                for trigger in _PROCEDURAL_TRIGGERS:
                    if _re.search(trigger, sentence):
                        rt = "procedural"
                        pattern = "procedural_pattern"
                        break
                if not rt:
                    for trigger in _EPISODIC_TRIGGERS:
                        if _re.search(trigger, sentence):
                            rt = "episodic"
                            pattern = "episodic_pattern"
                            break
                if not rt:
                    for trigger in _SEMANTIC_TRIGGERS:
                        if _re.search(trigger, sentence):
                            rt = "semantic"
                            pattern = "semantic_pattern"
                            break

                if rt and len(extractions) < max_extractions:
                    extractions.append({
                        "content": sentence,
                        "record_type": rt,
                        "confidence": 0.6,
                        "pattern_name": pattern,
                    })

            logger.info("Deterministic extraction found %d memories", len(extractions))

        # ── Store extracted memories ─────────────────────────────
        memory_ids: list[str] = []
        stored_extractions: list[dict[str, Any]] = []

        for ex in extractions:
            if ex["confidence"] < min_confidence:
                continue
            if self._contains_pii(ex["content"]):
                logger.warning("PII detected in extraction, skipping: %s", ex["content"][:50])
                self.audit.log(
                    operation="pii_blocked",
                    agent_id=agent_id,
                    namespace=namespace,
                    details={"content_preview": ex["content"][:30] + "...", "pattern": "pii_detected"},
                )
                continue

            rt = RecordType(ex["record_type"])
            typed_fields: dict[str, Any] = {}
            if rt == RecordType.SEMANTIC:
                typed_fields["confidence"] = ex["confidence"]
                typed_fields["source"] = f"context_extraction:{strategy_used}"
            elif rt == RecordType.EPISODIC:
                typed_fields["outcome"] = "Extracted from context"

            try:
                mid = await self.add(
                    content=ex["content"],
                    record_type=rt,
                    namespace=namespace,
                    created_by=agent_id,
                    metadata={
                        **(metadata or {}),
                        "source": "engram.ingest",
                        "extraction_strategy": strategy_used,
                        "pattern_name": ex.get("pattern_name", ""),
                    },
                    **typed_fields,
                )
                memory_ids.append(mid)
                stored_extractions.append({**ex, "memory_id": mid})
            except Exception as e:
                logger.warning("Failed to store extraction: %s", e)

        self.audit.log(
            operation="ingest",
            agent_id=agent_id,
            namespace=namespace,
            details={
                "strategy": strategy_used,
                "context_length": len(context),
                "extracted": len(extractions),
                "stored": len(memory_ids),
            },
        )

        return {
            "strategy_used": strategy_used,
            "extractions": stored_extractions,
            "memory_ids": memory_ids,
            "total_extracted": len(extractions),
            "total_stored": len(memory_ids),
        }

    # ── Context Manager ──────────────────────────────────────────

    async def __aenter__(self) -> "Memledger":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
