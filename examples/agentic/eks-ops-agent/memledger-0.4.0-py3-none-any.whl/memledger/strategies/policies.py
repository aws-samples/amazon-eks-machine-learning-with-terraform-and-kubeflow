"""Pluggable intelligence strategies for engram.

Memledger exposes four decision points where the trade-off between deterministic
rules and LLM-driven judgment is real and where users genuinely benefit from
having a choice:

  1. ImportanceStrategy   — write-time importance scoring
  2. WritePolicyStrategy  — should this memory be stored at all?
  3. ConflictResolverStrategy — when a conflict is detected, what do we do?
  4. RerankerStrategy     — final reranking of search results

Each strategy is an ABC with:
  - A deterministic reference implementation that preserves v0.3.0 behavior
    (free, no LLM call, sub-millisecond, no API key required)
  - Slot for an LLM-driven implementation in `llm.py` (v0.3.1)

Defaults are deterministic for pragmatic reasons — onboarding simplicity, zero
per-call cost, deterministic CI, no LLM provider dependency. Users opt in to
LLM strategies one at a time via the `strategies:` block in engram.yaml.

Memledger never makes a cost decision on behalf of the user. Every strategy choice
is explicit in the YAML; every model choice is explicit in the strategy config.

Status: v0.3.1 — interfaces and deterministic defaults shipped here. LLM
implementations live in `engram.strategies.llm`.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from memledger.models import MemoryRecord

logger = logging.getLogger(__name__)


# ── ImportanceStrategy ──────────────────────────────────────────────


class ImportanceStrategy(ABC):
    """Decide a memory's importance at write time.

    The returned value populates `MemoryRecord.importance` and feeds into the
    policy score for retrieval ranking. Range: [0.0, 1.0].
    """

    @abstractmethod
    async def score(self, record: "MemoryRecord") -> float:
        """Return importance in [0.0, 1.0]."""


class FixedImportance(ImportanceStrategy):
    """Default deterministic strategy.

    Returns a fixed value (0.5 by default). v0.3.0 behavior: every memory
    starts at 0.5, then shifts toward usage evidence as outcomes accumulate
    in the policy scoring layer.

    Free, deterministic, no LLM call, no API key required.
    """

    def __init__(self, default: float = 0.5) -> None:
        if not 0.0 <= default <= 1.0:
            raise ValueError(f"default importance must be in [0, 1], got {default}")
        self.default = default

    async def score(self, record: "MemoryRecord") -> float:
        return self.default


# ── WritePolicyStrategy ─────────────────────────────────────────────


@dataclass
class WriteDecision:
    """Result of a WritePolicyStrategy decision."""

    should_store: bool
    reason: Optional[str] = None  # human-readable explanation
    importance_hint: Optional[float] = None  # optional override of importance


class WritePolicyStrategy(ABC):
    """Decide whether a memory is worth storing at all.

    Some workloads (chat agents drowning in low-value observations) benefit
    from a gating step that filters out noise before it hits the substrate.
    Other workloads (the agent already decided to call add(), trust them)
    benefit from always storing.
    """

    @abstractmethod
    async def should_store(self, record: "MemoryRecord") -> WriteDecision:
        """Return a WriteDecision."""


class AlwaysStore(WritePolicyStrategy):
    """Default deterministic strategy.

    Always stores the memory. v0.3.0 behavior: the caller has already decided
    to call add(), so engram trusts them.

    Free, deterministic, no LLM call, no API key required.
    """

    async def should_store(self, record: "MemoryRecord") -> WriteDecision:
        return WriteDecision(should_store=True, reason="always-store policy")


# ── ConflictResolverStrategy ────────────────────────────────────────


@dataclass
class ConflictResolution:
    """Result of a ConflictResolverStrategy decision."""

    # One of: "store_anyway" | "supersede" | "merge" | "reject_new" | "accept_both"
    action: str
    reason: Optional[str] = None
    # If action == "supersede", this should point at the existing record being
    # superseded. The caller is responsible for applying the supersession.
    supersede_id: Optional[str] = None
    # If action == "merge", this is the new merged content the caller should
    # store instead of the original new memory.
    merged_content: Optional[str] = None


class ConflictResolverStrategy(ABC):
    """Decide what to do when adding a memory that conflicts with an existing one.

    Conflict detection itself is the responsibility of `Memledger.add()` —
    the resolver receives the new record and the existing high-similarity
    match, and returns an action.
    """

    @abstractmethod
    async def resolve(
        self,
        new_record: "MemoryRecord",
        existing_record: "MemoryRecord",
        similarity: float,
    ) -> ConflictResolution:
        """Return a ConflictResolution."""


class HookOnly(ConflictResolverStrategy):
    """Default deterministic strategy.

    Stores the new memory regardless. v0.3.0 behavior: engram detects the
    conflict, fires the on_conflict hook, and lets the caller's hook
    implementation decide what to do externally.

    Free, deterministic, no LLM call, no API key required.
    """

    async def resolve(
        self,
        new_record: "MemoryRecord",
        existing_record: "MemoryRecord",
        similarity: float,
    ) -> ConflictResolution:
        return ConflictResolution(
            action="store_anyway",
            reason=f"hook-only resolver — caller hook handles conflict (similarity={similarity:.3f})",
        )


# ── RerankerStrategy ────────────────────────────────────────────────


class RerankerStrategy(ABC):
    """Reorder search results.

    Memledger's default reranker blends cosine similarity with the policy score
    (success rate, recency, frequency, importance). An LLM reranker can layer
    a Cohere-style or Voyage-style or LLM-prompted reranking step on top.
    """

    @abstractmethod
    async def rerank(
        self,
        query: str,
        records: list["MemoryRecord"],
    ) -> list["MemoryRecord"]:
        """Return the records re-sorted, with `score` updated in place."""


class PolicyRerank(RerankerStrategy):
    """Default deterministic strategy.

    Wraps `Memledger._rerank` (the v0.3.0 reranker) — blends cosine similarity
    with the configured `ScoringConfig` policy signals. Sub-millisecond, free,
    no LLM call, no API key required.

    Note: this strategy is special because it requires access to the engram
    instance's `_rerank` method, which is the canonical scoring path. It's
    constructed with a callable that does the work, so engram can pass its
    own bound method in.
    """

    def __init__(self, rerank_fn: Any) -> None:
        # rerank_fn: Callable[[list[MemoryRecord]], list[MemoryRecord]]
        # We accept a sync or async callable; we treat it as sync because
        # engram._rerank is currently sync. We'll await it if it returns
        # an awaitable (forward-compat).
        self._rerank_fn = rerank_fn

    async def rerank(
        self,
        query: str,
        records: list["MemoryRecord"],
    ) -> list["MemoryRecord"]:
        result = self._rerank_fn(records)
        if hasattr(result, "__await__"):
            result = await result
        return result


# ── Container ──────────────────────────────────────────────────────


@dataclass
class EngramStrategies:
    """Bundle of all four pluggable strategies in one place.

    Memledger constructs this once at init time from `MemledgerConfig.strategies`
    and references it for every decision. Defaults preserve v0.3.0 behavior;
    users opt in to LLM-driven strategies one at a time via YAML.
    """

    importance: ImportanceStrategy
    write_policy: WritePolicyStrategy
    conflict_resolver: ConflictResolverStrategy
    reranker: RerankerStrategy
