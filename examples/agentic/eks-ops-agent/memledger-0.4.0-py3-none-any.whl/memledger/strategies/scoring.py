"""Memory scoring strategy — deterministic, policy-based ranking.

Combines cosine similarity with usage signals:
  - success_rate: success_count / (success_count + failure_count)
  - recency: power law decay from last_accessed_at
  - frequency: normalized access_count
  - importance: write-time hint, overridden by usage over time

Final score = similarity_weight * cosine_score + policy_weight * policy_score

All weights configurable via ScoringConfig. Power law decay by default
(matches Ebbinghaus forgetting curve, preserves long-term knowledge).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional


@dataclass
class ScoringConfig:
    """Configurable weights for memory scoring."""

    # How much cosine similarity matters vs policy signals
    similarity_weight: float = 0.5
    policy_weight: float = 0.5

    # Policy signal weights (must sum to 1.0)
    success_rate_weight: float = 0.3
    recency_weight: float = 0.25
    frequency_weight: float = 0.2
    importance_weight: float = 0.25

    # Decay configuration
    decay_type: str = "power_law"  # "power_law" or "exponential"
    power_law_alpha: float = 0.5  # for power law: score = days^(-alpha)
    exponential_half_life_days: float = 14.0  # for exponential: score halves every N days

    # Frequency normalization: access_count is divided by this
    frequency_max: int = 100


def _recency_score(
    last_accessed_at: Optional[datetime],
    config: ScoringConfig,
) -> float:
    """Compute recency score using configured decay function."""
    if last_accessed_at is None:
        return 0.5  # neutral if never accessed

    now = datetime.now(timezone.utc)
    if last_accessed_at.tzinfo is None:
        last_accessed_at = last_accessed_at.replace(tzinfo=timezone.utc)
    age_days = max((now - last_accessed_at).total_seconds() / 86400, 0.001)

    if config.decay_type == "power_law":
        # Power law: preserves old memories better than exponential
        # Matches Ebbinghaus forgetting curve
        return max(1.0, age_days) ** (-config.power_law_alpha)
    else:
        # Exponential: aggressive decay, favors recency
        return math.exp(-0.693 * age_days / config.exponential_half_life_days)


def _importance_score(
    importance_hint: float,
    access_count: int,
    success_count: int,
    failure_count: int,
) -> float:
    """Compute effective importance from write-time hint and usage evidence.

    Usage evidence overrides the hint over time:
    - If the memory has been used successfully many times, its importance
      is driven by that evidence regardless of the initial hint.
    - If the memory has no usage data, the hint is the primary signal.
    """
    total_outcomes = success_count + failure_count
    if total_outcomes >= 5:
        # Enough usage data — importance is primarily evidence-based
        usage_importance = success_count / total_outcomes
        # Blend: 70% usage evidence, 30% original hint
        return 0.7 * usage_importance + 0.3 * importance_hint
    elif access_count >= 3:
        # Some access data but limited outcome data
        # Access frequency itself is a signal of importance
        access_signal = min(access_count / 20.0, 1.0)
        return 0.5 * access_signal + 0.5 * importance_hint
    else:
        # Cold start — rely on the hint
        return importance_hint


def compute_policy_score(
    access_count: int = 0,
    success_count: int = 0,
    failure_count: int = 0,
    last_accessed_at: Optional[datetime] = None,
    importance: float = 0.5,
    config: Optional[ScoringConfig] = None,
) -> float:
    """Compute deterministic policy score from usage signals.

    Returns a float between 0.0 and 1.0.
    """
    if config is None:
        config = ScoringConfig()

    # Success rate: 0.0 to 1.0
    total_outcomes = success_count + failure_count
    if total_outcomes > 0:
        success_rate = success_count / total_outcomes
    else:
        success_rate = 0.5  # neutral if no outcome data

    # Recency: power law or exponential decay
    recency = _recency_score(last_accessed_at, config)

    # Frequency: normalized 0.0 to 1.0
    frequency = min(access_count / max(config.frequency_max, 1), 1.0)

    # Effective importance: hint overridden by usage evidence
    effective_importance = _importance_score(importance, access_count, success_count, failure_count)

    return (
        config.success_rate_weight * success_rate
        + config.recency_weight * recency
        + config.frequency_weight * frequency
        + config.importance_weight * effective_importance
    )


def compute_final_score(
    cosine_score: float,
    access_count: int = 0,
    success_count: int = 0,
    failure_count: int = 0,
    last_accessed_at: Optional[datetime] = None,
    importance: float = 0.5,
    config: Optional[ScoringConfig] = None,
) -> float:
    """Combine cosine similarity with policy score.

    Returns a float between 0.0 and 1.0.
    """
    if config is None:
        config = ScoringConfig()

    policy = compute_policy_score(
        access_count=access_count,
        success_count=success_count,
        failure_count=failure_count,
        last_accessed_at=last_accessed_at,
        importance=importance,
        config=config,
    )

    return config.similarity_weight * cosine_score + config.policy_weight * policy


def compute_confidence(
    created_at: Optional[datetime] = None,
    last_accessed_at: Optional[datetime] = None,
    success_count: int = 0,
    failure_count: int = 0,
    initial_confidence: float = 0.7,
    human_verified: bool = False,
    staleness_days: int = 90,
) -> float:
    """Compute memory confidence — how reliable is this information.

    Confidence lifecycle:
        - New memory: 0.7 (default)
        - Reinforced by successful use: rises toward 0.9
        - Contradicted by failures: drops toward 0.3
        - Unused for staleness_days: decays toward 0.1
        - Human verified: pinned at 1.0

    This is distinct from importance (how valuable is this memory) and
    cosine similarity (how relevant to the query). Confidence answers:
    "should the agent trust this information?"

    Returns a float between 0.0 and 1.0.
    """
    if human_verified:
        return 1.0

    confidence = initial_confidence

    # Outcome-based adjustment
    total_outcomes = success_count + failure_count
    if total_outcomes > 0:
        success_rate = success_count / total_outcomes
        # Successful use reinforces confidence (toward 0.9)
        # Failures erode confidence (toward 0.3)
        if success_rate >= 0.8:
            confidence = min(0.9, confidence + 0.05 * total_outcomes)
        elif success_rate <= 0.3:
            confidence = max(0.3, confidence - 0.1 * (1.0 - success_rate) * total_outcomes)
        else:
            # Mixed results — moderate adjustment
            confidence = confidence * 0.5 + success_rate * 0.5

    # Staleness decay — unused memories lose confidence over time
    access_time = last_accessed_at or created_at
    if access_time:
        now = datetime.now(timezone.utc)
        if access_time.tzinfo is None:
            access_time = access_time.replace(tzinfo=timezone.utc)
        days_since = (now - access_time).total_seconds() / 86400

        if days_since > staleness_days:
            # Decay toward 0.1 for very stale memories
            decay_factor = staleness_days / max(days_since, 1)
            confidence = max(0.1, confidence * decay_factor)

    return round(min(1.0, max(0.0, confidence)), 3)
