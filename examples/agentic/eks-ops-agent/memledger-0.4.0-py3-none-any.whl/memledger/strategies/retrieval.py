"""Composite retrieval strategy — parallel typed search.

Given a situation, returns similar episodes, suggested procedures,
and known failures in a single call. Three parallel vector searches,
no LLM, no complex logic.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from memledger.models import MemoryRecord


@dataclass
class ContextualRecall:
    """Result of a composite retrieval — episodes, procedures, and failures."""

    similar_episodes: list[MemoryRecord] = field(default_factory=list)
    suggested_procedures: list[MemoryRecord] = field(default_factory=list)
    known_failures: list[MemoryRecord] = field(default_factory=list)
    query: str = ""
    search_time_ms: float = 0.0

    @property
    def has_results(self) -> bool:
        return bool(self.similar_episodes or self.suggested_procedures or self.known_failures)

    @property
    def total_count(self) -> int:
        return len(self.similar_episodes) + len(self.suggested_procedures) + len(self.known_failures)

    def summary(self) -> str:
        """Human-readable summary for agent tool output."""
        if not self.has_results:
            return "No relevant memories found."

        parts = []
        if self.similar_episodes:
            parts.append(f"{len(self.similar_episodes)} similar episode(s)")
        if self.suggested_procedures:
            parts.append(f"{len(self.suggested_procedures)} suggested procedure(s)")
        if self.known_failures:
            parts.append(f"{len(self.known_failures)} known failure(s) to avoid")

        header = f"Found {', '.join(parts)} (search took {self.search_time_ms:.0f}ms):\n"

        lines = []
        if self.similar_episodes:
            lines.append("## Similar Episodes")
            for i, rec in enumerate(self.similar_episodes, 1):
                score = f" (score: {rec.score:.3f})" if rec.score else ""
                outcome = ""
                if hasattr(rec, "outcome") and rec.outcome:
                    outcome = f" → {rec.outcome}"
                lines.append(f"  {i}. [{rec.namespace}]{score}: {rec.content}{outcome}")

        if self.suggested_procedures:
            lines.append("## Suggested Procedures")
            for i, rec in enumerate(self.suggested_procedures, 1):
                score = f" (score: {rec.score:.3f})" if rec.score else ""
                lines.append(f"  {i}. [{rec.namespace}]{score}: {rec.content}")
                if hasattr(rec, "steps") and rec.steps:
                    for j, step in enumerate(rec.steps, 1):
                        lines.append(f"     {j}. {step}")

        if self.known_failures:
            lines.append("## Known Failures (avoid these approaches)")
            for i, rec in enumerate(self.known_failures, 1):
                score = f" (score: {rec.score:.3f})" if rec.score else ""
                lines.append(f"  {i}. [{rec.namespace}]{score}: {rec.content}")

        return header + "\n".join(lines)
