"""LLM-driven reference implementations of engram's pluggable strategies.

Four implementations, one per strategy interface defined in `policies.py`:

  - LLMImportance        — Generative-Agents-style 1-10 importance scoring
  - LLMGated             — Mem0-style write gating
  - LLMResolver          — semantic conflict resolution
  - LLMRerank            — LLM rerank step on top of policy reranking

All four use LiteLLM under the hood so any provider works (Bedrock, OpenAI,
Anthropic, local Llama, etc.). The model is specified per-strategy in the
engram.yaml config; engram never makes a model choice on behalf of the user.

Default prompts are drawn from published research where applicable
(LLMImportance follows Park et al., Generative Agents) and otherwise designed
to be conservative — they err toward storing rather than discarding, accepting
rather than rejecting, because false negatives in memory are usually worse
than false positives.

Status: v0.3.1 — first cut. Prompts and parsing will be tuned over time as
the eval harness reports results.
"""

from __future__ import annotations

import json
import logging
import re
from typing import TYPE_CHECKING, Any, Optional

from memledger.strategies.policies import (
    ConflictResolution,
    ConflictResolverStrategy,
    ImportanceStrategy,
    RerankerStrategy,
    WriteDecision,
    WritePolicyStrategy,
)

if TYPE_CHECKING:
    from memledger.models import MemoryRecord

logger = logging.getLogger(__name__)


# ── Shared LiteLLM helper ──────────────────────────────────────────


# litellm requires provider prefix for non-OpenAI models. Mirrors
# embeddings.py to keep model naming consistent across the project.
_PROVIDER_PREFIXES = {
    "bedrock": "bedrock/",
    "anthropic": "anthropic/",
}


def _normalize_model(model: str, provider: Optional[str] = None) -> str:
    """Add a litellm provider prefix if missing."""
    if provider and provider in _PROVIDER_PREFIXES:
        prefix = _PROVIDER_PREFIXES[provider]
        if not model.startswith(prefix):
            return f"{prefix}{model}"
    return model


async def _llm_call(
    prompt: str,
    model: str,
    *,
    max_tokens: int = 200,
    temperature: float = 0.0,
    timeout: float = 30.0,
) -> str:
    """Single-turn LiteLLM call. Returns the text content of the response.

    Wraps errors so strategy callers can fall back gracefully if the LLM is
    unavailable.
    """
    try:
        import litellm
    except ImportError as e:
        raise ImportError("LLM strategies require litellm. Install with: pip install engram[bedrock]") from e

    response = await litellm.acompletion(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=max_tokens,
        temperature=temperature,
        timeout=timeout,
    )
    return response.choices[0].message.content or ""


# ── LLMImportance ──────────────────────────────────────────────────


class LLMImportance(ImportanceStrategy):
    """LLM-driven importance scoring.

    Asks a configured LLM to rate a memory's significance on a 1-10 scale,
    after Park et al. (Generative Agents). Normalizes to [0.0, 1.0].

    Useful for character/social agents and any workload where some memories
    are obviously more significant than others. Adds one LLM call per write,
    so use a cheap model (Haiku, GPT-4o-mini) unless quality matters more
    than cost.

    Config:
        model:       LiteLLM model name (e.g. "anthropic/claude-haiku-4-5")
        provider:    Optional provider hint for prefix (bedrock, anthropic, ...)
        prompt:      Optional custom prompt template — must contain {content}
        fallback:    Score returned if the LLM call fails (default 0.5)
        max_tokens:  Max tokens for the LLM response (default 20)
    """

    DEFAULT_PROMPT = (
        "On a scale of 1 to 10, where 1 is purely mundane (e.g. brushing teeth, "
        "routine acknowledgments) and 10 is extremely poignant (e.g. a major "
        "incident, a contradicted assumption, a hard-won insight), rate the "
        "likely significance of the following memory.\n\n"
        "Memory: {content}\n\n"
        "Respond with only a single integer between 1 and 10. No explanation."
    )

    def __init__(
        self,
        model: str,
        provider: Optional[str] = None,
        prompt: Optional[str] = None,
        fallback: float = 0.5,
        max_tokens: int = 20,
    ) -> None:
        self.model = _normalize_model(model, provider)
        self.prompt = prompt or self.DEFAULT_PROMPT
        if not 0.0 <= fallback <= 1.0:
            raise ValueError("fallback must be in [0, 1]")
        self.fallback = fallback
        self.max_tokens = max_tokens

    async def score(self, record: "MemoryRecord") -> float:
        try:
            response = await _llm_call(
                self.prompt.format(content=record.content),
                model=self.model,
                max_tokens=self.max_tokens,
            )
            # Pull the first integer out of the response — robust to "8" or
            # "8.\n" or "8 because..." or similar.
            match = re.search(r"\d+", response)
            if not match:
                logger.warning(
                    "LLMImportance: no integer in response %r — using fallback %s",
                    response,
                    self.fallback,
                )
                return self.fallback
            value = int(match.group())
            score = max(0.0, min(1.0, value / 10.0))
            logger.debug("LLMImportance: rated %s -> %s", value, score)
            return score
        except Exception as e:
            logger.warning("LLMImportance call failed: %s — using fallback %s", e, self.fallback)
            return self.fallback


# ── LLMGated ───────────────────────────────────────────────────────


class LLMGated(WritePolicyStrategy):
    """LLM-driven write gating.

    Asks a configured LLM whether the candidate memory is worth storing.
    The default prompt errs toward storing — false negatives in memory
    (forgetting something important) are usually worse than false positives
    (storing something unimportant).

    Config:
        model:       LiteLLM model name
        provider:    Optional provider hint
        prompt:      Optional custom prompt template — must contain {content}
        fallback_store:  If the LLM call fails, store anyway (default True)
        max_tokens:  Max tokens for the LLM response (default 100)
    """

    DEFAULT_PROMPT = (
        "You are a memory gatekeeper for an AI agent. Decide whether the "
        "following observation is worth storing in long-term memory.\n\n"
        "Store it if it contains:\n"
        "- A fact, preference, or constraint the agent will need to remember\n"
        "- An incident, outcome, or decision worth referencing later\n"
        "- A procedure, fix, or pattern that could be reused\n\n"
        "Do NOT store it if it is:\n"
        "- Trivial chitchat or acknowledgments\n"
        "- Tool call results that have no lasting value\n"
        "- Pure transient reasoning that does not contain a fact\n\n"
        "Observation: {content}\n\n"
        "Respond with a JSON object:\n"
        '{{"store": true|false, "reason": "<one short sentence>"}}\n'
        "If in doubt, prefer storing."
    )

    def __init__(
        self,
        model: str,
        provider: Optional[str] = None,
        prompt: Optional[str] = None,
        fallback_store: bool = True,
        max_tokens: int = 100,
    ) -> None:
        self.model = _normalize_model(model, provider)
        self.prompt = prompt or self.DEFAULT_PROMPT
        self.fallback_store = fallback_store
        self.max_tokens = max_tokens

    async def should_store(self, record: "MemoryRecord") -> WriteDecision:
        try:
            response = await _llm_call(
                self.prompt.format(content=record.content),
                model=self.model,
                max_tokens=self.max_tokens,
            )
            decision = _extract_json(response)
            if decision is None:
                logger.warning(
                    "LLMGated: could not parse JSON from response %r — fallback %s",
                    response,
                    self.fallback_store,
                )
                return WriteDecision(
                    should_store=self.fallback_store,
                    reason="LLM response could not be parsed; using fallback",
                )
            return WriteDecision(
                should_store=bool(decision.get("store", self.fallback_store)),
                reason=str(decision.get("reason", "LLM gated")),
            )
        except Exception as e:
            logger.warning(
                "LLMGated call failed: %s — fallback store=%s",
                e,
                self.fallback_store,
            )
            return WriteDecision(
                should_store=self.fallback_store,
                reason=f"LLM call failed: {e}",
            )


# ── LLMResolver ────────────────────────────────────────────────────


class LLMResolver(ConflictResolverStrategy):
    """LLM-driven conflict resolution.

    Reads the new memory and the existing high-similarity match, and proposes
    one of: store_anyway, supersede, merge, accept_both, reject_new.

    Use this when conflicts are common in your workload and manual review
    via the on_conflict hook is impractical (research agents, debate-style
    multi-agent systems, high-volume CRM agents).

    Config:
        model:       LiteLLM model name
        provider:    Optional provider hint
        prompt:      Optional custom prompt template — must contain
                     {new_content} and {existing_content}
        fallback_action: Action to take if the LLM call fails (default
                         "store_anyway" — preserves v0.3.0 behavior)
        max_tokens:  Max tokens for the LLM response (default 250)
    """

    DEFAULT_PROMPT = (
        "Two memories appear to conflict. Decide what to do.\n\n"
        "EXISTING memory (already stored):\n{existing_content}\n\n"
        "NEW memory (just added):\n{new_content}\n\n"
        "Pick exactly one action:\n"
        "- store_anyway: both are valid, keep both as-is\n"
        "- supersede: the new memory replaces the existing one (existing becomes deprecated)\n"
        "- merge: combine into a single new memory (provide merged_content)\n"
        "- accept_both: same as store_anyway, but explicitly acknowledged as compatible\n"
        "- reject_new: the existing one is correct and the new one should be discarded\n\n"
        "Respond with a JSON object:\n"
        '{{"action": "<action>", "reason": "<one short sentence>", '
        '"merged_content": "<only if action=merge>"}}\n'
    )

    VALID_ACTIONS = {"store_anyway", "supersede", "merge", "accept_both", "reject_new"}

    def __init__(
        self,
        model: str,
        provider: Optional[str] = None,
        prompt: Optional[str] = None,
        fallback_action: str = "store_anyway",
        max_tokens: int = 250,
    ) -> None:
        self.model = _normalize_model(model, provider)
        self.prompt = prompt or self.DEFAULT_PROMPT
        if fallback_action not in self.VALID_ACTIONS:
            raise ValueError(f"fallback_action must be one of {self.VALID_ACTIONS}, got {fallback_action}")
        self.fallback_action = fallback_action
        self.max_tokens = max_tokens

    async def resolve(
        self,
        new_record: "MemoryRecord",
        existing_record: "MemoryRecord",
        similarity: float,
    ) -> ConflictResolution:
        try:
            response = await _llm_call(
                self.prompt.format(
                    new_content=new_record.content,
                    existing_content=existing_record.content,
                ),
                model=self.model,
                max_tokens=self.max_tokens,
            )
            parsed = _extract_json(response)
            if parsed is None:
                logger.warning(
                    "LLMResolver: could not parse JSON from response %r — fallback %s",
                    response,
                    self.fallback_action,
                )
                return ConflictResolution(
                    action=self.fallback_action,
                    reason="LLM response could not be parsed; using fallback",
                )

            action = str(parsed.get("action", self.fallback_action))
            if action not in self.VALID_ACTIONS:
                logger.warning(
                    "LLMResolver: invalid action %r — fallback %s",
                    action,
                    self.fallback_action,
                )
                action = self.fallback_action

            return ConflictResolution(
                action=action,
                reason=str(parsed.get("reason", "")),
                supersede_id=existing_record.id if action == "supersede" else None,
                merged_content=parsed.get("merged_content") if action == "merge" else None,
            )
        except Exception as e:
            logger.warning(
                "LLMResolver call failed: %s — fallback action=%s",
                e,
                self.fallback_action,
            )
            return ConflictResolution(
                action=self.fallback_action,
                reason=f"LLM call failed: {e}",
            )


# ── LLMRerank ──────────────────────────────────────────────────────


class LLMRerank(RerankerStrategy):
    """LLM-driven reranking on top of policy reranking.

    First applies the deterministic policy rerank (cosine + scoring) so the
    LLM only sees the top-N candidates. Then prompts the LLM to reorder them
    based on the query.

    Strictly more expensive than PolicyRerank — adds one LLM call per search
    plus the deterministic rerank. Use for non-real-time analytical agents
    where retrieval quality matters more than latency.

    Config:
        model:       LiteLLM model name
        provider:    Optional provider hint
        rerank_fn:   Bound reference to engram._rerank for the deterministic
                     pre-pass. Injected by build_strategies.
        top_k:       Pass at most this many records to the LLM (default 10).
                     Larger k = better quality but more tokens.
        prompt:      Optional custom prompt template — must contain
                     {query} and {records_json}
        fallback_to_policy: If the LLM call fails, fall back to the
                            deterministic rerank result (default True)
        max_tokens:  Max tokens for the LLM response (default 500)
    """

    DEFAULT_PROMPT = (
        "Reorder the following memories from most to least relevant to the "
        "user's query. Consider both literal relevance and likely usefulness.\n\n"
        "Query: {query}\n\n"
        "Memories (each with an id and content):\n{records_json}\n\n"
        "Respond with a JSON array of ids in the new order. Most relevant first. "
        "Include all ids; do not omit any. Example:\n"
        '["id1", "id2", "id3"]'
    )

    def __init__(
        self,
        model: str,
        provider: Optional[str] = None,
        rerank_fn: Any = None,
        top_k: int = 10,
        prompt: Optional[str] = None,
        fallback_to_policy: bool = True,
        max_tokens: int = 500,
    ) -> None:
        self.model = _normalize_model(model, provider)
        self.prompt = prompt or self.DEFAULT_PROMPT
        self.top_k = top_k
        self.fallback_to_policy = fallback_to_policy
        self.max_tokens = max_tokens
        self._rerank_fn = rerank_fn

    async def rerank(
        self,
        query: str,
        records: list["MemoryRecord"],
    ) -> list["MemoryRecord"]:
        if not records:
            return records

        # Step 1: deterministic policy rerank to get the candidate set
        if self._rerank_fn is not None:
            candidates = self._rerank_fn(records)
        else:
            candidates = records
        candidates = candidates[: self.top_k]

        # Step 2: ask the LLM to reorder
        try:
            records_json = json.dumps([{"id": r.id, "content": (r.content or "")[:200]} for r in candidates])
            response = await _llm_call(
                self.prompt.format(query=query, records_json=records_json),
                model=self.model,
                max_tokens=self.max_tokens,
            )
            ordered_ids = _extract_json(response)
            if not isinstance(ordered_ids, list):
                logger.warning("LLMRerank: response was not a JSON list — fallback to policy")
                return candidates if self.fallback_to_policy else records

            id_to_record = {r.id: r for r in candidates}
            reordered = [id_to_record[i] for i in ordered_ids if i in id_to_record]
            # Append any candidates the LLM forgot
            seen = {r.id for r in reordered}
            for r in candidates:
                if r.id not in seen:
                    reordered.append(r)
            return reordered
        except Exception as e:
            logger.warning(
                "LLMRerank call failed: %s — falling back to policy rerank",
                e,
            )
            return candidates if self.fallback_to_policy else records


# ── JSON extraction helper ─────────────────────────────────────────


def _extract_json(text: str) -> Any:
    """Pull a JSON object or array out of an LLM response.

    Robust to:
      - Surrounding prose ("Here is the JSON: { ... }")
      - Markdown code fences (```json ... ```)
      - Trailing whitespace or punctuation

    Returns the parsed value or None if no valid JSON is found.
    """
    if not text:
        return None

    # Try a fenced code block first
    fence = re.search(r"```(?:json)?\s*(.+?)```", text, flags=re.DOTALL)
    if fence:
        text = fence.group(1)

    # Try the largest {...} or [...] in the text
    for match in re.finditer(r"(\{.*\}|\[.*\])", text, flags=re.DOTALL):
        candidate = match.group(1)
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            continue

    # Last resort: parse the whole thing
    try:
        return json.loads(text.strip())
    except json.JSONDecodeError:
        return None
