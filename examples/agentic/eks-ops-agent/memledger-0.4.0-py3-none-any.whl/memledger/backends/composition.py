"""Multi-backend composition router.

Routes operations to the appropriate backend based on access pattern:
  - Writes → Primary (DynamoDB, Redis, or any key-value store)
  - Exact lookups → Primary
  - Semantic search → Search backend (OpenSearch, pgvector)
  - Batch operations → Primary

The router IS a BackendProvider — Memledger doesn't know it's talking to a
composition. This means no changes to the Memledger class or any existing backend.

Sync strategy (MVP): inline — writes go to both backends synchronously.
Search backend failures on write are logged but don't fail the operation.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from memledger.backends.base import BackendProvider
from memledger.models import MemoryRecord

logger = logging.getLogger(__name__)


class CompositionRouter(BackendProvider):
    """Routes operations between a primary store and a search index.

    Primary: source of truth for all writes, exact lookups, batch operations.
    Search: handles vector and text search. Populated via inline sync on writes.

    Config:
        primary: name of the primary backend (e.g. "dynamodb")
        search: name of the search backend (e.g. "opensearch")
        sync: "inline" (default) — writes to both on every add/update/delete
    """

    def __init__(self) -> None:
        self._primary: Optional[BackendProvider] = None
        self._search: Optional[BackendProvider] = None
        self._sync_mode: str = "inline"

    async def initialize(self, config: dict[str, Any]) -> None:
        """Initialize both backends.

        Config format:
            {
                "primary_backend": <initialized BackendProvider>,
                "search_backend": <initialized BackendProvider>,
                "sync": "inline"  # or "background" (future)
            }

        The backends are passed pre-initialized by Memledger.create().
        """
        self._primary = config["primary_backend"]
        self._search = config["search_backend"]
        self._sync_mode = config.get("sync", "inline")

        logger.info(
            "CompositionRouter initialized: primary=%s, search=%s, sync=%s",
            type(self._primary).__name__,
            type(self._search).__name__,
            self._sync_mode,
        )

    # ── Writes: Primary + sync to Search ─────────────────────

    async def add(self, records: list[MemoryRecord]) -> list[str]:
        """Write to primary, then sync to search."""
        if not self._primary:
            raise RuntimeError("CompositionRouter not initialized.")

        # Write to primary (source of truth)
        ids = await self._primary.add(records)

        # Sync to search (best effort — failure doesn't fail the write)
        if self._search:
            try:
                await self._search.add(records)
            except Exception as e:
                logger.warning(
                    "Failed to sync %d records to search backend: %s. Records are in primary but not yet searchable.",
                    len(records),
                    e,
                )

        return ids

    async def update(self, record_id: str, **kwargs: Any) -> bool:
        """Update in primary, then sync to search."""
        if not self._primary:
            raise RuntimeError("CompositionRouter not initialized.")

        result = await self._primary.update(record_id, **kwargs)

        if result and self._search:
            try:
                await self._search.update(record_id, **kwargs)
            except Exception as e:
                logger.warning("Failed to sync update to search: %s", e)

        return result

    async def delete(self, record_id: str) -> bool:
        """Soft delete in primary, then sync to search."""
        if not self._primary:
            raise RuntimeError("CompositionRouter not initialized.")

        result = await self._primary.delete(record_id)

        if result and self._search:
            try:
                await self._search.delete(record_id)
            except Exception as e:
                logger.warning("Failed to sync delete to search: %s", e)

        return result

    # ── Exact lookups: Primary ───────────────────────────────

    async def get(self, record_id: str) -> Optional[MemoryRecord]:
        """Get from primary (source of truth)."""
        if not self._primary:
            raise RuntimeError("CompositionRouter not initialized.")
        return await self._primary.get(record_id)

    # ── Search: Search backend ───────────────────────────────

    async def search_vector(
        self,
        embedding: list[float],
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        """Vector search routes to search backend."""
        if not self._search:
            logger.warning("No search backend configured. Returning empty results.")
            return []
        return await self._search.search_vector(embedding, top_k, namespace, filters)

    async def search_text(
        self,
        query: str,
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        """Text search routes to search backend."""
        if not self._search:
            logger.warning("No search backend configured. Returning empty results.")
            return []
        return await self._search.search_text(query, top_k, namespace, filters)

    async def search_hybrid(
        self,
        query: str,
        embedding: list[float],
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        """Hybrid search (vector + BM25 + RRF) routes to search backend."""
        if not self._search:
            logger.warning("No search backend configured. Returning empty results.")
            return []
        if hasattr(self._search, "search_hybrid"):
            return await self._search.search_hybrid(
                query=query,
                embedding=embedding,
                top_k=top_k,
                namespace=namespace,
                filters=filters,
            )
        # Fall back to vector-only if search backend doesn't support hybrid
        return await self._search.search_vector(
            embedding=embedding,
            top_k=top_k,
            namespace=namespace,
            filters=filters,
        )

    # ── Scoring: Primary ─────────────────────────────────────

    async def record_access(self, record_ids: list[str], accessed_by: str = None) -> None:
        """Track access in primary (scoring signals live in primary)."""
        if self._primary and hasattr(self._primary, "record_access"):
            await self._primary.record_access(record_ids, accessed_by=accessed_by)

    async def record_outcome(self, record_id: str, success: bool) -> bool:
        """Track outcome in primary."""
        if self._primary and hasattr(self._primary, "record_outcome"):
            return await self._primary.record_outcome(record_id, success)
        return False

    # ── Introspection: Primary ───────────────────────────────

    async def health_check(self) -> bool:
        """Both backends must be healthy."""
        primary_ok = await self._primary.health_check() if self._primary else False
        search_ok = await self._search.health_check() if self._search else False

        if not primary_ok:
            logger.error("Primary backend health check failed")
        if not search_ok:
            logger.warning("Search backend health check failed — searches will return empty")

        return primary_ok  # primary is essential; search is degraded-mode-ok

    async def list_namespaces(self) -> list[str]:
        """Namespaces from primary (source of truth)."""
        if self._primary:
            return await self._primary.list_namespaces()
        return []

    async def stats(self, namespace: Optional[str] = None) -> dict[str, Any]:
        """Stats from primary (source of truth)."""
        if self._primary:
            return await self._primary.stats(namespace)
        return {}

    # ── Batch APIs: Primary ──────────────────────────────────

    async def get_by_session(self, session_id: str) -> list[MemoryRecord]:
        if self._primary:
            return await self._primary.get_by_session(session_id)
        return []

    async def get_by_timerange(self, start, end, namespace=None) -> list[MemoryRecord]:
        if self._primary:
            return await self._primary.get_by_timerange(start, end, namespace)
        return []

    async def get_stale(self, days=30, min_access=0, namespace=None) -> list[MemoryRecord]:
        if self._primary:
            return await self._primary.get_stale(days, min_access, namespace)
        return []

    async def get_by_status(self, status: str, namespace=None) -> list[MemoryRecord]:
        if self._primary:
            return await self._primary.get_by_status(status, namespace)
        return []

    async def bulk_update_status(self, record_ids: list[str], status: str) -> int:
        """Update status in primary, sync to search."""
        if not self._primary:
            return 0

        count = await self._primary.bulk_update_status(record_ids, status)

        if count > 0 and self._search:
            try:
                await self._search.bulk_update_status(record_ids, status)
            except Exception as e:
                logger.warning("Failed to sync bulk status update to search: %s", e)

        return count

    async def bulk_archive(self, record_ids: list[str]) -> int:
        return await self.bulk_update_status(record_ids, "archived")

    # ── Cleanup ──────────────────────────────────────────────

    async def close(self) -> None:
        """Close both backends."""
        if self._primary:
            await self._primary.close()
        if self._search:
            await self._search.close()
