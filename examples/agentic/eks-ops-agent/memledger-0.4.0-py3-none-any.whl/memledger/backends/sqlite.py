"""SQLite + sqlite-vec backend provider.

Zero-install local memory for on-device agents.
Requires: pip install engram[sqlite]
"""

from __future__ import annotations

import json
import logging
import struct
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from memledger.backends.base import BackendProvider
from memledger.models import MemoryRecord

logger = logging.getLogger(__name__)

CREATE_TABLES_SQL = """
CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'semantic',
    namespace TEXT NOT NULL DEFAULT '/',
    agent_id TEXT,
    user_id TEXT,
    session_id TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    importance REAL DEFAULT 0.5,
    metadata TEXT DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    access_count INTEGER DEFAULT 0,
    last_accessed_at TEXT,
    success_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0,
    supersedes TEXT,
    derived_from TEXT DEFAULT '[]',
    created_by TEXT,
    workflow_id TEXT,
    triggered_by TEXT,
    accessed_by TEXT DEFAULT '[]'
);

CREATE INDEX IF NOT EXISTS idx_memories_namespace ON memories(namespace);
CREATE INDEX IF NOT EXISTS idx_memories_record_type ON memories(record_type);
CREATE INDEX IF NOT EXISTS idx_memories_agent_id ON memories(agent_id);
CREATE INDEX IF NOT EXISTS idx_memories_status ON memories(status);
"""


class SQLiteBackend(BackendProvider):
    """SQLite + sqlite-vec backend for local/on-device memory.

    Config keys:
        path: Path to SQLite database file (default: ~/.memledger/memory.db)
        dimensions: Embedding dimensions (default: 1024)
    """

    def __init__(self) -> None:
        self._conn = None
        self._dimensions: int = 1024
        self._path: str = "~/.memledger/memory.db"
        self._vec_enabled: bool = False

    async def initialize(self, config: dict[str, Any]) -> None:
        try:
            import aiosqlite
        except ImportError:
            raise ImportError("SQLite backend requires aiosqlite. Install with: pip install engram[sqlite]")

        self._dimensions = config.get("dimensions", 1024)
        self._path = config.get("path", "~/.memledger/memory.db")

        # Expand user home and ensure directory exists
        db_path = Path(self._path).expanduser()
        db_path.parent.mkdir(parents=True, exist_ok=True)

        self._conn = await aiosqlite.connect(str(db_path))
        self._conn.row_factory = aiosqlite.Row

        # Load sqlite-vec extension on the worker thread
        try:
            import sqlite_vec

            def _load_vec(conn):
                conn.enable_load_extension(True)
                sqlite_vec.load(conn)

            await self._conn._execute(_load_vec, self._conn._conn)
            self._vec_enabled = True
        except ImportError:
            logger.warning(
                "sqlite-vec not installed. Vector search will not work. Install with: pip install sqlite-vec"
            )
        except Exception as e:
            logger.warning(f"Failed to load sqlite-vec: {e}")

        # Create tables
        await self._conn.executescript(CREATE_TABLES_SQL)

        # Create vector table (sqlite-vec virtual table)
        if self._vec_enabled:
            try:
                await self._conn.execute(
                    f"""
                    CREATE VIRTUAL TABLE IF NOT EXISTS memory_embeddings USING vec0(
                        memory_id TEXT PRIMARY KEY,
                        embedding FLOAT[{self._dimensions}]
                    )
                    """
                )
            except Exception as e:
                logger.warning(f"Could not create vector table: {e}")
                self._vec_enabled = False

        await self._conn.commit()

        logger.info(
            "SQLiteBackend initialized: %s, dimensions=%d",
            str(db_path),
            self._dimensions,
        )

    async def add(self, records: list[MemoryRecord]) -> list[str]:
        if not self._conn:
            raise RuntimeError("Backend not initialized.")

        ids = []
        for record in records:
            metadata = self._merge_typed_fields(record)

            await self._conn.execute(
                """
                INSERT OR REPLACE INTO memories
                    (id, content, record_type, status, namespace, agent_id,
                     user_id, session_id, importance, metadata, created_at,
                     updated_at, access_count, last_accessed_at, success_count,
                     failure_count, supersedes, derived_from,
                     created_by, workflow_id, triggered_by, accessed_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record.id,
                    record.content,
                    record.record_type.value,
                    record.status.value,
                    record.namespace,
                    record.agent_id,
                    record.user_id,
                    record.session_id,
                    record.importance,
                    json.dumps(metadata),
                    record.created_at.isoformat(),
                    record.updated_at.isoformat(),
                    record.access_count,
                    record.last_accessed_at.isoformat() if record.last_accessed_at else None,
                    record.success_count,
                    record.failure_count,
                    record.supersedes,
                    json.dumps(record.derived_from),
                    record.created_by,
                    record.workflow_id,
                    record.triggered_by,
                    json.dumps(record.accessed_by),
                ),
            )

            if record.embedding and self._vec_enabled:
                embedding_blob = self._embedding_to_blob(record.embedding)
                await self._conn.execute(
                    """
                    INSERT OR REPLACE INTO memory_embeddings (memory_id, embedding)
                    VALUES (?, ?)
                    """,
                    (record.id, embedding_blob),
                )

            ids.append(record.id)

        await self._conn.commit()
        return ids

    async def get(self, record_id: str) -> Optional[MemoryRecord]:
        if not self._conn:
            raise RuntimeError("Backend not initialized.")

        cursor = await self._conn.execute("SELECT * FROM memories WHERE id = ?", (record_id,))
        row = await cursor.fetchone()
        if not row:
            return None
        return self._row_to_record(row)

    async def search_vector(
        self,
        embedding: list[float],
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        if not self._conn:
            raise RuntimeError("Backend not initialized.")

        if not self._vec_enabled:
            return await self._search_fallback(top_k, namespace, filters)

        embedding_blob = self._embedding_to_blob(embedding)

        # Default: only return active memories
        where_clauses = ["m.status = 'active'"]
        params: list[Any] = []

        if namespace:
            where_clauses.append("m.namespace LIKE ? || '%'")
            params.append(namespace)

        if filters:
            for key, value in filters.items():
                if key in ("agent_id", "user_id", "session_id", "record_type"):
                    where_clauses.append(f"m.{key} = ?")
                    params.append(value)
                else:
                    where_clauses.append(f"json_extract(m.metadata, '$.{key}') = ?")
                    params.append(json.dumps(value) if isinstance(value, (dict, list)) else value)

        where_sql = ""
        if where_clauses:
            where_sql = "AND " + " AND ".join(where_clauses)

        query = f"""
            SELECT
                m.*,
                vec_distance_cosine(e.embedding, ?) as distance
            FROM memory_embeddings e
            JOIN memories m ON e.memory_id = m.id
            WHERE 1=1 {where_sql}
            ORDER BY distance ASC
            LIMIT ?
        """

        cursor = await self._conn.execute(query, [embedding_blob] + params + [top_k])
        rows = await cursor.fetchall()

        results = []
        for row in rows:
            # distance is the last column
            distance = row["distance"] if "distance" in row.keys() else row[-1]
            score = 1.0 - distance  # Convert distance to similarity
            record = self._row_to_record(row, score=score)
            results.append(record)

        return results

    async def search_text(
        self,
        query: str,
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        if not self._conn:
            raise RuntimeError("Backend not initialized.")

        where_clauses = ["content LIKE '%' || ? || '%'"]
        params: list[Any] = [query]

        if namespace:
            where_clauses.append("namespace LIKE ? || '%'")
            params.append(namespace)

        where_sql = "WHERE " + " AND ".join(where_clauses)

        cursor = await self._conn.execute(
            f"""
            SELECT * FROM memories
            {where_sql}
            ORDER BY updated_at DESC
            LIMIT ?
            """,
            params + [top_k],
        )
        rows = await cursor.fetchall()
        return [self._row_to_record(row) for row in rows]

    async def update(self, record_id: str, **kwargs: Any) -> bool:
        if not self._conn:
            raise RuntimeError("Backend not initialized.")

        set_clauses = ["updated_at = ?"]
        params: list[Any] = [datetime.now(timezone.utc).isoformat()]

        allowed_fields = {
            "content",
            "namespace",
            "metadata",
            "agent_id",
            "user_id",
            "record_type",
            "status",
            "importance",
            "supersedes",
            "created_by",
            "workflow_id",
            "triggered_by",
        }
        for key, value in kwargs.items():
            if key in allowed_fields:
                if key == "metadata":
                    set_clauses.append("metadata = ?")
                    params.append(json.dumps(value))
                else:
                    set_clauses.append(f"{key} = ?")
                    params.append(value)

        params.append(record_id)
        cursor = await self._conn.execute(
            f"UPDATE memories SET {', '.join(set_clauses)} WHERE id = ?",
            params,
        )
        await self._conn.commit()
        return cursor.rowcount > 0

    async def delete(self, record_id: str) -> bool:
        """Soft delete — sets status to 'archived', never physically removes."""
        if not self._conn:
            raise RuntimeError("Backend not initialized.")

        now = datetime.now(timezone.utc).isoformat()
        cursor = await self._conn.execute(
            "UPDATE memories SET status = 'archived', updated_at = ? WHERE id = ?",
            (now, record_id),
        )
        await self._conn.commit()
        return cursor.rowcount > 0

    async def record_access(self, record_ids: list[str], accessed_by: str = None) -> None:
        if not self._conn or not record_ids:
            return
        now = datetime.now(timezone.utc).isoformat()
        placeholders = ",".join("?" * len(record_ids))
        await self._conn.execute(
            f"""
            UPDATE memories
            SET access_count = access_count + 1, last_accessed_at = ?
            WHERE id IN ({placeholders})
            """,
            [now] + record_ids,
        )
        # Append accessed_by agent to the JSON array
        if accessed_by:
            for rid in record_ids:
                row = await self._conn.execute_fetchall("SELECT accessed_by FROM memories WHERE id = ?", (rid,))
                if row:
                    import json as _json

                    current = _json.loads(row[0][0] or "[]")
                    if accessed_by not in current:
                        current.append(accessed_by)
                        await self._conn.execute(
                            "UPDATE memories SET accessed_by = ? WHERE id = ?",
                            (_json.dumps(current), rid),
                        )
        await self._conn.commit()

    async def record_outcome(self, record_id: str, success: bool) -> bool:
        if not self._conn:
            raise RuntimeError("Backend not initialized.")
        col = "success_count" if success else "failure_count"
        cursor = await self._conn.execute(
            f"UPDATE memories SET {col} = {col} + 1 WHERE id = ?",
            (record_id,),
        )
        await self._conn.commit()
        return cursor.rowcount > 0

    async def close(self) -> None:
        if self._conn:
            await self._conn.close()
            self._conn = None

    async def health_check(self) -> bool:
        if not self._conn:
            return False
        try:
            cursor = await self._conn.execute("SELECT 1")
            await cursor.fetchone()
            return True
        except Exception:
            return False

    async def list_namespaces(self) -> list[str]:
        if not self._conn:
            return []
        cursor = await self._conn.execute("SELECT DISTINCT namespace FROM memories ORDER BY namespace")
        rows = await cursor.fetchall()
        return [row["namespace"] for row in rows]

    # ── Batch APIs ───────────────────────────────────────────

    async def get_by_status(self, status: str, namespace=None) -> list[MemoryRecord]:
        if not self._conn:
            return []
        where = "WHERE status = ?"
        params: list[Any] = [status]
        if namespace:
            where += " AND namespace LIKE ? || '%'"
            params.append(namespace)
        cursor = await self._conn.execute(f"SELECT * FROM memories {where} ORDER BY created_at DESC LIMIT 1000", params)
        rows = await cursor.fetchall()
        return [self._row_to_record(dict(r)) for r in rows]

    async def get_by_session(self, session_id: str) -> list[MemoryRecord]:
        if not self._conn:
            return []
        cursor = await self._conn.execute(
            "SELECT * FROM memories WHERE session_id = ? ORDER BY created_at LIMIT 1000",
            (session_id,),
        )
        rows = await cursor.fetchall()
        return [self._row_to_record(dict(r)) for r in rows]

    async def get_by_timerange(self, start, end, namespace=None) -> list[MemoryRecord]:
        if not self._conn:
            return []
        where = "WHERE created_at >= ? AND created_at <= ?"
        start_str = start.isoformat() if hasattr(start, "isoformat") else str(start)
        end_str = end.isoformat() if hasattr(end, "isoformat") else str(end)
        params: list[Any] = [start_str, end_str]
        if namespace:
            where += " AND namespace LIKE ? || '%'"
            params.append(namespace)
        cursor = await self._conn.execute(f"SELECT * FROM memories {where} ORDER BY created_at LIMIT 1000", params)
        rows = await cursor.fetchall()
        return [self._row_to_record(dict(r)) for r in rows]

    async def get_stale(self, days: int = 30, min_access: int = 0, namespace=None) -> list[MemoryRecord]:
        if not self._conn:
            return []
        from datetime import timedelta

        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        where = "WHERE status = 'active' AND (last_accessed_at IS NULL OR last_accessed_at < ?) AND access_count <= ?"
        params: list[Any] = [cutoff, min_access]
        if namespace:
            where += " AND namespace LIKE ? || '%'"
            params.append(namespace)
        cursor = await self._conn.execute(f"SELECT * FROM memories {where} ORDER BY created_at LIMIT 1000", params)
        rows = await cursor.fetchall()
        return [self._row_to_record(dict(r)) for r in rows]

    async def bulk_update_status(self, record_ids: list[str], status: str) -> int:
        if not self._conn or not record_ids:
            return 0
        placeholders = ",".join("?" * len(record_ids))
        now = datetime.now(timezone.utc).isoformat()
        cursor = await self._conn.execute(
            f"UPDATE memories SET status = ?, updated_at = ? WHERE id IN ({placeholders})",
            [status, now, *record_ids],
        )
        await self._conn.commit()
        return cursor.rowcount

    async def bulk_archive(self, record_ids: list[str]) -> int:
        return await self.bulk_update_status(record_ids, "archived")

    async def stats(self, namespace: str | None = None) -> dict[str, Any]:
        if not self._conn:
            return {}

        where = ""
        params: list[Any] = []
        if namespace:
            where = "WHERE namespace LIKE ? || '%'"
            params = [namespace]

        # Total count
        cursor = await self._conn.execute(f"SELECT COUNT(*) as cnt FROM memories {where}", params)
        total = (await cursor.fetchone())["cnt"]

        # By record type
        cursor = await self._conn.execute(
            f"SELECT record_type, COUNT(*) as cnt FROM memories {where} GROUP BY record_type",
            params,
        )
        by_type = {row["record_type"]: row["cnt"] for row in await cursor.fetchall()}

        # By namespace
        cursor = await self._conn.execute(
            f"SELECT namespace, COUNT(*) as cnt FROM memories {where} GROUP BY namespace ORDER BY cnt DESC LIMIT 20",
            params,
        )
        by_ns = {row["namespace"]: row["cnt"] for row in await cursor.fetchall()}

        # Namespaces list
        cursor = await self._conn.execute(
            f"SELECT DISTINCT namespace FROM memories {where} ORDER BY namespace",
            params,
        )
        ns_list = [row["namespace"] for row in await cursor.fetchall()]

        # Time range
        cursor = await self._conn.execute(
            f"SELECT MIN(created_at) as oldest, MAX(created_at) as newest FROM memories {where}",
            params,
        )
        time_row = await cursor.fetchone()

        # Most accessed
        cursor = await self._conn.execute(
            f"SELECT id FROM memories {where} ORDER BY access_count DESC LIMIT 5",
            params,
        )
        top_ids = [row["id"] for row in await cursor.fetchall()]

        return {
            "total_count": total or 0,
            "namespaces": ns_list,
            "by_record_type": by_type,
            "by_namespace": by_ns,
            "avg_success_rate": None,  # simplified for SQLite
            "most_accessed": top_ids,
            "oldest_memory": time_row["oldest"] if time_row else None,
            "newest_memory": time_row["newest"] if time_row else None,
        }

    async def _search_fallback(
        self,
        top_k: int,
        namespace: Optional[str],
        filters: Optional[dict[str, Any]],
    ) -> list[MemoryRecord]:
        """Fallback search when sqlite-vec is not available. Returns by recency."""
        where_clauses = ["status = 'active'"]
        params: list[Any] = []

        if namespace:
            where_clauses.append("namespace LIKE ? || '%'")
            params.append(namespace)

        if filters:
            for key, value in filters.items():
                if key in ("agent_id", "user_id", "session_id", "record_type"):
                    where_clauses.append(f"{key} = ?")
                    params.append(value)

        where_sql = ""
        if where_clauses:
            where_sql = "WHERE " + " AND ".join(where_clauses)

        cursor = await self._conn.execute(
            f"SELECT * FROM memories {where_sql} ORDER BY updated_at DESC LIMIT ?",
            params + [top_k],
        )
        rows = await cursor.fetchall()
        return [self._row_to_record(row) for row in rows]

    # ── Helpers ──────────────────────────────────────────────

    def _embedding_to_blob(self, embedding: list[float]) -> bytes:
        """Convert embedding list to bytes for sqlite-vec."""
        return struct.pack(f"{len(embedding)}f", *embedding)

    def _merge_typed_fields(self, record: MemoryRecord) -> dict[str, Any]:
        """Merge typed record extra fields into metadata."""
        from memledger.models import EpisodicRecord, ProceduralRecord, SemanticRecord

        metadata = dict(record.metadata)

        if isinstance(record, EpisodicRecord):
            typed = {}
            if record.event_time:
                typed["event_time"] = record.event_time.isoformat()
            if record.duration_ms is not None:
                typed["duration_ms"] = record.duration_ms
            if record.outcome:
                typed["outcome"] = record.outcome
            if record.actors:
                typed["actors"] = record.actors
            if typed:
                metadata["_typed"] = typed
        elif isinstance(record, ProceduralRecord):
            typed = {}
            if record.steps:
                typed["steps"] = record.steps
            if record.preconditions:
                typed["preconditions"] = record.preconditions
            if record.tools_required:
                typed["tools_required"] = record.tools_required
            if typed:
                metadata["_typed"] = typed
        elif isinstance(record, SemanticRecord):
            typed = {}
            if record.source:
                typed["source"] = record.source
            if typed:
                metadata["_typed"] = typed

        # Store trust-layer fields in _typed for all record types (sqlite has no dedicated columns)
        if "_typed" not in metadata:
            metadata["_typed"] = {}
        if record.confidence != 0.5:
            metadata["_typed"]["confidence"] = record.confidence
        if record.turn_context:
            metadata["_typed"]["turn_context"] = record.turn_context
        if record.hedged:
            metadata["_typed"]["hedged"] = record.hedged
        if not metadata["_typed"]:
            del metadata["_typed"]

        return metadata

    def _row_to_record(self, row: Any, score: float | None = None) -> MemoryRecord:
        metadata = row["metadata"]
        if isinstance(metadata, str):
            metadata = json.loads(metadata)

        typed_data = metadata.pop("_typed", {}) if metadata else {}
        record_type = row["record_type"] if "record_type" in row.keys() else "semantic"

        # Helper for sqlite3.Row which doesn't support .get()
        def _get(key, default=None):
            try:
                val = row[key]
                return val if val is not None else default
            except (IndexError, KeyError):
                return default

        # Parse derived_from
        derived_from_raw = _get("derived_from", "[]")
        if isinstance(derived_from_raw, str):
            derived_from = json.loads(derived_from_raw)
        else:
            derived_from = derived_from_raw or []

        base_kwargs = dict(
            id=row["id"],
            content=row["content"],
            record_type=record_type,
            status=_get("status", "active"),
            namespace=row["namespace"],
            agent_id=row["agent_id"],
            user_id=row["user_id"],
            session_id=row["session_id"],
            importance=_get("importance", 0.5),
            metadata=metadata or {},
            score=score,
            supersedes=_get("supersedes"),
            derived_from=derived_from,
            access_count=row["access_count"] or 0,
            success_count=row["success_count"] or 0,
            failure_count=row["failure_count"] or 0,
            created_by=_get("created_by"),
            workflow_id=_get("workflow_id"),
            triggered_by=_get("triggered_by"),
            accessed_by=json.loads(_get("accessed_by", "[]"))
            if isinstance(_get("accessed_by", "[]"), str)
            else _get("accessed_by", []),
            confidence=typed_data.get("confidence", 0.5) or 0.5,
            turn_context=typed_data.get("turn_context"),
            hedged=typed_data.get("hedged", False) or False,
        )

        # Parse datetime strings
        if row["created_at"]:
            base_kwargs["created_at"] = datetime.fromisoformat(row["created_at"])
        if row["updated_at"]:
            base_kwargs["updated_at"] = datetime.fromisoformat(row["updated_at"])
        if row["last_accessed_at"]:
            base_kwargs["last_accessed_at"] = datetime.fromisoformat(row["last_accessed_at"])

        if record_type == "episodic":
            from memledger.models import EpisodicRecord

            return EpisodicRecord(
                **base_kwargs,
                event_time=typed_data.get("event_time"),
                duration_ms=typed_data.get("duration_ms"),
                outcome=typed_data.get("outcome"),
                actors=typed_data.get("actors", []),
            )
        elif record_type == "procedural":
            from memledger.models import ProceduralRecord

            return ProceduralRecord(
                **base_kwargs,
                steps=typed_data.get("steps", []),
                preconditions=typed_data.get("preconditions", []),
                tools_required=typed_data.get("tools_required", []),
            )
        elif record_type == "semantic":
            from memledger.models import SemanticRecord

            return SemanticRecord(
                **base_kwargs,
                source=typed_data.get("source"),
            )
        else:
            return MemoryRecord(**base_kwargs)
