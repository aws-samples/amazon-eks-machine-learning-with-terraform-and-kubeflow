"""PostgreSQL + pgvector backend provider.

Compatible with kagent's existing PostgreSQL instance.
Requires: pip install engram[pgvector]
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from memledger.backends.base import BackendProvider
from memledger.models import MemoryRecord

logger = logging.getLogger(__name__)

# SQL for table creation — matches kagent issue #1256 schema direction
CREATE_EXTENSION_SQL = "CREATE EXTENSION IF NOT EXISTS vector;"

CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS agent_memory (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'semantic',
    status TEXT NOT NULL DEFAULT 'active',
    embedding vector({dimensions}),
    namespace TEXT NOT NULL DEFAULT '/',
    agent_id TEXT,
    user_id TEXT,
    session_id TEXT,
    importance REAL DEFAULT 0.5,
    metadata JSONB DEFAULT '{{}}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    access_count INTEGER DEFAULT 0,
    last_accessed_at TIMESTAMPTZ,
    success_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0,
    supersedes TEXT,
    derived_from TEXT[],
    created_by TEXT,
    workflow_id TEXT,
    triggered_by TEXT,
    accessed_by TEXT[] DEFAULT ARRAY[]::TEXT[],
    confidence REAL DEFAULT 0.5,
    turn_context TEXT,
    hedged BOOLEAN DEFAULT FALSE
);
"""

CREATE_INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_agent_memory_embedding
    ON agent_memory USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 200);

CREATE INDEX IF NOT EXISTS idx_agent_memory_namespace
    ON agent_memory (namespace text_pattern_ops);

CREATE INDEX IF NOT EXISTS idx_agent_memory_agent_id
    ON agent_memory (agent_id);

CREATE INDEX IF NOT EXISTS idx_agent_memory_record_type
    ON agent_memory (record_type);

CREATE INDEX IF NOT EXISTS idx_agent_memory_metadata
    ON agent_memory USING gin (metadata);

CREATE INDEX IF NOT EXISTS idx_agent_memory_status
    ON agent_memory (status);
"""

# Migrations for existing tables
MIGRATIONS_SQL = """
DO $$
BEGIN
    -- Add record_type column
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = '{table}' AND column_name = 'record_type'
    ) THEN
        ALTER TABLE {table} ADD COLUMN record_type TEXT NOT NULL DEFAULT 'semantic';
        CREATE INDEX IF NOT EXISTS idx_agent_memory_record_type ON {table} (record_type);
    END IF;

    -- Add scoring columns
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = '{table}' AND column_name = 'access_count'
    ) THEN
        ALTER TABLE {table} ADD COLUMN access_count INTEGER DEFAULT 0;
        ALTER TABLE {table} ADD COLUMN last_accessed_at TIMESTAMPTZ;
        ALTER TABLE {table} ADD COLUMN success_count INTEGER DEFAULT 0;
        ALTER TABLE {table} ADD COLUMN failure_count INTEGER DEFAULT 0;
    END IF;

    -- Add lifecycle columns
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = '{table}' AND column_name = 'status'
    ) THEN
        ALTER TABLE {table} ADD COLUMN status TEXT NOT NULL DEFAULT 'active';
        ALTER TABLE {table} ADD COLUMN importance REAL DEFAULT 0.5;
        ALTER TABLE {table} ADD COLUMN supersedes TEXT;
        ALTER TABLE {table} ADD COLUMN derived_from TEXT[] DEFAULT ARRAY[]::TEXT[];
        CREATE INDEX IF NOT EXISTS idx_agent_memory_status ON {table} (status);
    END IF;

    -- Add provenance columns
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = '{table}' AND column_name = 'created_by'
    ) THEN
        ALTER TABLE {table} ADD COLUMN created_by TEXT;
        ALTER TABLE {table} ADD COLUMN workflow_id TEXT;
        ALTER TABLE {table} ADD COLUMN triggered_by TEXT;
        ALTER TABLE {table} ADD COLUMN accessed_by TEXT[] DEFAULT ARRAY[]::TEXT[];
    END IF;

    -- Add trust-layer columns (F1)
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = '{table}' AND column_name = 'confidence'
    ) THEN
        ALTER TABLE {table} ADD COLUMN confidence REAL DEFAULT 0.5;
        ALTER TABLE {table} ADD COLUMN turn_context TEXT;
        ALTER TABLE {table} ADD COLUMN hedged BOOLEAN DEFAULT FALSE;
    END IF;
END $$;
"""


class PgVectorBackend(BackendProvider):
    """PostgreSQL + pgvector backend.

    Config keys:
        host: PostgreSQL host (default: localhost)
        port: PostgreSQL port (default: 5432)
        database: Database name (default: kagent)
        user: Username
        password: Password
        connection_string: Full DSN (overrides host/port/database/user/password)
        pool_min_size: Min pool connections (default: 2)
        pool_max_size: Max pool connections (default: 10)
        dimensions: Vector dimensions (default: 1024)
        table_name: Table name (default: agent_memory)
    """

    def __init__(self) -> None:
        self._pool = None
        self._dimensions: int = 1024
        self._table: str = "agent_memory"

    async def initialize(self, config: dict[str, Any]) -> None:
        try:
            import asyncpg
        except ImportError:
            raise ImportError("pgvector backend requires asyncpg. Install with: pip install engram[pgvector]")

        self._dimensions = config.get("dimensions", 1024)
        self._table = config.get("table_name", "agent_memory")

        # Build connection string
        dsn = config.get("connection_string")
        if not dsn:
            host = config.get("host", "localhost")
            port = config.get("port", 5432)
            database = config.get("database", "kagent")
            user = config.get("user", "postgres")
            password = config.get("password", "")
            dsn = f"postgresql://{user}:{password}@{host}:{port}/{database}"

        self._pool = await asyncpg.create_pool(
            dsn,
            min_size=config.get("pool_min_size", 2),
            max_size=config.get("pool_max_size", 10),
        )

        # Register pgvector type codec — handle concurrent initialization gracefully
        async with self._pool.acquire() as conn:
            try:
                await conn.execute("CREATE EXTENSION IF NOT EXISTS vector;")
            except Exception:
                pass  # Extension already exists (concurrent init race)

            # Create table (with record_type column)
            await conn.execute(CREATE_TABLE_SQL.format(dimensions=self._dimensions))
            await conn.execute(CREATE_INDEX_SQL)

            # Run migrations for existing tables
            try:
                await conn.execute(MIGRATIONS_SQL.format(table=self._table))
            except Exception:
                pass  # Migrations already applied

        logger.info(
            "PgVectorBackend initialized: %s, dimensions=%d",
            dsn.split("@")[-1] if "@" in dsn else dsn,  # hide credentials
            self._dimensions,
        )

    async def add(self, records: list[MemoryRecord]) -> list[str]:
        if not self._pool:
            raise RuntimeError("Backend not initialized. Call initialize() first.")

        ids = []
        async with self._pool.acquire() as conn:
            for record in records:
                embedding_str = "[" + ",".join(str(x) for x in record.embedding) + "]" if record.embedding else None

                # Serialize typed record extra fields into metadata
                metadata = self._merge_typed_fields(record)

                await conn.execute(
                    f"""
                    INSERT INTO {self._table}
                        (id, content, record_type, status, embedding, namespace,
                         agent_id, user_id, session_id, importance, metadata,
                         created_at, updated_at, supersedes, derived_from,
                         created_by, workflow_id, triggered_by, accessed_by,
                         confidence, turn_context, hedged)
                    VALUES ($1, $2, $3, $4, $5::vector, $6, $7, $8, $9, $10,
                            $11::jsonb, $12, $13, $14, $15, $16, $17, $18, $19,
                            $20, $21, $22)
                    ON CONFLICT (id) DO UPDATE SET
                        content = EXCLUDED.content,
                        record_type = EXCLUDED.record_type,
                        status = EXCLUDED.status,
                        embedding = EXCLUDED.embedding,
                        importance = EXCLUDED.importance,
                        metadata = EXCLUDED.metadata,
                        updated_at = EXCLUDED.updated_at,
                        supersedes = EXCLUDED.supersedes,
                        derived_from = EXCLUDED.derived_from,
                        created_by = EXCLUDED.created_by,
                        workflow_id = EXCLUDED.workflow_id,
                        triggered_by = EXCLUDED.triggered_by,
                        confidence = EXCLUDED.confidence,
                        turn_context = EXCLUDED.turn_context,
                        hedged = EXCLUDED.hedged
                    """,
                    record.id,
                    record.content,
                    record.record_type.value,
                    record.status.value,
                    embedding_str,
                    record.namespace,
                    record.agent_id,
                    record.user_id,
                    record.session_id,
                    record.importance,
                    json.dumps(metadata),
                    record.created_at,
                    record.updated_at,
                    record.supersedes,
                    record.derived_from,
                    record.created_by,
                    record.workflow_id,
                    record.triggered_by,
                    record.accessed_by,
                    record.confidence,
                    record.turn_context,
                    record.hedged,
                )
                ids.append(record.id)
        return ids

    async def get(self, record_id: str) -> Optional[MemoryRecord]:
        if not self._pool:
            raise RuntimeError("Backend not initialized.")

        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(f"SELECT * FROM {self._table} WHERE id = $1", record_id)
            if not row:
                return None
            return self._row_to_record(row)

    async def search_vector(
        self,
        embedding: list[float],
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        if not self._pool:
            raise RuntimeError("Backend not initialized.")

        embedding_str = "[" + ",".join(str(x) for x in embedding) + "]"

        # Default: only return active memories
        where_clauses = [f"status = ${3}"]
        params: list[Any] = [embedding_str, top_k, "active"]
        param_idx = 4

        if namespace:
            # Prefix match: namespace='/incidents' matches '/incidents/pod-crash/...'
            where_clauses.append(f"namespace LIKE ${param_idx} || '%'")
            params.append(namespace)
            param_idx += 1

        if filters:
            for key, value in filters.items():
                if key in ("agent_id", "user_id", "session_id", "record_type"):
                    where_clauses.append(f"{key} = ${param_idx}")
                    params.append(value)
                    param_idx += 1
                else:
                    # JSONB metadata filter
                    where_clauses.append(f"metadata @> ${param_idx}::jsonb")
                    params.append(json.dumps({key: value}))
                    param_idx += 1

        where_sql = ""
        if where_clauses:
            where_sql = "WHERE " + " AND ".join(where_clauses)

        query = f"""
            SELECT *,
                   1 - (embedding <=> $1::vector) AS score
            FROM {self._table}
            {where_sql}
            ORDER BY embedding <=> $1::vector
            LIMIT $2
        """

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, *params)
            return [self._row_to_record(row, score=row.get("score")) for row in rows]

    async def search_text(
        self,
        query: str,
        top_k: int = 5,
        namespace: Optional[str] = None,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[MemoryRecord]:
        """Basic text search using PostgreSQL ILIKE. For full-text, use OpenSearch."""
        if not self._pool:
            raise RuntimeError("Backend not initialized.")

        where_clauses = ["content ILIKE '%' || $1 || '%'"]
        params: list[Any] = [query, top_k]
        param_idx = 3

        if namespace:
            where_clauses.append(f"namespace LIKE ${param_idx} || '%'")
            params.append(namespace)
            param_idx += 1

        where_sql = "WHERE " + " AND ".join(where_clauses)

        sql = f"""
            SELECT * FROM {self._table}
            {where_sql}
            ORDER BY updated_at DESC
            LIMIT $2
        """

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
            return [self._row_to_record(row) for row in rows]

    async def update(self, record_id: str, **kwargs: Any) -> bool:
        if not self._pool:
            raise RuntimeError("Backend not initialized.")

        set_clauses = ["updated_at = NOW()"]
        params: list[Any] = []
        param_idx = 1

        allowed_fields = {
            "content",
            "namespace",
            "metadata",
            "agent_id",
            "user_id",
            "record_type",
            "status",
            "importance",
            "supersedes",
        }
        for key, value in kwargs.items():
            if key in allowed_fields:
                if key == "metadata":
                    set_clauses.append(f"metadata = ${param_idx}::jsonb")
                    params.append(json.dumps(value))
                else:
                    set_clauses.append(f"{key} = ${param_idx}")
                    params.append(value)
                param_idx += 1

        params.append(record_id)
        sql = f"""
            UPDATE {self._table}
            SET {", ".join(set_clauses)}
            WHERE id = ${param_idx}
        """

        async with self._pool.acquire() as conn:
            result = await conn.execute(sql, *params)
            return result.endswith("1")  # "UPDATE 1" means found

    async def delete(self, record_id: str) -> bool:
        """Soft delete — sets status to 'archived', never physically removes."""
        if not self._pool:
            raise RuntimeError("Backend not initialized.")

        async with self._pool.acquire() as conn:
            result = await conn.execute(
                f"UPDATE {self._table} SET status = 'archived', updated_at = NOW() WHERE id = $1",
                record_id,
            )
            return result.endswith("1")

    async def record_access(self, record_ids: list[str], accessed_by: str = None) -> None:
        """Increment access_count and update last_accessed_at for retrieved records."""
        if not self._pool or not record_ids:
            return
        async with self._pool.acquire() as conn:
            if accessed_by:
                await conn.execute(
                    f"""
                    UPDATE {self._table}
                    SET access_count = access_count + 1,
                        last_accessed_at = NOW(),
                        accessed_by = array_append(
                            COALESCE(accessed_by, ARRAY[]::TEXT[]),
                            CASE WHEN $2 = ANY(COALESCE(accessed_by, ARRAY[]::TEXT[]))
                                 THEN NULL ELSE $2 END
                        )
                    WHERE id = ANY($1)
                    """,
                    record_ids,
                    accessed_by,
                )
            else:
                await conn.execute(
                    f"""
                    UPDATE {self._table}
                    SET access_count = access_count + 1,
                        last_accessed_at = NOW()
                    WHERE id = ANY($1)
                    """,
                    record_ids,
                )

    async def record_outcome(self, record_id: str, success: bool) -> bool:
        """Record a success or failure outcome for a memory.

        Call this after using a memory to track its effectiveness:
            await backend.record_outcome(record_id, success=True)
        """
        if not self._pool:
            raise RuntimeError("Backend not initialized.")
        col = "success_count" if success else "failure_count"
        async with self._pool.acquire() as conn:
            result = await conn.execute(
                f"UPDATE {self._table} SET {col} = {col} + 1 WHERE id = $1",
                record_id,
            )
            return result.endswith("1")

    async def close(self) -> None:
        if self._pool:
            await self._pool.close()
            self._pool = None

    async def health_check(self) -> bool:
        if not self._pool:
            return False
        try:
            async with self._pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
            return True
        except Exception:
            return False

    # ── Batch APIs ──────────────────────────────────────────

    async def get_by_session(self, session_id: str) -> list[MemoryRecord]:
        if not self._pool:
            return []
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                f"SELECT * FROM {self._table} WHERE session_id = $1 ORDER BY created_at LIMIT 1000",
                session_id,
            )
            return [self._row_to_record(row) for row in rows]

    async def get_by_timerange(
        self,
        start,
        end,
        namespace=None,
    ) -> list[MemoryRecord]:
        if not self._pool:
            return []
        where = "WHERE created_at >= $1 AND created_at <= $2"
        params = [start, end]
        if namespace:
            where += " AND namespace LIKE $3 || '%'"
            params.append(namespace)
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                f"SELECT * FROM {self._table} {where} ORDER BY created_at LIMIT 1000",
                *params,
            )
            return [self._row_to_record(row) for row in rows]

    async def get_stale(
        self,
        days: int = 30,
        min_access: int = 0,
        namespace=None,
    ) -> list[MemoryRecord]:
        if not self._pool:
            return []
        where = """WHERE status = 'active'
            AND (last_accessed_at IS NULL OR last_accessed_at < NOW() - $1 * INTERVAL '1 day')
            AND access_count <= $2"""
        params: list = [days, min_access]
        if namespace:
            where += " AND namespace LIKE $3 || '%'"
            params.append(namespace)
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                f"SELECT * FROM {self._table} {where} ORDER BY created_at LIMIT 1000",
                *params,
            )
            return [self._row_to_record(row) for row in rows]

    async def get_by_status(self, status: str, namespace=None) -> list[MemoryRecord]:
        if not self._pool:
            return []
        where = "WHERE status = $1"
        params = [status]
        if namespace:
            where += " AND namespace LIKE $2 || '%'"
            params.append(namespace)
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                f"SELECT * FROM {self._table} {where} ORDER BY updated_at DESC LIMIT 1000",
                *params,
            )
            return [self._row_to_record(row) for row in rows]

    async def bulk_update_status(self, record_ids: list[str], status: str) -> int:
        if not self._pool or not record_ids:
            return 0
        async with self._pool.acquire() as conn:
            result = await conn.execute(
                f"UPDATE {self._table} SET status = $1, updated_at = NOW() WHERE id = ANY($2)",
                status,
                record_ids,
            )
            # result like "UPDATE 5"
            return int(result.split()[-1]) if result else 0

    async def bulk_archive(self, record_ids: list[str]) -> int:
        return await self.bulk_update_status(record_ids, "archived")

    async def list_namespaces(self) -> list[str]:
        """List all distinct namespaces."""
        if not self._pool:
            return []
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(f"SELECT DISTINCT namespace FROM {self._table} ORDER BY namespace")
            return [row["namespace"] for row in rows]

    async def stats(self, namespace: str | None = None) -> dict[str, Any]:
        """Return memory statistics, optionally scoped to a namespace."""
        if not self._pool:
            return {}

        where = ""
        params: list[Any] = []
        if namespace:
            where = "WHERE namespace LIKE $1 || '%'"
            params = [namespace]

        async with self._pool.acquire() as conn:
            # Total count
            total = await conn.fetchval(f"SELECT COUNT(*) FROM {self._table} {where}", *params)

            # By record type
            type_rows = await conn.fetch(
                f"SELECT record_type, COUNT(*) as cnt FROM {self._table} {where} GROUP BY record_type",
                *params,
            )
            by_type = {row["record_type"]: row["cnt"] for row in type_rows}

            # By namespace (top 20)
            ns_rows = await conn.fetch(
                f"SELECT namespace, COUNT(*) as cnt FROM {self._table} {where} GROUP BY namespace ORDER BY cnt DESC LIMIT 20",
                *params,
            )
            by_ns = {row["namespace"]: row["cnt"] for row in ns_rows}

            # Namespaces list
            ns_list = await conn.fetch(
                f"SELECT DISTINCT namespace FROM {self._table} {where} ORDER BY namespace",
                *params,
            )

            # Average success rate (only for records with outcomes)
            avg_sr = await conn.fetchval(
                f"""SELECT AVG(
                    CASE WHEN success_count + failure_count > 0
                    THEN success_count::float / (success_count + failure_count)
                    ELSE NULL END
                ) FROM {self._table} {where}""",
                *params,
            )

            # Most accessed (top 5)
            top_rows = await conn.fetch(
                f"SELECT id FROM {self._table} {where} ORDER BY access_count DESC LIMIT 5",
                *params,
            )

            # Time range
            time_row = await conn.fetchrow(
                f"SELECT MIN(created_at) as oldest, MAX(created_at) as newest FROM {self._table} {where}",
                *params,
            )

            return {
                "total_count": total or 0,
                "namespaces": [r["namespace"] for r in ns_list],
                "by_record_type": by_type,
                "by_namespace": by_ns,
                "avg_success_rate": round(avg_sr, 3) if avg_sr else None,
                "most_accessed": [r["id"] for r in top_rows],
                "oldest_memory": time_row["oldest"] if time_row else None,
                "newest_memory": time_row["newest"] if time_row else None,
            }

    def _merge_typed_fields(self, record: MemoryRecord) -> dict[str, Any]:
        """Merge typed record extra fields into metadata for storage.

        Typed fields (e.g. EpisodicRecord.outcome, ProceduralRecord.steps)
        are stored inside the JSONB metadata column under a '_typed' key.
        """
        from memledger.models import EpisodicRecord, ProceduralRecord, SemanticRecord

        metadata = dict(record.metadata)

        if isinstance(record, EpisodicRecord):
            typed = {}
            if record.event_time:
                typed["event_time"] = record.event_time.isoformat()
            if record.duration_ms is not None:
                typed["duration_ms"] = record.duration_ms
            if record.outcome:
                typed["outcome"] = record.outcome
            if record.actors:
                typed["actors"] = record.actors
            if typed:
                metadata["_typed"] = typed
        elif isinstance(record, ProceduralRecord):
            typed = {}
            if record.steps:
                typed["steps"] = record.steps
            if record.preconditions:
                typed["preconditions"] = record.preconditions
            if record.tools_required:
                typed["tools_required"] = record.tools_required
            if typed:
                metadata["_typed"] = typed
        elif isinstance(record, SemanticRecord):
            typed = {}
            if record.confidence is not None:
                typed["confidence"] = record.confidence
            if record.source:
                typed["source"] = record.source
            if typed:
                metadata["_typed"] = typed

        return metadata

    def _row_to_record(self, row: Any, score: float | None = None) -> MemoryRecord:
        metadata = row["metadata"]
        if isinstance(metadata, str):
            metadata = json.loads(metadata)

        # Extract typed fields from metadata and build the right record type
        typed_data = metadata.pop("_typed", {}) if metadata else {}
        record_type = row.get("record_type", "semantic")

        base_kwargs = dict(
            id=row["id"],
            content=row["content"],
            record_type=record_type,
            status=row.get("status", "active"),
            namespace=row["namespace"],
            agent_id=row.get("agent_id"),
            user_id=row.get("user_id"),
            session_id=row.get("session_id"),
            importance=row.get("importance", 0.5) or 0.5,
            metadata=metadata or {},
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            score=score,
            supersedes=row.get("supersedes"),
            derived_from=row.get("derived_from") or [],
            access_count=row.get("access_count", 0) or 0,
            last_accessed_at=row.get("last_accessed_at"),
            success_count=row.get("success_count", 0) or 0,
            failure_count=row.get("failure_count", 0) or 0,
            created_by=row.get("created_by"),
            workflow_id=row.get("workflow_id"),
            triggered_by=row.get("triggered_by"),
            accessed_by=row.get("accessed_by") or [],
            confidence=row.get("confidence", 0.5) or 0.5,
            turn_context=row.get("turn_context"),
            hedged=row.get("hedged", False) or False,
        )

        if record_type == "episodic":
            from memledger.models import EpisodicRecord

            return EpisodicRecord(
                **base_kwargs,
                event_time=typed_data.get("event_time"),
                duration_ms=typed_data.get("duration_ms"),
                outcome=typed_data.get("outcome"),
                actors=typed_data.get("actors", []),
            )
        elif record_type == "procedural":
            from memledger.models import ProceduralRecord

            return ProceduralRecord(
                **base_kwargs,
                steps=typed_data.get("steps", []),
                preconditions=typed_data.get("preconditions", []),
                tools_required=typed_data.get("tools_required", []),
            )
        elif record_type == "semantic":
            from memledger.models import SemanticRecord

            return SemanticRecord(
                **base_kwargs,
                source=typed_data.get("source"),
            )
        else:
            return MemoryRecord(**base_kwargs)
