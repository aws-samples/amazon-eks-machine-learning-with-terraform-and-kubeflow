"""Amazon DynamoDB backend provider.

Key-value store optimized for fast exact lookups, session retrieval,
and lifecycle operations. Does NOT support vector search — use in
multi-backend composition with OpenSearch or pgvector for semantic search.

Requires: pip install engram[dynamodb]

Table design:
  Partition Key: namespace (S)
  Sort Key: id (S)
  GSI-1 (session-index): session_id (S) + created_at (S)
  GSI-2 (status-index): status (S) + updated_at (S)
  TTL attribute: ttl_expiry (N)
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Optional

from memledger.backends.base import BackendProvider
from memledger.models import MemoryRecord

logger = logging.getLogger(__name__)


class DynamoDBBackend(BackendProvider):
    """Amazon DynamoDB backend — fast key-value store for agent memory.

    Strengths: sub-ms lookups, native TTL, batch operations, serverless scaling.
    Limitation: no vector search — use composition with a search backend.

    Config keys:
        table_name: DynamoDB table name (default: engram-memory)
        region: AWS region (default: us-west-2)
        create_table: Whether to create table if missing (default: True)
        ttl_enabled: Enable DynamoDB TTL on ttl_expiry attribute (default: True)
    """

    def __init__(self) -> None:
        self._table = None
        self._table_name: str = "engram-memory"
        self._client = None
        self._resource = None

    async def initialize(self, config: dict[str, Any]) -> None:
        try:
            import boto3
        except ImportError:
            raise ImportError("DynamoDB backend requires boto3. Install with: pip install engram[dynamodb]")

        self._table_name = config.get("table_name", "engram-memory")
        region = config.get("region", "us-west-2")
        create_table = config.get("create_table", True)

        self._resource = boto3.resource("dynamodb", region_name=region)
        self._client = boto3.client("dynamodb", region_name=region)

        if create_table:
            await self._ensure_table()

        self._table = self._resource.Table(self._table_name)

        logger.info("DynamoDBBackend initialized: table=%s, region=%s", self._table_name, region)

    async def _ensure_table(self) -> None:
        """Create table and GSIs if they don't exist."""
        existing = self._client.list_tables()["TableNames"]
        if self._table_name in existing:
            return

        self._client.create_table(
            TableName=self._table_name,
            KeySchema=[
                {"AttributeName": "namespace", "KeyType": "HASH"},
                {"AttributeName": "id", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "namespace", "AttributeType": "S"},
                {"AttributeName": "id", "AttributeType": "S"},
                {"AttributeName": "session_id", "AttributeType": "S"},
                {"AttributeName": "created_at", "AttributeType": "S"},
                {"AttributeName": "status", "AttributeType": "S"},
                {"AttributeName": "updated_at", "AttributeType": "S"},
            ],
            GlobalSecondaryIndexes=[
                {
                    "IndexName": "session-index",
                    "KeySchema": [
                        {"AttributeName": "session_id", "KeyType": "HASH"},
                        {"AttributeName": "created_at", "KeyType": "RANGE"},
                    ],
                    "Projection": {"ProjectionType": "ALL"},
                },
                {
                    "IndexName": "status-index",
                    "KeySchema": [
                        {"AttributeName": "status", "KeyType": "HASH"},
                        {"AttributeName": "updated_at", "KeyType": "RANGE"},
                    ],
                    "Projection": {"ProjectionType": "ALL"},
                },
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Wait for table to be active
        waiter = self._client.get_waiter("table_exists")
        waiter.wait(TableName=self._table_name)

        # Enable TTL
        try:
            self._client.update_time_to_live(
                TableName=self._table_name,
                TimeToLiveSpecification={
                    "Enabled": True,
                    "AttributeName": "ttl_expiry",
                },
            )
        except Exception as e:
            logger.warning(f"Could not enable TTL: {e}")

        logger.info("Created DynamoDB table: %s", self._table_name)

    def _record_to_item(self, record: MemoryRecord) -> dict:
        """Convert MemoryRecord to DynamoDB item."""
        from memledger.models import EpisodicRecord, ProceduralRecord, SemanticRecord

        item = {
            "namespace": record.namespace,
            "id": record.id,
            "content": record.content,
            "record_type": record.record_type.value,
            "status": record.status.value,
            "importance": str(record.importance),
            "created_at": record.created_at.isoformat(),
            "updated_at": record.updated_at.isoformat(),
            "access_count": record.access_count,
            "success_count": record.success_count,
            "failure_count": record.failure_count,
        }

        # Optional fields — DynamoDB doesn't store None/empty well
        if record.agent_id:
            item["agent_id"] = record.agent_id
        if record.user_id:
            item["user_id"] = record.user_id
        if record.session_id:
            item["session_id"] = record.session_id
        if record.last_accessed_at:
            item["last_accessed_at"] = record.last_accessed_at.isoformat()
        if record.supersedes:
            item["supersedes"] = record.supersedes
        if record.derived_from:
            item["derived_from"] = record.derived_from
        if record.created_by:
            item["created_by"] = record.created_by
        if record.workflow_id:
            item["workflow_id"] = record.workflow_id
        if record.triggered_by:
            item["triggered_by"] = record.triggered_by
        if record.accessed_by:
            item["accessed_by"] = record.accessed_by
        if record.metadata:
            item["metadata"] = json.dumps(record.metadata)
        if record.embedding:
            # Store embedding as JSON string (not used for search in DynamoDB)
            item["embedding"] = json.dumps(record.embedding)

        # Typed fields
        if isinstance(record, EpisodicRecord):
            typed = {}
            if record.event_time:
                typed["event_time"] = record.event_time.isoformat()
            if record.duration_ms is not None:
                typed["duration_ms"] = record.duration_ms
            if record.outcome:
                typed["outcome"] = record.outcome
            if record.actors:
                typed["actors"] = record.actors
            if typed:
                item["_typed"] = json.dumps(typed)
        elif isinstance(record, ProceduralRecord):
            typed = {}
            if record.steps:
                typed["steps"] = record.steps
            if record.preconditions:
                typed["preconditions"] = record.preconditions
            if record.tools_required:
                typed["tools_required"] = record.tools_required
            if typed:
                item["_typed"] = json.dumps(typed)
        elif isinstance(record, SemanticRecord):
            typed = {}
            if record.confidence is not None:
                typed["confidence"] = record.confidence
            if record.source:
                typed["source"] = record.source
            if typed:
                item["_typed"] = json.dumps(typed)

        return item

    def _item_to_record(self, item: dict, score: float | None = None) -> MemoryRecord:
        """Convert DynamoDB item to MemoryRecord."""
        metadata = json.loads(item.get("metadata", "{}"))
        typed_data = json.loads(item.get("_typed", "{}"))
        record_type = item.get("record_type", "semantic")

        base_kwargs = dict(
            id=item["id"],
            content=item["content"],
            record_type=record_type,
            status=item.get("status", "active"),
            namespace=item["namespace"],
            agent_id=item.get("agent_id"),
            user_id=item.get("user_id"),
            session_id=item.get("session_id"),
            importance=float(item.get("importance", 0.5)),
            metadata=metadata,
            score=score,
            supersedes=item.get("supersedes"),
            derived_from=item.get("derived_from", []),
            created_by=item.get("created_by"),
            workflow_id=item.get("workflow_id"),
            triggered_by=item.get("triggered_by"),
            accessed_by=item.get("accessed_by", []),
            access_count=int(item.get("access_count", 0)),
            success_count=int(item.get("success_count", 0)),
            failure_count=int(item.get("failure_count", 0)),
        )

        if item.get("created_at"):
            base_kwargs["created_at"] = datetime.fromisoformat(item["created_at"])
        if item.get("updated_at"):
            base_kwargs["updated_at"] = datetime.fromisoformat(item["updated_at"])
        if item.get("last_accessed_at"):
            base_kwargs["last_accessed_at"] = datetime.fromisoformat(item["last_accessed_at"])

        if record_type == "episodic":
            from memledger.models import EpisodicRecord

            return EpisodicRecord(
                **base_kwargs,
                event_time=typed_data.get("event_time"),
                duration_ms=typed_data.get("duration_ms"),
                outcome=typed_data.get("outcome"),
                actors=typed_data.get("actors", []),
            )
        elif record_type == "procedural":
            from memledger.models import ProceduralRecord

            return ProceduralRecord(
                **base_kwargs,
                steps=typed_data.get("steps", []),
                preconditions=typed_data.get("preconditions", []),
                tools_required=typed_data.get("tools_required", []),
            )
        elif record_type == "semantic":
            from memledger.models import SemanticRecord

            return SemanticRecord(
                **base_kwargs,
                confidence=typed_data.get("confidence"),
                source=typed_data.get("source"),
            )
        else:
            return MemoryRecord(**base_kwargs)

    # ── Core CRUD ────────────────────────────────────────────

    async def add(self, records: list[MemoryRecord]) -> list[str]:
        if not self._table:
            raise RuntimeError("Backend not initialized.")

        ids = []
        with self._table.batch_writer() as batch:
            for record in records:
                item = self._record_to_item(record)
                batch.put_item(Item=item)
                ids.append(record.id)
        return ids

    async def get(self, record_id: str) -> Optional[MemoryRecord]:
        if not self._table:
            raise RuntimeError("Backend not initialized.")

        # Scan with consistent read — 'id' is a reserved word, use expression attribute names
        response = self._table.scan(
            FilterExpression="#rid = :id",
            ExpressionAttributeNames={"#rid": "id"},
            ExpressionAttributeValues={":id": record_id},
            ConsistentRead=True,
        )
        items = response.get("Items", [])
        if not items:
            return None
        return self._item_to_record(items[0])

    async def update(self, record_id: str, **kwargs: Any) -> bool:
        if not self._table:
            raise RuntimeError("Backend not initialized.")

        record = await self.get(record_id)
        if not record:
            return False

        update_expr_parts = ["#updated_at = :updated_at"]
        expr_names = {"#updated_at": "updated_at"}
        expr_values = {":updated_at": datetime.now(timezone.utc).isoformat()}

        allowed = {
            "content",
            "namespace",
            "metadata",
            "agent_id",
            "user_id",
            "record_type",
            "status",
            "importance",
            "supersedes",
            "created_by",
            "workflow_id",
            "triggered_by",
        }

        for key, value in kwargs.items():
            if key in allowed:
                placeholder = f":{key}"
                name_placeholder = f"#{key}"
                if key == "metadata":
                    value = json.dumps(value)
                update_expr_parts.append(f"{name_placeholder} = {placeholder}")
                expr_names[name_placeholder] = key
                expr_values[placeholder] = value

        self._table.update_item(
            Key={"namespace": record.namespace, "id": record_id},
            UpdateExpression="SET " + ", ".join(update_expr_parts),
            ExpressionAttributeNames=expr_names,
            ExpressionAttributeValues=expr_values,
        )
        return True

    async def delete(self, record_id: str) -> bool:
        """Soft delete — sets status to archived."""
        return await self.update(record_id, status="archived")

    async def close(self) -> None:
        self._table = None
        self._client = None
        self._resource = None

    # ── Scoring support ──────────────────────────────────────

    async def record_access(self, record_ids: list[str], accessed_by: str = None) -> None:
        if not self._table:
            return
        now = datetime.now(timezone.utc).isoformat()
        for rid in record_ids:
            record = await self.get(rid)
            if record:
                update_expr = "SET access_count = access_count + :inc, last_accessed_at = :now"
                expr_values = {":inc": 1, ":now": now}
                if accessed_by and accessed_by not in (record.accessed_by or []):
                    update_expr += ", accessed_by = list_append(if_not_exists(accessed_by, :empty), :agent)"
                    expr_values[":empty"] = []
                    expr_values[":agent"] = [accessed_by]
                self._table.update_item(
                    Key={"namespace": record.namespace, "id": rid},
                    UpdateExpression=update_expr,
                    ExpressionAttributeValues=expr_values,
                )

    async def record_outcome(self, record_id: str, success: bool) -> bool:
        if not self._table:
            return False
        record = await self.get(record_id)
        if not record:
            return False
        field = "success_count" if success else "failure_count"
        self._table.update_item(
            Key={"namespace": record.namespace, "id": record_id},
            UpdateExpression=f"SET {field} = {field} + :inc",
            ExpressionAttributeValues={":inc": 1},
        )
        return True

    # ── Introspection ────────────────────────────────────────

    async def health_check(self) -> bool:
        if not self._table:
            return False
        try:
            self._table.table_status
            return True
        except Exception:
            return False

    async def list_namespaces(self) -> list[str]:
        if not self._table:
            return []
        # Scan is expensive but namespaces are the partition key
        response = self._table.scan(
            ProjectionExpression="#ns",
            ExpressionAttributeNames={"#ns": "namespace"},
        )
        namespaces = set()
        for item in response.get("Items", []):
            namespaces.add(item["namespace"])
        # Handle pagination
        while "LastEvaluatedKey" in response:
            response = self._table.scan(
                ProjectionExpression="#ns",
                ExpressionAttributeNames={"#ns": "namespace"},
                ExclusiveStartKey=response["LastEvaluatedKey"],
            )
            for item in response.get("Items", []):
                namespaces.add(item["namespace"])
        return sorted(namespaces)

    async def stats(self, namespace: Optional[str] = None) -> dict[str, Any]:
        """Aggregate counts via Scan. Cheap at small scale; switch to a
        counter table or DynamoDB Streams aggregation at high scale."""
        if not self._table:
            return {}

        scan_kwargs: dict[str, Any] = {
            "ProjectionExpression": "#ns, record_type, #st, success_count, failure_count, access_count",
            "ExpressionAttributeNames": {"#ns": "namespace", "#st": "status"},
        }
        if namespace:
            scan_kwargs["FilterExpression"] = "begins_with(#ns, :ns)"
            scan_kwargs["ExpressionAttributeValues"] = {":ns": namespace}

        items: list[dict[str, Any]] = []
        response = self._table.scan(**scan_kwargs)
        items.extend(response.get("Items", []))
        while "LastEvaluatedKey" in response:
            scan_kwargs["ExclusiveStartKey"] = response["LastEvaluatedKey"]
            response = self._table.scan(**scan_kwargs)
            items.extend(response.get("Items", []))

        by_type: dict[str, int] = {}
        by_status: dict[str, int] = {}
        by_namespace: dict[str, int] = {}
        total_success = 0
        total_failure = 0
        total_access = 0

        for item in items:
            rt = item.get("record_type", "semantic")
            st = item.get("status", "active")
            ns = item.get("namespace", "/")
            by_type[rt] = by_type.get(rt, 0) + 1
            by_status[st] = by_status.get(st, 0) + 1
            by_namespace[ns] = by_namespace.get(ns, 0) + 1
            total_success += int(item.get("success_count", 0) or 0)
            total_failure += int(item.get("failure_count", 0) or 0)
            total_access += int(item.get("access_count", 0) or 0)

        outcomes = total_success + total_failure
        success_rate = (total_success / outcomes) if outcomes > 0 else None

        return {
            "total_count": len(items),
            "by_record_type": by_type,
            "by_status": by_status,
            "by_namespace": dict(sorted(by_namespace.items(), key=lambda x: x[1], reverse=True)[:20]),
            "namespaces": sorted(by_namespace.keys()),
            "total_access_count": total_access,
            "total_success_count": total_success,
            "total_failure_count": total_failure,
            "success_rate": success_rate,
            "backend": "dynamodb",
        }

    # ── Batch APIs ───────────────────────────────────────────

    async def get_by_session(self, session_id: str) -> list[MemoryRecord]:
        if not self._table:
            return []
        response = self._table.query(
            IndexName="session-index",
            KeyConditionExpression="session_id = :sid",
            ExpressionAttributeValues={":sid": session_id},
        )
        return [self._item_to_record(item) for item in response.get("Items", [])]

    async def get_by_status(self, status: str, namespace=None) -> list[MemoryRecord]:
        if not self._table:
            return []
        key_expr = "#status = :status"
        expr_names = {"#status": "status"}
        expr_values = {":status": status}

        filter_expr = None
        if namespace:
            filter_expr = "begins_with(#ns, :ns)"
            expr_names["#ns"] = "namespace"
            expr_values[":ns"] = namespace

        kwargs = dict(
            IndexName="status-index",
            KeyConditionExpression=key_expr,
            ExpressionAttributeNames=expr_names,
            ExpressionAttributeValues=expr_values,
        )
        if filter_expr:
            kwargs["FilterExpression"] = filter_expr

        response = self._table.query(**kwargs)
        return [self._item_to_record(item) for item in response.get("Items", [])]

    async def get_stale(self, days: int = 30, min_access: int = 0, namespace=None) -> list[MemoryRecord]:
        if not self._table:
            return []
        from datetime import timedelta

        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

        filter_parts = [
            "#status = :active",
            "(attribute_not_exists(last_accessed_at) OR last_accessed_at < :cutoff)",
            "access_count <= :min_access",
        ]
        expr_names = {"#status": "status"}
        expr_values = {
            ":active": "active",
            ":cutoff": cutoff,
            ":min_access": min_access,
        }

        if namespace:
            filter_parts.append("begins_with(#ns, :ns)")
            expr_names["#ns"] = "namespace"
            expr_values[":ns"] = namespace

        response = self._table.scan(
            FilterExpression=" AND ".join(filter_parts),
            ExpressionAttributeNames=expr_names,
            ExpressionAttributeValues=expr_values,
        )
        return [self._item_to_record(item) for item in response.get("Items", [])]

    async def get_by_timerange(self, start, end, namespace=None) -> list[MemoryRecord]:
        if not self._table:
            return []
        filter_parts = [
            "created_at >= :start_time",
            "created_at <= :end_time",
        ]
        expr_values = {
            ":start_time": start.isoformat() if hasattr(start, "isoformat") else str(start),
            ":end_time": end.isoformat() if hasattr(end, "isoformat") else str(end),
        }
        expr_names = {}

        if namespace:
            filter_parts.append("begins_with(#ns, :ns)")
            expr_names["#ns"] = "namespace"
            expr_values[":ns"] = namespace

        kwargs = dict(
            FilterExpression=" AND ".join(filter_parts),
            ExpressionAttributeValues=expr_values,
        )
        if expr_names:
            kwargs["ExpressionAttributeNames"] = expr_names

        response = self._table.scan(**kwargs)
        return [self._item_to_record(item) for item in response.get("Items", [])]

    async def bulk_update_status(self, record_ids: list[str], status: str) -> int:
        if not self._table:
            return 0
        count = 0
        now = datetime.now(timezone.utc).isoformat()
        for rid in record_ids:
            record = await self.get(rid)
            if record:
                self._table.update_item(
                    Key={"namespace": record.namespace, "id": rid},
                    UpdateExpression="SET #status = :status, updated_at = :now",
                    ExpressionAttributeNames={"#status": "status"},
                    ExpressionAttributeValues={":status": status, ":now": now},
                )
                count += 1
        return count

    async def bulk_archive(self, record_ids: list[str]) -> int:
        return await self.bulk_update_status(record_ids, "archived")
