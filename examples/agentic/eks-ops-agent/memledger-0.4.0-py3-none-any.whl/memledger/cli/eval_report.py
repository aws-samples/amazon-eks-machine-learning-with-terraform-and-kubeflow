"""Memledger eval-report — turn an eval session's summary.json into charts.

Reads `summary.json` (and optionally `results.json`) from a directory
produced by `engram eval`, and writes:

  - success-rate.png         — bar chart, success rate per configuration
  - latency.png              — grouped bar, p50 / p95 / mean per configuration
  - cost.png                 — bar chart, total USD per configuration (only
                                if any configuration has cost data)
  - chart-report.md          — short markdown report that embeds the charts

Usage:
    engram eval-report --session-dir ./eval-results/eval-20260409-...
    engram eval-report --session-dir <dir> --output ./charts/

Matplotlib is an optional dependency. Install with:
    pip install engram[eval]
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# Tokyo Night palette to match the rest of engram's UI tooling
_BG = "#0f1419"
_PANEL = "#1a1f2e"
_PANEL_2 = "#232938"
_TEXT = "#e6e9ef"
_DIM = "#8b94a8"
_ACCENT = "#7aa2f7"
_ACCENT_2 = "#bb9af7"
_GREEN = "#9ece6a"
_YELLOW = "#e0af68"
_RED = "#f7768e"
_ORANGE = "#ff9e64"

# A consistent color for each common configuration name. Falls back to a
# rotating palette for unknown names.
_CONFIG_COLORS = {
    "no_memory": _DIM,
    "deterministic": _ACCENT,
    "llm": _ACCENT_2,
    "llm_haiku": _GREEN,
    "llm_sonnet": _ACCENT_2,
    "llm_opus": _RED,
    "llm_local": _ORANGE,
}
_FALLBACK_PALETTE = [_ACCENT, _ACCENT_2, _GREEN, _YELLOW, _RED, _ORANGE]


def _color_for(name: str, idx: int) -> str:
    if name in _CONFIG_COLORS:
        return _CONFIG_COLORS[name]
    for k, v in _CONFIG_COLORS.items():
        if name.startswith(k):
            return v
    return _FALLBACK_PALETTE[idx % len(_FALLBACK_PALETTE)]


# ── Data loading ───────────────────────────────────────────────────


@dataclass
class ConfigStats:
    name: str
    reps: int
    success_rate: float
    success_count: int
    failure_count: int
    duration_p50: float
    duration_p95: float
    duration_mean: float
    timeout_count: int
    error_count: int
    cost_total_usd: float | None


def _load_summary(session_dir: Path) -> list[ConfigStats]:
    summary_path = session_dir / "summary.json"
    if not summary_path.exists():
        raise FileNotFoundError(
            f"summary.json not found in {session_dir}. "
            f"Pass --session-dir pointing at an `engram eval` output directory."
        )

    raw = json.loads(summary_path.read_text())
    if not isinstance(raw, list):
        raise ValueError(f"summary.json must be a JSON array; got {type(raw).__name__}")

    stats: list[ConfigStats] = []
    for entry in raw:
        stats.append(
            ConfigStats(
                name=entry.get("config_name", "unknown"),
                reps=int(entry.get("reps", 0)),
                success_rate=float(entry.get("success_rate", 0.0)),
                success_count=int(entry.get("success_count", 0)),
                failure_count=int(entry.get("failure_count", 0)),
                duration_p50=float(entry.get("duration_p50", 0.0)),
                duration_p95=float(entry.get("duration_p95", 0.0)),
                duration_mean=float(entry.get("duration_mean", 0.0)),
                timeout_count=int(entry.get("timeout_count", 0)),
                error_count=int(entry.get("error_count", 0)),
                cost_total_usd=entry.get("cost_total_usd"),
            )
        )
    return stats


# ── Chart styling ──────────────────────────────────────────────────


def _style_axes(ax, title: str, ylabel: str | None = None) -> None:
    ax.set_title(title, color=_TEXT, fontsize=14, fontweight="bold", pad=14)
    if ylabel:
        ax.set_ylabel(ylabel, color=_DIM, fontsize=11)
    ax.tick_params(colors=_DIM, labelsize=10)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(_PANEL_2)
    ax.spines["bottom"].set_color(_PANEL_2)
    ax.set_facecolor(_PANEL)
    ax.yaxis.grid(True, color=_PANEL_2, linewidth=0.7)
    ax.set_axisbelow(True)


def _annotate_bars(ax, bars, fmt: str) -> None:
    for bar in bars:
        h = bar.get_height()
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            h,
            fmt.format(h),
            ha="center",
            va="bottom",
            color=_TEXT,
            fontsize=10,
            fontweight="bold",
        )


# ── Chart writers ──────────────────────────────────────────────────


def _write_success_chart(stats: list[ConfigStats], out_path: Path) -> None:
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5), facecolor=_BG)
    names = [s.name for s in stats]
    rates = [s.success_rate * 100 for s in stats]
    colors = [_color_for(s.name, i) for i, s in enumerate(stats)]

    bars = ax.bar(names, rates, color=colors, edgecolor=_BG, linewidth=1.5)
    _style_axes(ax, "Success rate by configuration", ylabel="success rate (%)")
    ax.set_ylim(0, 110)
    _annotate_bars(ax, bars, "{:.1f}%")

    fig.patch.set_facecolor(_BG)
    fig.tight_layout()
    fig.savefig(out_path, facecolor=_BG, dpi=180)
    plt.close(fig)


def _write_latency_chart(stats: list[ConfigStats], out_path: Path) -> None:
    import matplotlib.pyplot as plt
    import numpy as np

    fig, ax = plt.subplots(figsize=(9, 5), facecolor=_BG)

    names = [s.name for s in stats]
    p50 = [s.duration_p50 for s in stats]
    p95 = [s.duration_p95 for s in stats]
    mean = [s.duration_mean for s in stats]

    x = np.arange(len(names))
    w = 0.27

    p50_bars = ax.bar(x - w, p50, w, label="p50", color=_ACCENT, edgecolor=_BG, linewidth=1.0)
    mean_bars = ax.bar(x, mean, w, label="mean", color=_ACCENT_2, edgecolor=_BG, linewidth=1.0)
    p95_bars = ax.bar(x + w, p95, w, label="p95", color=_YELLOW, edgecolor=_BG, linewidth=1.0)

    _style_axes(ax, "Latency by configuration (seconds)", ylabel="duration (s)")
    ax.set_xticks(x)
    ax.set_xticklabels(names)

    legend = ax.legend(facecolor=_PANEL, edgecolor=_PANEL_2, labelcolor=_TEXT, fontsize=10)
    for text in legend.get_texts():
        text.set_color(_TEXT)

    for bars in (p50_bars, mean_bars, p95_bars):
        _annotate_bars(ax, bars, "{:.1f}s")

    fig.patch.set_facecolor(_BG)
    fig.tight_layout()
    fig.savefig(out_path, facecolor=_BG, dpi=180)
    plt.close(fig)


def _write_cost_chart(stats: list[ConfigStats], out_path: Path) -> bool:
    """Returns True if the chart was written, False if no cost data was present."""
    import matplotlib.pyplot as plt

    has_cost = any(s.cost_total_usd is not None and s.cost_total_usd > 0 for s in stats)
    if not has_cost:
        return False

    fig, ax = plt.subplots(figsize=(8, 5), facecolor=_BG)
    names = [s.name for s in stats]
    costs = [s.cost_total_usd or 0.0 for s in stats]
    colors = [_color_for(s.name, i) for i, s in enumerate(stats)]

    bars = ax.bar(names, costs, color=colors, edgecolor=_BG, linewidth=1.5)
    _style_axes(ax, "Total LLM cost by configuration (USD)", ylabel="USD")
    _annotate_bars(ax, bars, "${:.4f}")

    fig.patch.set_facecolor(_BG)
    fig.tight_layout()
    fig.savefig(out_path, facecolor=_BG, dpi=180)
    plt.close(fig)
    return True


def _write_markdown_report(
    session_dir: Path,
    out_dir: Path,
    stats: list[ConfigStats],
    cost_chart_written: bool,
) -> Path:
    md_path = out_dir / "chart-report.md"
    rows = []
    for s in stats:
        cost = f"${s.cost_total_usd:.4f}" if s.cost_total_usd is not None else "—"
        rows.append(
            f"| {s.name} | {s.reps} | {s.success_rate * 100:.1f}% | "
            f"{s.duration_p50:.1f}s | {s.duration_p95:.1f}s | {s.duration_mean:.1f}s | "
            f"{s.timeout_count} | {s.error_count} | {cost} |"
        )

    images = ["![Success rate](success-rate.png)", "", "![Latency](latency.png)"]
    if cost_chart_written:
        images.extend(["", "![Cost](cost.png)"])

    body = (
        f"# Memledger eval session — chart report\n"
        f"\n"
        f"Source: `{session_dir}`\n"
        f"\n"
        f"## Summary\n"
        f"\n"
        "| Configuration | Reps | Success rate | p50 | p95 | mean | Timeouts | Errors | Cost (USD) |\n"
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|\n"
        + "\n".join(rows)
        + "\n\n## Charts\n\n"
        + "\n".join(images)
        + "\n"
    )

    md_path.write_text(body)
    return md_path


# ── CLI entry point ────────────────────────────────────────────────


def _run_eval_report(args: argparse.Namespace) -> int:
    try:
        import matplotlib  # noqa: F401
    except ImportError:
        print(
            "matplotlib is required for engram eval-report.\nInstall with: pip install engram[eval]",
            file=sys.stderr,
        )
        return 2

    logging.basicConfig(level=logging.INFO, format="%(message)s")

    session_dir = Path(args.session_dir)
    if not session_dir.exists() or not session_dir.is_dir():
        print(f"Not a directory: {session_dir}", file=sys.stderr)
        return 2

    out_dir = Path(args.output) if args.output else session_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    stats = _load_summary(session_dir)
    if not stats:
        print(f"summary.json had no entries in {session_dir}", file=sys.stderr)
        return 1

    success_path = out_dir / "success-rate.png"
    latency_path = out_dir / "latency.png"
    cost_path = out_dir / "cost.png"

    _write_success_chart(stats, success_path)
    _write_latency_chart(stats, latency_path)
    cost_written = _write_cost_chart(stats, cost_path)

    md_path = _write_markdown_report(session_dir, out_dir, stats, cost_written)

    print(f"wrote {success_path}")
    print(f"wrote {latency_path}")
    if cost_written:
        print(f"wrote {cost_path}")
    else:
        print("(skipped cost.png — no cost data in summary.json)")
    print(f"wrote {md_path}")
    return 0


def add_subparsers(subparsers: Any) -> None:
    parser = subparsers.add_parser(
        "eval-report",
        help="Render charts and a summary markdown for an eval session.",
    )
    parser.add_argument(
        "--session-dir",
        "-s",
        required=True,
        help="Directory produced by `engram eval` (contains summary.json).",
    )
    parser.add_argument(
        "--output",
        "-o",
        default=None,
        help="Output directory for charts (default: same as --session-dir).",
    )
    parser.set_defaults(_handler=_run_eval_report)
