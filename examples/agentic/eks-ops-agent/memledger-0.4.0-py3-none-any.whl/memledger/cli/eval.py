"""Memledger evaluation harness — `engram eval`.

The harness is generic and runner-agnostic. It treats any agent runner as an
opaque subprocess that takes a task description and produces files in a
designated output directory. The harness:

  1. Reads a task spec YAML (the agent runner command, success criteria,
     timeouts) and an eval config YAML (the configurations to compare and
     reps per config).
  2. For each (configuration, rep) pair, creates a unique RUN_OUTPUT_DIR,
     sets the configuration's env vars, invokes the runner as a subprocess,
     waits for it to finish, and scores success against the criteria.
  3. Aggregates results across reps per configuration.
  4. Writes per-run records (JSON), a session-level summary (JSON), and a
     human-readable markdown report.

Contract with agent runners
---------------------------
Runners must respect three environment variables:

  RUN_OUTPUT_DIR
      Absolute path to the directory where this run should write its outputs.
      The harness pre-creates the directory before the runner is invoked.
      All success-criteria checks read from this directory after the runner
      exits.

  ENABLE_MEMORY = "true" | "false"
      When "false", the runner should bypass engram entirely (no add, no
      search, no engram process at all). When "true" (or unset), the runner
      uses engram per the loaded config.

  ENGRAM_CONFIG_PATH
      Absolute path to an engram.yaml the runner should pass to
      Memledger.from_config(). Only relevant when ENABLE_MEMORY=true.

The runner should exit with code 0 on success, non-zero on failure.
The harness scores success independently — exit code is informational.

Status: v0.3.1
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import shlex
import statistics
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import yaml

logger = logging.getLogger(__name__)


# ── Result records ─────────────────────────────────────────────────


@dataclass
class RunResult:
    """One invocation of the runner under one configuration."""

    config_name: str
    rep_index: int  # 0-based
    run_id: str
    output_dir: str

    started_at: str
    finished_at: str
    duration_seconds: float

    exit_code: Optional[int]
    timed_out: bool
    timeout_seconds: float

    success: bool
    success_reason: str
    failure_details: Optional[dict[str, Any]] = None

    stdout_tail: str = ""
    stderr_tail: str = ""

    # Optional cost data — populated by the runner via a JSON file at
    # $RUN_OUTPUT_DIR/cost.json if present (the runner is responsible for
    # writing it; the harness only reads it).
    cost: Optional[dict[str, Any]] = None


@dataclass
class ConfigSummary:
    """Aggregated stats for one configuration across all reps."""

    config_name: str
    reps: int
    success_count: int
    failure_count: int
    success_rate: float
    duration_p50: float
    duration_p95: float
    duration_mean: float
    timeout_count: int
    error_count: int  # non-zero exit codes
    cost_total_usd: Optional[float] = None
    cost_total_input_tokens: Optional[int] = None
    cost_total_output_tokens: Optional[int] = None


@dataclass
class SessionResult:
    """Top-level aggregation: all configurations × all reps."""

    session_id: str
    started_at: str
    finished_at: str
    task_spec_path: str
    eval_config_path: str
    total_runs: int
    summaries: list[ConfigSummary] = field(default_factory=list)
    runs: list[RunResult] = field(default_factory=list)


# ── YAML loaders ───────────────────────────────────────────────────


def _load_yaml(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"YAML not found: {p}")
    return yaml.safe_load(p.read_text()) or {}


def _expand_env(text: str) -> str:
    """Expand ${VAR} and ${VAR:default} interpolations."""
    import re

    def repl(m: "re.Match") -> str:
        var = m.group(1)
        if ":" in var:
            name, default = var.split(":", 1)
            return os.environ.get(name, default)
        return os.environ.get(var, m.group(0))

    return re.sub(r"\$\{([^}]+)\}", repl, text)


def _load_yaml_with_env(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"YAML not found: {p}")
    return yaml.safe_load(_expand_env(p.read_text())) or {}


# ── Success scoring ────────────────────────────────────────────────


def _score_files_exist(
    output_dir: Path,
    spec: dict[str, Any],
) -> tuple[bool, str, dict[str, Any]]:
    """files_exist scoring: every required file must exist and be non-empty.

    Spec format:
        type: files_exist
        required_files:
          - climate_data.json
          - trend_analysis.json
          - extreme_events.json
        min_size_bytes: 100   # optional, default 1
    """
    required = spec.get("required_files", [])
    min_size = int(spec.get("min_size_bytes", 1))

    if not required:
        return False, "no required_files in spec", {}

    missing: list[str] = []
    too_small: list[dict[str, Any]] = []
    sizes: dict[str, int] = {}

    for fname in required:
        fpath = output_dir / fname
        if not fpath.exists():
            missing.append(fname)
            continue
        size = fpath.stat().st_size
        sizes[fname] = size
        if size < min_size:
            too_small.append({"file": fname, "size": size, "min_required": min_size})

    if missing:
        return False, f"missing files: {missing}", {"missing": missing, "sizes": sizes}
    if too_small:
        return (
            False,
            f"files too small: {[t['file'] for t in too_small]}",
            {
                "too_small": too_small,
                "sizes": sizes,
            },
        )
    return True, "all required files exist and meet size threshold", {"sizes": sizes}


def _score_files_valid_json(
    output_dir: Path,
    spec: dict[str, Any],
) -> tuple[bool, str, dict[str, Any]]:
    """files_valid_json scoring: every required file must parse as JSON and
    pass an optional non-empty / minimum-length check.

    Spec format:
        type: files_valid_json
        required_files:
          - climate_data.json
        min_records: 10        # optional — file must contain a JSON list/dict
                               # with at least N elements
    """
    required = spec.get("required_files", [])
    min_records = int(spec.get("min_records", 0))

    missing: list[str] = []
    invalid: list[dict[str, Any]] = []
    counts: dict[str, int] = {}

    for fname in required:
        fpath = output_dir / fname
        if not fpath.exists():
            missing.append(fname)
            continue
        try:
            data = json.loads(fpath.read_text())
        except json.JSONDecodeError as e:
            invalid.append({"file": fname, "error": str(e)})
            continue
        n = len(data) if isinstance(data, (list, dict)) else 1
        counts[fname] = n
        if n < min_records:
            invalid.append({"file": fname, "records": n, "min_required": min_records})

    if missing:
        return False, f"missing files: {missing}", {"missing": missing, "counts": counts}
    if invalid:
        return False, f"invalid files: {invalid}", {"invalid": invalid, "counts": counts}
    return True, "all required files parse and meet record threshold", {"counts": counts}


_SCORERS = {
    "files_exist": _score_files_exist,
    "files_valid_json": _score_files_valid_json,
}


def _score_run(
    output_dir: Path,
    success_criteria: dict[str, Any],
) -> tuple[bool, str, dict[str, Any]]:
    """Dispatch on success_criteria.type. Returns (success, reason, details)."""
    kind = success_criteria.get("type")
    scorer = _SCORERS.get(kind)
    if scorer is None:
        return False, f"unknown success criteria type: {kind!r}", {}
    return scorer(output_dir, success_criteria)


# ── Run executor ───────────────────────────────────────────────────


async def _run_one(
    *,
    config_name: str,
    rep_index: int,
    runner_spec: dict[str, Any],
    success_criteria: dict[str, Any],
    config_env: dict[str, str],
    output_root: Path,
    timeout_seconds: float,
    capture_tail_chars: int = 4000,
) -> RunResult:
    """Execute one rep of one configuration. Pure async / subprocess."""
    run_id = f"{config_name}-{rep_index:03d}-{uuid.uuid4().hex[:8]}"
    output_dir = output_root / run_id
    output_dir.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env.update({k: str(v) for k, v in config_env.items()})
    env["RUN_OUTPUT_DIR"] = str(output_dir)
    env["ENGRAM_EVAL_RUN_ID"] = run_id
    env["ENGRAM_EVAL_CONFIG"] = config_name

    cmd = runner_spec.get("command")
    if not cmd:
        raise ValueError("runner.command is required in the task spec")
    if isinstance(cmd, str):
        cmd = shlex.split(cmd)

    args = runner_spec.get("args", []) or []
    if isinstance(args, str):
        args = shlex.split(args)
    full_cmd = list(cmd) + list(args)

    cwd = runner_spec.get("cwd")

    started_at = datetime.now(timezone.utc).isoformat()
    started_monotonic = time.monotonic()
    timed_out = False
    exit_code: Optional[int] = None
    stdout_b = b""
    stderr_b = b""

    logger.info(
        "[%s rep=%d] running: %s (cwd=%s, timeout=%.1fs)",
        config_name,
        rep_index,
        " ".join(full_cmd),
        cwd,
        timeout_seconds,
    )

    try:
        proc = await asyncio.create_subprocess_exec(
            *full_cmd,
            cwd=cwd,
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout_b, stderr_b = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout_seconds,
            )
            exit_code = proc.returncode
        except asyncio.TimeoutError:
            timed_out = True
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            try:
                stdout_b, stderr_b = await proc.communicate()
            except Exception:
                pass
            exit_code = proc.returncode
    except FileNotFoundError as e:
        finished_at = datetime.now(timezone.utc).isoformat()
        return RunResult(
            config_name=config_name,
            rep_index=rep_index,
            run_id=run_id,
            output_dir=str(output_dir),
            started_at=started_at,
            finished_at=finished_at,
            duration_seconds=0.0,
            exit_code=None,
            timed_out=False,
            timeout_seconds=timeout_seconds,
            success=False,
            success_reason=f"runner not found: {e}",
            failure_details={"error": "FileNotFoundError", "command": full_cmd},
            stdout_tail="",
            stderr_tail="",
        )

    duration = time.monotonic() - started_monotonic
    finished_at = datetime.now(timezone.utc).isoformat()

    # Score success against criteria
    success, reason, details = _score_run(output_dir, success_criteria)

    # Optional cost.json from the runner
    cost = None
    cost_path = output_dir / "cost.json"
    if cost_path.exists():
        try:
            cost = json.loads(cost_path.read_text())
        except Exception as e:
            logger.warning("[%s rep=%d] cost.json present but unreadable: %s", config_name, rep_index, e)

    return RunResult(
        config_name=config_name,
        rep_index=rep_index,
        run_id=run_id,
        output_dir=str(output_dir),
        started_at=started_at,
        finished_at=finished_at,
        duration_seconds=round(duration, 3),
        exit_code=exit_code,
        timed_out=timed_out,
        timeout_seconds=timeout_seconds,
        success=success,
        success_reason=reason,
        failure_details=None
        if success
        else {
            "exit_code": exit_code,
            "timed_out": timed_out,
            "scoring": details,
        },
        stdout_tail=_tail(stdout_b, capture_tail_chars),
        stderr_tail=_tail(stderr_b, capture_tail_chars),
        cost=cost,
    )


def _tail(data: bytes, max_chars: int) -> str:
    if not data:
        return ""
    text = data.decode(errors="replace")
    if len(text) <= max_chars:
        return text
    return "...(truncated)..." + text[-max_chars:]


# ── Aggregation ────────────────────────────────────────────────────


def _summarize(config_name: str, runs: list[RunResult]) -> ConfigSummary:
    if not runs:
        return ConfigSummary(
            config_name=config_name,
            reps=0,
            success_count=0,
            failure_count=0,
            success_rate=0.0,
            duration_p50=0.0,
            duration_p95=0.0,
            duration_mean=0.0,
            timeout_count=0,
            error_count=0,
        )

    durations = sorted(r.duration_seconds for r in runs)
    p50 = durations[len(durations) // 2]
    p95_idx = max(0, int(round(len(durations) * 0.95)) - 1)
    p95 = durations[p95_idx]
    mean = statistics.fmean(durations)

    successes = sum(1 for r in runs if r.success)
    failures = len(runs) - successes
    timeouts = sum(1 for r in runs if r.timed_out)
    errors = sum(1 for r in runs if r.exit_code not in (None, 0))

    # Cost aggregation if any run reports it
    cost_total = 0.0
    in_tokens = 0
    out_tokens = 0
    has_cost = False
    for r in runs:
        if not r.cost:
            continue
        has_cost = True
        cost_total += float(r.cost.get("total_usd", 0) or 0)
        in_tokens += int(r.cost.get("input_tokens", 0) or 0)
        out_tokens += int(r.cost.get("output_tokens", 0) or 0)

    return ConfigSummary(
        config_name=config_name,
        reps=len(runs),
        success_count=successes,
        failure_count=failures,
        success_rate=round(successes / len(runs), 4),
        duration_p50=round(p50, 3),
        duration_p95=round(p95, 3),
        duration_mean=round(mean, 3),
        timeout_count=timeouts,
        error_count=errors,
        cost_total_usd=round(cost_total, 4) if has_cost else None,
        cost_total_input_tokens=in_tokens if has_cost else None,
        cost_total_output_tokens=out_tokens if has_cost else None,
    )


# ── Markdown report ────────────────────────────────────────────────


def _render_markdown(session: SessionResult) -> str:
    lines = [
        f"# Memledger eval session `{session.session_id}`",
        "",
        f"- **Started:** {session.started_at}",
        f"- **Finished:** {session.finished_at}",
        f"- **Task spec:** `{session.task_spec_path}`",
        f"- **Eval config:** `{session.eval_config_path}`",
        f"- **Total runs:** {session.total_runs}",
        "",
        "## Summary",
        "",
        "| Configuration | Reps | Success rate | p50 | p95 | mean | Timeouts | Errors | Cost (USD) |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for s in session.summaries:
        cost = f"${s.cost_total_usd:.4f}" if s.cost_total_usd is not None else "—"
        lines.append(
            f"| {s.config_name} | {s.reps} | "
            f"{s.success_rate * 100:.1f}% | "
            f"{s.duration_p50:.1f}s | {s.duration_p95:.1f}s | {s.duration_mean:.1f}s | "
            f"{s.timeout_count} | {s.error_count} | {cost} |"
        )

    lines.extend(["", "## Failure breakdown by configuration", ""])
    for s in session.summaries:
        failed = [r for r in session.runs if r.config_name == s.config_name and not r.success]
        if not failed:
            lines.append(f"### {s.config_name}: no failures")
            lines.append("")
            continue
        lines.append(f"### {s.config_name} — {len(failed)} failures")
        lines.append("")
        for r in failed:
            lines.append(f"- **rep {r.rep_index} (`{r.run_id}`)** — {r.success_reason}")
        lines.append("")

    return "\n".join(lines)


# ── Async session driver ───────────────────────────────────────────


async def _run_session(
    *,
    task_spec: dict[str, Any],
    eval_config: dict[str, Any],
    output_root: Path,
    task_spec_path: str,
    eval_config_path: str,
) -> SessionResult:
    runner = task_spec.get("runner") or {}
    success_criteria = task_spec.get("success_criteria") or {}
    timeout_seconds = float(runner.get("timeout_seconds", 1800))

    configurations = eval_config.get("configurations") or {}
    reps_per_config = int(eval_config.get("reps_per_config", 30))

    if not configurations:
        raise ValueError("eval_config.configurations is empty — nothing to run")
    if reps_per_config < 1:
        raise ValueError(f"reps_per_config must be >= 1, got {reps_per_config}")

    session_id = f"eval-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6]}"
    session_started = datetime.now(timezone.utc).isoformat()
    session_root = output_root / session_id
    session_root.mkdir(parents=True, exist_ok=True)

    all_runs: list[RunResult] = []

    total = len(configurations) * reps_per_config
    counter = 0
    for config_name, cfg in configurations.items():
        config_env = (cfg or {}).get("env") or {}
        per_config_runs: list[RunResult] = []
        for rep in range(reps_per_config):
            counter += 1
            print(
                f"[{counter}/{total}] {config_name} rep {rep + 1}/{reps_per_config}",
                flush=True,
            )
            result = await _run_one(
                config_name=config_name,
                rep_index=rep,
                runner_spec=runner,
                success_criteria=success_criteria,
                config_env=config_env,
                output_root=session_root,
                timeout_seconds=timeout_seconds,
            )
            per_config_runs.append(result)
            all_runs.append(result)
            print(
                f"    {'OK ' if result.success else 'FAIL'} duration={result.duration_seconds:.1f}s "
                f"reason={result.success_reason}",
                flush=True,
            )

    summaries = [_summarize(name, [r for r in all_runs if r.config_name == name]) for name in configurations]

    session = SessionResult(
        session_id=session_id,
        started_at=session_started,
        finished_at=datetime.now(timezone.utc).isoformat(),
        task_spec_path=str(task_spec_path),
        eval_config_path=str(eval_config_path),
        total_runs=len(all_runs),
        summaries=summaries,
        runs=all_runs,
    )

    # Persist results
    results_json = session_root / "results.json"
    results_json.write_text(json.dumps(asdict(session), indent=2))

    summary_json = session_root / "summary.json"
    summary_json.write_text(json.dumps([asdict(s) for s in summaries], indent=2))

    md = _render_markdown(session)
    (session_root / "report.md").write_text(md)

    print()
    print(md)
    print()
    print(f"Results written to: {session_root}")

    return session


# ── Subparser registration ─────────────────────────────────────────


def _run_eval(args: argparse.Namespace) -> int:
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    task_spec = _load_yaml_with_env(args.task_spec)
    eval_config = _load_yaml_with_env(args.eval_config)

    output_root = Path(args.output or "./engram-eval-runs")
    output_root.mkdir(parents=True, exist_ok=True)

    asyncio.run(
        _run_session(
            task_spec=task_spec,
            eval_config=eval_config,
            output_root=output_root,
            task_spec_path=str(args.task_spec),
            eval_config_path=str(args.eval_config),
        )
    )
    return 0


def add_subparsers(subparsers: Any) -> None:
    eval_parser = subparsers.add_parser(
        "eval",
        help="Run a comparative evaluation of engram configurations",
    )
    eval_parser.add_argument(
        "--task-spec",
        "-t",
        required=True,
        help="YAML describing the agent runner and the success criteria.",
    )
    eval_parser.add_argument(
        "--eval-config",
        "-e",
        required=True,
        help="YAML describing the configurations to compare and reps per config.",
    )
    eval_parser.add_argument(
        "--output",
        "-o",
        default=None,
        help="Output root for run artifacts (default: ./engram-eval-runs)",
    )
    eval_parser.set_defaults(_handler=_run_eval)
