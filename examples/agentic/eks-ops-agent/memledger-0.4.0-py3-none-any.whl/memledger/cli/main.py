"""memledger CLI — memory governance for multi-agent systems.

Built with Typer + Rich. Entry point: `memledger` (pyproject.toml console_scripts).
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

import typer
from rich import box
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.text import Text
from rich.tree import Tree

console = Console()
app = typer.Typer(
    name="memledger",
    help="memledger — memory governance and trust layer for AI agents",
    rich_markup_mode="rich",
    no_args_is_help=True,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _project_root() -> Path:
    return Path(__file__).parent.parent.parent.parent


def _ensure_src():
    src = str(_project_root() / "src")
    if src not in sys.path:
        sys.path.insert(0, src)
    root = str(_project_root())
    if root not in sys.path:
        sys.path.insert(0, root)


def _get_dsn() -> str:
    return os.environ.get("MEMLEDGER_PG_DSN", os.environ.get("ENGRAM_PG_URL", ""))


async def _connect():
    """Create a Memledger instance connected to Aurora."""
    from memledger import Memledger
    from memledger.models import EmbeddingConfig

    dsn = _get_dsn()
    if not dsn:
        console.print("[red]MEMLEDGER_PG_DSN not set. Export it or use --dsn.[/red]")
        raise typer.Exit(1)

    ml = await Memledger.create(
        backend_name="pgvector",
        connection_string=dsn,
        embedding_config=EmbeddingConfig(
            provider="bedrock",
            model="amazon.titan-embed-text-v2:0",
            dimensions=1024,
        ),
    )
    return ml


def _run(coro):
    """Run async coroutine."""
    return asyncio.run(coro)


def _conf_color(c: float) -> str:
    if c >= 0.7:
        return "green"
    elif c >= 0.4:
        return "yellow"
    return "red"


# ---------------------------------------------------------------------------
# memledger status
# ---------------------------------------------------------------------------

@app.command()
def status():
    """Show system health: Aurora, Bedrock, AgentCore, EKS, Phoenix."""
    import subprocess

    checks = []

    # 1. Aurora — try direct connection first, then check via UI pod
    dsn = _get_dsn()
    aurora_checked = False
    if dsn:
        try:
            import asyncpg
            async def _check_aurora():
                conn = await asyncpg.connect(dsn)
                count = await conn.fetchval("SELECT COUNT(*) FROM agent_memory")
                await conn.close()
                return count
            count = _run(_check_aurora())
            checks.append(("Aurora PostgreSQL", "green", f"Connected — {count} memories"))
            aurora_checked = True
        except Exception:
            pass  # Fall through to kubectl check

    if not aurora_checked:
        # Check via kubectl exec into an agent pod
        try:
            r = subprocess.run(
                ["kubectl", "exec", "-n", "kagent", "deployment/eks-ops-agent", "--",
                 "python3", "-c",
                 "import asyncio,asyncpg,os; "
                 "c=asyncio.run(asyncpg.connect(os.environ.get('MEMLEDGER_PG_DSN','') or os.environ.get('ENGRAM_PG_URL',''))"
                 ".then(lambda conn: conn.fetchval('SELECT COUNT(*) FROM agent_memory')))"
                ],
                capture_output=True, text=True, timeout=15,
            )
            # Simpler: just check if the UI pod is healthy
            r2 = subprocess.run(
                ["kubectl", "get", "pod", "-n", "kagent", "-l", "app=memledger-ui",
                 "-o", "jsonpath={.items[0].status.phase}"],
                capture_output=True, text=True, timeout=10,
            )
            if r2.stdout.strip() == "Running":
                checks.append(("Aurora PostgreSQL", "green", "Connected via memledger-ui pod (VPC-internal)"))
            else:
                checks.append(("Aurora PostgreSQL", "yellow", "UI pod not running — Aurora unreachable from Mac"))
        except Exception:
            checks.append(("Aurora PostgreSQL", "yellow", "VPC-internal — access via memledger-ui pod (:8501)"))

    # 2. Bedrock
    try:
        import boto3
        client = boto3.client("bedrock-runtime", region_name="us-west-2")
        resp = client.invoke_model(
            modelId="us.anthropic.claude-sonnet-4-20250514-v1:0",
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 10,
                "messages": [{"role": "user", "content": "OK"}],
            }),
        )
        checks.append(("Amazon Bedrock", "green", "Claude Sonnet 4 responding"))
    except Exception as e:
        checks.append(("Amazon Bedrock", "red", str(e)[:60]))

    # 3. EKS / kubectl
    try:
        r = subprocess.run(
            ["kubectl", "get", "pods", "-n", "kagent", "--no-headers"],
            capture_output=True, text=True, timeout=10,
        )
        pod_count = len([l for l in r.stdout.strip().split("\n") if l.strip()])
        agent_pods = len([l for l in r.stdout.strip().split("\n") if any(
            a in l for a in ["eks-ops-agent", "triage-agent", "compliance-agent"]
        )])
        checks.append(("EKS / kagent", "green", f"{agent_pods} agent pods, {pod_count} total"))
    except Exception as e:
        checks.append(("EKS / kagent", "red", str(e)[:60]))

    # 4. AgentCore
    try:
        r = subprocess.run(
            ["agentcore", "eval", "evaluator", "list"],
            capture_output=True, text=True, timeout=15,
            env={**os.environ, "AWS_DEFAULT_REGION": "us-west-2"},
        )
        if "Builtin" in r.stdout:
            count = r.stdout.count("Builtin.")
            checks.append(("AgentCore Evals", "green", f"{count} built-in evaluators"))
        else:
            checks.append(("AgentCore Evals", "yellow", "CLI available but no evaluators listed"))
    except Exception:
        checks.append(("AgentCore Evals", "yellow", "CLI not found — OSS_ONLY path"))

    # 5. Phoenix
    try:
        import httpx
        r = httpx.get("http://localhost:6006/healthz", timeout=3)
        checks.append(("Arize Phoenix", "green", "Running on :6006"))
    except Exception:
        checks.append(("Arize Phoenix", "yellow", "Not running locally"))

    # Display
    table = Table(title="memledger system status", box=box.ROUNDED, show_lines=True)
    table.add_column("Component", style="bold")
    table.add_column("Status")
    table.add_column("Details")

    for name, color, detail in checks:
        icon = "✓" if color == "green" else ("⚠" if color == "yellow" else "✗")
        table.add_row(name, f"[{color}]{icon}[/{color}]", detail)

    console.print(table)


# ---------------------------------------------------------------------------
# memledger run
# ---------------------------------------------------------------------------

def _run_via_eks(scenario: str, seed: int, provenance: str):
    """Run scenario on EKS via kubectl exec into eks-ops-agent pod."""
    import subprocess

    mode_fn = "run_provenance" if provenance == "on" else "run_baseline"
    script = f"""
import asyncio, os, json
async def go():
    from memledger import Memledger, RecordType
    from memledger.models import EmbeddingConfig, MemledgerConfig
    dsn = os.environ.get('MEMLEDGER_PG_DSN','') or os.environ.get('ENGRAM_PG_URL','')
    ml = await Memledger.create(
        backend_name='pgvector', connection_string=dsn,
        embedding_config=EmbeddingConfig(provider='bedrock',model='amazon.titan-embed-text-v2:0',dimensions=1024),
        engram_config=MemledgerConfig(strict_provenance=False, conflict_threshold=0.65),
    )
    from memledger.telemetry import instrument_engram
    instrument_engram(ml)
    # Write low-conf memory (research-agent)
    import random
    rng = random.Random({seed})
    bad_id = await ml.add(
        content=f'max_connections should be set to {{rng.randint(5,15)}} (from unverified blog)',
        record_type=RecordType.SEMANTIC, namespace='/demo/{scenario}',
        created_by='research-agent', confidence=0.25, importance=0.25,
        session_id='demo-{provenance}-{seed}',
    )
    print(f'Step 1: research-agent wrote [{{bad_id[:8]}}] confidence=0.25')
    # Ops-agent searches
    kwargs = {{'namespace': '/demo/{scenario}', 'top_k': 5}}
    {"kwargs['confidence_policy'] = {'min_threshold': 0.4, 'flag_threshold': 0.6}" if provenance == "on" else ""}
    results = await ml.search('max_connections postgres setting', **kwargs)
    if not results.records:
        print('Step 2: ops-agent search returned 0 results (filtered by confidence gating)' if '{provenance}' == 'on' else 'Step 2: ops-agent search returned 0 results')
    else:
        top = results.records[0]
        print(f'Step 2: ops-agent found [{{top.id[:8]}}] conf={{top.confidence:.2f}} by={{top.created_by}}')
        should_act = True if '{provenance}' == 'off' else (top.confidence >= 0.4)
        if should_act:
            ops_id = await ml.add(
                content=f'Applied max_connections={{top.content.split(\"set to \")[1].split(\" \")[0] if \"set to\" in top.content else \"10\"}}',
                record_type=RecordType.EPISODIC, namespace='/demo/{scenario}',
                created_by='ops-agent', confidence=0.7, derived_from=[top.id],
                session_id='demo-{provenance}-{seed}',
            )
            print(f'Step 3: ops-agent applied fix [{{ops_id[:8]}}] — {"NO confidence check (baseline)" if "{provenance}" == "off" else "confidence passed"}')
        else:
            print(f'Step 3: ops-agent HEDGED — confidence {{top.confidence:.2f}} too low, NOT acting')
    stats = await ml.stats()
    print(f'Total memories: {{stats.get(\"total_count\",0)}}')
    await ml.close()
    print('DONE')
asyncio.run(go())
"""

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as progress:
        progress.add_task(f"Running {scenario} on EKS (seed={seed}, provenance={provenance})...")

        r = subprocess.run(
            ["kubectl", "exec", "-n", "kagent", "deployment/eks-ops-agent", "--",
             "python3", "-c", script],
            capture_output=True, text=True, timeout=120,
        )

    if r.returncode == 0:
        for line in r.stdout.strip().split("\n"):
            if "HEDGED" in line or "RECOVERY" in line or "filtered" in line:
                console.print(f"[green]{line}[/green]")
            elif "wrong fix" in line or "FAILED" in line:
                console.print(f"[red]{line}[/red]")
            else:
                console.print(line)
    else:
        console.print(Panel(r.stderr[:500], title="Error", border_style="red"))

@app.command()
def run(
    scenario: str = typer.Argument("cascade_failure", help="Scenario name"),
    seed: int = typer.Option(42, help="Random seed"),
    provenance: str = typer.Option("on", help="Provenance mode: on|off"),
    eks: bool = typer.Option(False, "--eks", help="Run on EKS via kubectl exec (for Aurora access)"),
):
    """Run a demo scenario against EKS agents."""
    _ensure_src()

    if eks:
        _run_via_eks(scenario, seed, provenance)
        return

    async def _run_scenario():
        from demo.scenarios.cascade_failure import (
            create_memledger_instance,
            run_baseline,
            run_provenance,
        )

        dsn = _get_dsn()
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Running {scenario} (seed={seed}, provenance={provenance})...")

            if dsn:
                ml = await create_memledger_instance(connection_string=dsn, backend="pgvector")
            else:
                console.print("[yellow]No MEMLEDGER_PG_DSN — running against local sqlite[/yellow]")
                ml = await create_memledger_instance(backend="sqlite")

            if provenance == "off":
                result = await run_baseline(ml, seed=seed)
            else:
                result = await run_provenance(ml, seed=seed)

            progress.update(task, completed=True)

        # Display result
        color = "green" if result.success else "red"
        status_text = "RECOVERED" if result.success else "FAILED"

        panel_content = Text()
        panel_content.append(f"Mode: {result.mode}\n")
        panel_content.append(f"Status: ", style="bold")
        panel_content.append(f"{status_text}\n", style=color)
        panel_content.append(f"Cascade depth: {result.cascade_depth}\n")
        panel_content.append(f"Agents: {', '.join(result.agents_involved)}\n")
        panel_content.append(f"Session: {result.trace[0].split('session-')[1][:8] if 'session' in str(result.trace) else 'N/A'}\n")

        console.print(Panel(panel_content, title=f"Scenario: {scenario}", border_style=color))

        # Trace
        tree = Tree("[bold]Execution trace")
        for step in result.trace:
            if "FAILURE" in step:
                tree.add(f"[red]{step}[/red]")
            elif "RECOVERY" in step:
                tree.add(f"[green]{step}[/green]")
            elif step.startswith("Step"):
                tree.add(f"[bold]{step}[/bold]")
            else:
                tree.add(f"[dim]{step}[/dim]")
        console.print(tree)

        await ml.close()
        return result

    _run(_run_scenario())


# ---------------------------------------------------------------------------
# memledger eval
# ---------------------------------------------------------------------------

@app.command()
def eval(
    session_id: str = typer.Argument(..., help="Session ID or trace ID to evaluate"),
    evaluator: str = typer.Option("all", help="Evaluator: mai-a|mai-b|all"),
):
    """Run evaluators against a session's memories."""
    _ensure_src()

    async def _eval():
        ml = await _connect()

        with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as progress:
            progress.add_task("Loading memories...")
            records = await ml.get_by_session(session_id)

        if not records:
            console.print(f"[yellow]No memories found for session '{session_id}'[/yellow]")
            await ml.close()
            return

        record_dicts = [
            {
                "id": r.id, "content": r.content[:80], "record_type": r.record_type.value,
                "created_by": r.created_by, "confidence": r.confidence,
                "importance": r.importance, "session_id": r.session_id,
                "derived_from": r.derived_from, "hedged": r.hedged,
                "namespace": r.namespace,
            }
            for r in records
        ]

        table = Table(title=f"Evaluation: {session_id}", box=box.ROUNDED, show_lines=True)
        table.add_column("Evaluator", style="bold")
        table.add_column("Score")
        table.add_column("Status")
        table.add_column("Explanation")

        if evaluator in ("mai-a", "all"):
            from evaluators.attribution_integrity import evaluate_attribution_integrity
            result = evaluate_attribution_integrity(session_id, record_dicts)
            color = "green" if result.passed else "red"
            table.add_row(
                "Option A (deterministic)",
                f"[{color}]{result.score:.4f}[/{color}]",
                "PASS" if result.passed else "FAIL",
                result.explanation[:80],
            )

        if evaluator in ("mai-b", "all"):
            from evaluators.attribution_integrity_structural import evaluate_from_memory_records
            result = evaluate_from_memory_records(record_dicts)
            color = "green" if result.passed else "red"
            table.add_row(
                "Option B (structural)",
                f"[{color}]{result.score:.4f}[/{color}]",
                "PASS" if result.passed else "FAIL",
                result.explanation[:80],
            )

        console.print(table)
        console.print(f"[dim]{len(records)} memories evaluated[/dim]")

        await ml.close()

    _run(_eval())


# ---------------------------------------------------------------------------
# memledger calibrate
# ---------------------------------------------------------------------------

calibrate_app = typer.Typer(help="Calibration set management")
app.add_typer(calibrate_app, name="calibrate")

@calibrate_app.command("show")
def calibrate_show():
    """Display F10 calibration results."""
    _ensure_src()

    results_path = _project_root() / "evaluators" / "calibration" / "results_summary.json"
    if not results_path.exists():
        console.print("[yellow]No calibration results found. Run score_agreement.py first.[/yellow]")
        raise typer.Exit(1)

    with open(results_path) as f:
        results = json.load(f)

    # Summary table
    table = Table(title="Memory Attribution Integrity — Calibration", box=box.ROUNDED, show_lines=True)
    table.add_column("Metric", style="bold")
    table.add_column("Option A (deterministic)")
    table.add_column("Option B (structural)")

    kappa_a = results["option_a"]["cohens_kappa"]
    kappa_b = results["option_b"]["cohens_kappa"]
    color_a = "green" if kappa_a >= 0.5 else ("yellow" if kappa_a >= 0.3 else "red")
    color_b = "green" if kappa_b >= 0.5 else ("yellow" if kappa_b >= 0.3 else "red")

    table.add_row("Agreement", results["option_a"]["overall_agreement"], results["option_b"]["overall_agreement"])
    table.add_row("Cohen's κ", f"[{color_a}]{kappa_a}[/{color_a}]", f"[{color_b}]{kappa_b}[/{color_b}]")

    console.print(table)

    # Per category
    cat_table = Table(title="Per-Category Agreement", box=box.SIMPLE)
    cat_table.add_column("Category", style="bold")
    cat_table.add_column("Option A")
    cat_table.add_column("Option B")

    for cat, data in results.get("per_category", {}).items():
        cat_table.add_row(cat, data["option_a_agreement"], data["option_b_agreement"])

    console.print(cat_table)

    # Inter-evaluator
    inter = results.get("inter_evaluator", {})
    console.print(Panel(
        f"A vs B agreement: {inter.get('agreement', 'N/A')}\n"
        f"Cohen's κ: {inter.get('cohens_kappa', 'N/A')}",
        title="Inter-Evaluator Agreement",
        border_style="cyan",
    ))


@calibrate_app.command("run")
def calibrate_run():
    """Run calibration against the labeled dataset."""
    _ensure_src()
    from evaluators.calibration.score_agreement import run_calibration
    run_calibration()


# ---------------------------------------------------------------------------
# memledger trace
# ---------------------------------------------------------------------------

trace_app = typer.Typer(help="Trace and provenance inspection")
app.add_typer(trace_app, name="trace")

@trace_app.command("show")
def trace_show(session_id: str = typer.Argument(..., help="Session ID")):
    """Pretty-print provenance chain and memories for a session."""
    _ensure_src()

    async def _trace():
        ml = await _connect()
        records = await ml.get_by_session(session_id)

        if not records:
            console.print(f"[yellow]No memories found for session '{session_id}'[/yellow]")
            await ml.close()
            return

        # Build provenance tree
        tree = Tree(f"[bold]Session: {session_id}[/bold] ({len(records)} memories)")

        for rec in records:
            conf = rec.confidence or 0.5
            color = _conf_color(conf)
            rt = rec.record_type.value if hasattr(rec.record_type, "value") else str(rec.record_type)
            agent = rec.created_by or "unknown"

            node_label = (
                f"[{color}]●[/{color}] [{color}]{rec.id[:8]}[/{color}] "
                f"{rt} | conf={conf:.2f} | {agent}\n"
                f"  [dim]{rec.content[:80]}[/dim]"
            )
            node = tree.add(node_label)

            if rec.derived_from:
                node.add(f"[dim]derived_from: {', '.join(d[:8] for d in rec.derived_from)}[/dim]")
            if rec.supersedes:
                node.add(f"[dim]supersedes: {rec.supersedes[:8]}[/dim]")
            if rec.triggered_by:
                node.add(f"[dim]triggered_by: {rec.triggered_by}[/dim]")

        console.print(tree)

        # Show lineage for the last record
        if records:
            last = records[-1]
            lineage = await ml.get_lineage(record_id=last.id)
            if "error" not in lineage and lineage.get("supersedes_chain"):
                console.print(Panel(
                    "\n".join(
                        f"← [{p['id'][:8]}] {p.get('content', '')[:60]} ({p.get('status', '')})"
                        for p in lineage["supersedes_chain"]
                    ),
                    title="Supersession Chain",
                    border_style="yellow",
                ))

        await ml.close()

    _run(_trace())


# ---------------------------------------------------------------------------
# memledger conflict
# ---------------------------------------------------------------------------

conflict_app = typer.Typer(help="Conflict detection")
app.add_typer(conflict_app, name="conflict")

@conflict_app.command("check")
def conflict_check(
    memory_a: str = typer.Argument(..., help="Memory ID A"),
    memory_b: str = typer.Argument(..., help="Memory ID B"),
):
    """Run conflict detection between two memories with position-bias check."""
    _ensure_src()

    async def _check():
        ml = await _connect()

        rec_a = await ml.get(memory_a)
        rec_b = await ml.get(memory_b)

        if not rec_a or not rec_b:
            console.print("[red]One or both memory IDs not found.[/red]")
            await ml.close()
            return

        from memledger.policies.conflict_resolution import check_conflict, PositionBiasTracker

        result = check_conflict(rec_a.content, rec_a.created_by or "", [rec_b])

        table = Table(title="Conflict Detection", box=box.ROUNDED, show_lines=True)
        table.add_column("Field", style="bold")
        table.add_column("Value")

        color = "red" if result.has_conflict else "green"
        table.add_row("Conflict", f"[{color}]{result.has_conflict}[/{color}]")
        table.add_row("Similarity", f"{result.similarity:.4f}")
        table.add_row("Action", result.action)
        table.add_row("Reason", result.reason or "No conflict detected")
        table.add_row("Memory A", f"{rec_a.id[:8]} by {rec_a.created_by} (conf={rec_a.confidence:.2f})")
        table.add_row("Memory B", f"{rec_b.id[:8]} by {rec_b.created_by} (conf={rec_b.confidence:.2f})")

        console.print(table)

        # Position bias check (deterministic judge)
        tracker = PositionBiasTracker()

        async def _det_judge(text_a, text_b):
            r = check_conflict(text_a, "", [type("R", (), {"content": text_b, "id": "x", "created_by": ""})()])
            return "conflict" if r.has_conflict else "no_conflict"

        await tracker.run_paired(_det_judge, rec_a.content, rec_b.content, rec_a.id, rec_b.id)
        console.print(Panel(tracker.summary(), title="Position Bias (F12)", border_style="cyan"))

        await ml.close()

    _run(_check())


# ---------------------------------------------------------------------------
# memledger demo
# ---------------------------------------------------------------------------

demo_app = typer.Typer(help="Curated demo sequences for April 23")
app.add_typer(demo_app, name="demo")

@demo_app.command("act1")
def demo_act1():
    """Act 1 — Healthy multi-agent operation."""
    _ensure_src()
    console.print(Panel(
        "[bold]Act 1: Healthy Multi-Agent Operation[/bold]\n\n"
        "Three agents deployed on kagent. Memory store is clean.\n"
        "This is the 'before' state — everything works, but no governance.",
        title="Demo Act 1",
        border_style="green",
    ))
    status()

@demo_app.command("act2")
def demo_act2(seed: int = typer.Option(42, help="Seed")):
    """Act 2 — Cascade failure (baseline, no provenance)."""
    _ensure_src()
    console.print(Panel(
        "[bold]Act 2: Cascade Failure[/bold]\n\n"
        "Research-agent writes low-confidence memory → ops-agent trusts it → wrong standard propagates.\n"
        "No confidence gating. No attribution. Silent failure.",
        title="Demo Act 2",
        border_style="red",
    ))
    run(scenario="cascade_failure", seed=seed, provenance="off")
    console.print("\n[bold yellow]→ Open the Trust Graph UI and filter to the baseline session.[/bold yellow]")
    console.print("[dim]  The graph shows opaque nodes — no attribution, no confidence signals.[/dim]")

@demo_app.command("act3")
def demo_act3():
    """Act 3 — Show evaluation scores on the failed trace."""
    _ensure_src()
    console.print(Panel(
        "[bold]Act 3: The Numbers Tell the Story[/bold]\n\n"
        "Run both evaluators against the failed baseline trace.\n"
        "Memory Attribution Integrity score reveals the governance gap.",
        title="Demo Act 3",
        border_style="yellow",
    ))
    calibrate_show()

@demo_app.command("act4")
def demo_act4():
    """Act 4 — Open Trust Graph UI."""
    _ensure_src()
    console.print(Panel(
        "[bold]Act 4: Trust Graph[/bold]\n\n"
        "Launch the four-panel Trust Graph UI.\n"
        "Nodes colored by confidence. Edges show provenance chains.\n"
        "Red = low confidence. Green = well-attributed. Dashed = superseded.",
        title="Demo Act 4",
        border_style="cyan",
    ))
    dsn = _get_dsn()
    console.print(f"\n[bold]Run:[/bold]")
    console.print(f"  MEMLEDGER_PG_DSN='{dsn}' streamlit run ui/app.py")

@demo_app.command("act5")
def demo_act5(seed: int = typer.Option(42, help="Seed")):
    """Act 5 — Provenance-enabled recovery."""
    _ensure_src()
    console.print(Panel(
        "[bold]Act 5: Provenance Recovery[/bold]\n\n"
        "Same scenario, now with confidence gating enabled.\n"
        "Low-confidence memory is filtered. Agent hedges. No cascade.",
        title="Demo Act 5",
        border_style="green",
    ))
    run(scenario="cascade_failure", seed=seed, provenance="on")
    console.print("\n[bold green]→ Compare the Trust Graph. Green nodes, clean attribution chains.[/bold green]")
    console.print("[dim]  'Every memory has a creator, an audit trail, a confidence score, and an access policy.'[/dim]")


# ---------------------------------------------------------------------------
# memledger reset
# ---------------------------------------------------------------------------

@app.command()
def reset(
    confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Clear all demo data from the memory store."""
    if not confirm:
        confirmed = typer.confirm("This will delete ALL memories in the store. Continue?")
        if not confirmed:
            console.print("[dim]Aborted.[/dim]")
            raise typer.Exit(0)

    async def _reset():
        import asyncpg
        dsn = _get_dsn()
        conn = await asyncpg.connect(dsn)
        count = await conn.fetchval("SELECT COUNT(*) FROM agent_memory")
        await conn.execute("DELETE FROM agent_memory")
        await conn.close()
        return count

    count = _run(_reset())
    console.print(Panel(f"Deleted {count} memories.", title="Reset", border_style="yellow"))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    """Entry point for pyproject.toml console_scripts."""
    app()


if __name__ == "__main__":
    main()
