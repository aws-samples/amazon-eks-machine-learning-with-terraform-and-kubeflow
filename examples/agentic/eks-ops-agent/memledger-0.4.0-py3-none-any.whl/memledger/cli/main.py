"""Memledger CLI entry point.

Commands:
    engram serve [--config PATH]                              Start MCP server
    engram lineage <target> --config PATH                     Render lineage HTML
    engram dashboard --config PATH                            Render dashboard HTML
    engram eval --task-spec PATH --eval-config PATH           Comparative evaluation
    engram eval-report --session-dir PATH                     Charts from an eval session
"""

from __future__ import annotations

import argparse
import asyncio
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="engram",
        description="Memledger — memory infrastructure for AI agents",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # serve command
    serve_parser = subparsers.add_parser("serve", help="Start the MCP server")
    serve_parser.add_argument(
        "--config",
        "-c",
        help="Path to engram config file (default: ~/.memledger/config.yaml)",
        default=None,
    )

    # dashboard / lineage subcommands
    from memledger.cli.dashboard import add_subparsers as add_dashboard_subparsers

    add_dashboard_subparsers(subparsers)

    # eval subcommand
    from memledger.cli.eval import add_subparsers as add_eval_subparsers

    add_eval_subparsers(subparsers)

    # eval-report subcommand (chart generator)
    from memledger.cli.eval_report import add_subparsers as add_eval_report_subparsers

    add_eval_report_subparsers(subparsers)

    # demo subcommand
    from memledger.cli.demo import add_subparsers as add_demo_subparsers

    add_demo_subparsers(subparsers)

    args = parser.parse_args()

    if args.command == "serve":
        from memledger.mcp.server import serve

        asyncio.run(serve(args.config))
    elif hasattr(args, "_handler"):
        sys.exit(args._handler(args) or 0)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
