"""Memledger demo — scripted 8-step demo for stakeholder presentations.

Each step executes one engram operation against a local SQLite backend
with a deterministic fake embedder (no API keys, no infrastructure).
A Streamlit dashboard polls the same SQLite file and displays results
in real time.

Usage:
    engram demo --step 1                  # Run step 1
    engram demo --step 4                  # Run step 4
    engram demo --all                     # Run all 8 steps with pauses
    engram demo --reset                   # Clear demo data
    engram demo --ui                      # Start Streamlit dashboard
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import logging
import shutil
import sys
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ── Demo configuration ─────────────────────────────────────────────

DEMO_DB = Path.home() / ".engram" / "demo.db"
DEMO_STATE = Path.home() / ".engram" / "demo-state.json"
DEMO_NAMESPACE = "/demo/sre"
DEMO_DIMENSIONS = 64


# ── Fake embedder ──────────────────────────────────────────────────


class DemoEmbedder:
    """Deterministic hash-based embedder. No API keys. Reproducible."""

    def __init__(self, dimensions: int = DEMO_DIMENSIONS):
        self._dimensions = dimensions

    async def embed_single(self, text: str) -> list[float]:
        h = hashlib.sha256(text.encode()).digest()
        return [(h[i % len(h)] / 255.0) - 0.5 for i in range(self._dimensions)]

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [await self.embed_single(t) for t in texts]


# ── Memledger setup ───────────────────────────────────────────────────


async def _get_engram():
    from memledger import Memledger
    from memledger.models import EmbeddingConfig

    DEMO_DB.parent.mkdir(parents=True, exist_ok=True)
    engram = await Memledger.create(
        backend_name="sqlite",
        backend_config={"path": str(DEMO_DB), "dimensions": DEMO_DIMENSIONS},
        embedding_config=EmbeddingConfig(provider="fake", model="fake", dimensions=DEMO_DIMENSIONS),
    )
    engram._embedder = DemoEmbedder(DEMO_DIMENSIONS)
    return engram


# ── Pretty printing ────────────────────────────────────────────────

BLUE = "\033[94m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
PURPLE = "\033[95m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"


def _header(step: int, title: str):
    print(f"\n{BOLD}{BLUE}━━━ Step {step}: {title} ━━━{RESET}\n")


def _result(key: str, value: str, color: str = GREEN):
    print(f"  {DIM}→{RESET} {key}: {color}{value}{RESET}")


def _wow(msg: str):
    print(f"\n  {BOLD}{YELLOW}★ {msg}{RESET}\n")


def _pause(seconds: float = 1.5):
    time.sleep(seconds)


# ── Demo steps ─────────────────────────────────────────────────────

# State preserved across steps via JSON file
def _load_state() -> dict[str, Any]:
    import json
    if DEMO_STATE.exists():
        return json.loads(DEMO_STATE.read_text())
    return {}

def _save_state(state: dict[str, Any]):
    import json
    DEMO_STATE.parent.mkdir(parents=True, exist_ok=True)
    DEMO_STATE.write_text(json.dumps(state, indent=2))

_state: dict[str, Any] = {}


async def step_1(engram):
    """Store an episodic memory — a production incident."""
    from memledger import RecordType

    _header(1, "Agent stores a production incident")

    rid = await engram.add(
        "Payment service hit OOM kills at 3am. Root cause: HikariCP connection pool "
        "leak with unbounded maxPoolSize. Fixed by setting maxPoolSize=50 in "
        "application.yaml and restarting pods. Service recovered in 45 minutes.",
        record_type=RecordType.EPISODIC,
        namespace=DEMO_NAMESPACE,
        metadata={"severity": "P1", "service": "payment-service", "resolved": True},
    )
    _state["incident_id"] = rid

    _result("Record ID", rid[:8])
    _result("Type", "episodic")
    _result("Namespace", DEMO_NAMESPACE)
    _result("Status", "active")
    _result("Importance", "0.5 (default)")
    print(f"\n  {DIM}The agent just learned from a real incident.{RESET}")


async def step_2(engram):
    """Search for relevant memories."""
    _header(2, "Agent searches memory: 'How to fix OOM kills?'")

    results = await engram.search("OOM kills connection pool fix", namespace=DEMO_NAMESPACE, top_k=5)

    if results.records:
        rec = results.records[0]
        _result("Query", "OOM kills connection pool fix")
        _result("Results found", str(len(results.records)))
        _result("Top match", f"[{rec.id[:8]}] score={rec.score:.3f}" if rec.score else f"[{rec.id[:8]}]")
        _result("Content", rec.content[:80] + "...")
        _result("Search time", f"{results.search_time_ms:.1f}ms")
        print(f"\n  {DIM}The agent found relevant past experience.{RESET}")
    else:
        _result("Results", "none found", RED)


async def step_3(engram):
    """Record successful outcomes — the fix worked."""
    _header(3, "Recording outcomes — the fix worked (3 times)")

    rid = _state.get("incident_id")
    if not rid:
        print(f"  {RED}Run step 1 first.{RESET}")
        return

    for i in range(1, 4):
        await engram.record_outcome(rid, success=True)
        rec = await engram.get(rid)
        _result(f"Outcome #{i}", f"success_count={rec.success_count}")
        if i < 3:
            _pause(0.5)

    # Check for auto-promotion
    active = await engram.get_by_status("active")
    promoted = [r for r in active if rid in (r.derived_from or []) and r.record_type.value == "procedural"]

    if promoted:
        p = promoted[0]
        _state["procedural_id"] = p.id
        _wow("AUTO-PROMOTION: Episodic → Procedural!")
        _result("New procedural record", p.id[:8])
        _result("Created by", p.created_by or "engram:auto_promote")
        _result("Derived from", rid[:8])
        _result("Content", p.content[:80] + "...")
        print(f"\n  {DIM}An incident fix that worked 3 times just became a reusable runbook.{RESET}")
    else:
        _result("Auto-promotion", "threshold not yet reached", YELLOW)


async def step_4(engram):
    """Search again — the procedural memory should rank high."""
    _header(4, "Search again — proven procedure ranks first")

    results = await engram.search("OOM kills fix procedure", namespace=DEMO_NAMESPACE, top_k=5)

    for i, rec in enumerate(results.records[:3], 1):
        type_color = GREEN if rec.record_type.value == "procedural" else BLUE
        _result(
            f"#{i}",
            f"[{rec.id[:8]}] {type_color}{rec.record_type.value}{RESET} "
            f"score={rec.score:.3f} success={rec.success_count}",
        )

    if results.records and results.records[0].record_type.value == "procedural":
        _wow("The proven procedure ranks first — scoring works!")
    print(f"\n  {DIM}Memories that lead to successful outcomes rise in ranking.{RESET}")


async def step_5(engram):
    """Store a conflicting memory — conflict detection fires."""
    from memledger import RecordType

    _header(5, "Storing conflicting information")

    rid = await engram.add(
        "maxPoolSize should be set to 100 for all services. This is the "
        "team standard configuration.",
        record_type=RecordType.SEMANTIC,
        namespace=DEMO_NAMESPACE,
        metadata={"type": "configuration", "parameter": "maxPoolSize", "value": "100"},
    )
    _state["conflict_id"] = rid

    _result("Stored", f"[{rid[:8]}] maxPoolSize=100")

    # Check audit for conflict detection
    conflicts = [e for e in engram.audit.recent(10) if e.operation == "conflict_detected"]
    if conflicts:
        c = conflicts[-1]
        _wow("CONFLICT DETECTED!")
        _result("Conflicting with", c.details.get("existing_id", "?")[:8])
        _result("Similarity", str(c.details.get("similarity", "?")))
        print(f"\n  {DIM}Memledger caught the contradiction and surfaced it.{RESET}")
    else:
        _result("Conflict check", "ran (no conflict above threshold)", DIM)
        print(f"\n  {DIM}Memory stored. Conflict detection checked existing memories.{RESET}")


async def step_6(engram):
    """Supersede — update the standard with a reviewed value."""
    from memledger import RecordType

    _header(6, "Knowledge evolves — superseding old information")

    old_id = _state.get("conflict_id")
    rid = await engram.add(
        "maxPoolSize=250 is the official standard after Q1 capacity review. "
        "Previous values (50, 100) are deprecated.",
        record_type=RecordType.SEMANTIC,
        namespace=DEMO_NAMESPACE,
        supersedes=old_id,
        metadata={"type": "configuration", "parameter": "maxPoolSize", "value": "250", "reviewed": True},
    )
    _state["superseded_id"] = rid

    _result("New record", f"[{rid[:8]}] maxPoolSize=250 (active)")
    if old_id:
        old = await engram.get(old_id)
        _result("Old record", f"[{old_id[:8]}] maxPoolSize=100 ({old.status.value if old else 'unknown'})")

    _wow("Knowledge evolved. Old value deprecated. History preserved.")
    print(f"\n  {DIM}The supersession chain is maintained in lineage.{RESET}")


async def step_7(engram):
    """View the full lineage graph."""
    _header(7, "Memory lineage — full provenance")

    # Get lineage for the superseded record or the incident
    target_id = _state.get("superseded_id") or _state.get("incident_id")
    if not target_id:
        print(f"  {RED}Run earlier steps first.{RESET}")
        return

    lineage = await engram.get_lineage(target_id)

    if "error" in lineage:
        _result("Error", lineage["error"], RED)
        return

    rec = lineage["record"]
    _result("Record", f"[{rec['id'][:8]}] {rec['record_type']} | {rec['status']}")
    _result("Content", rec["content"][:60] + "...")
    _result("Confidence", f"{lineage.get('confidence', 'N/A')}")

    if lineage.get("created_by"):
        _result("Created by", lineage["created_by"])
    if lineage.get("accessed_by"):
        _result("Accessed by", ", ".join(lineage["accessed_by"]))

    chain = lineage.get("supersedes_chain", [])
    if chain:
        _result("Supersession chain", f"{len(chain)} predecessors")
        for s in chain:
            print(f"    {DIM}← [{s['id'][:8]}] {s['content'][:50]}... ({s['status']}){RESET}")

    derived = lineage.get("derived_records", [])
    if derived:
        _result("Derived records", f"{len(derived)} descendants")
        for d in derived:
            print(f"    {DIM}→ [{d['id'][:8]}] {d['content'][:50]}...{RESET}")

    _wow("Every piece of knowledge is traceable.")
    print(f"\n  {DIM}Full provenance: who created it, what it replaced, what was derived from it.{RESET}")


async def step_8(engram):
    """Show stats and audit summary."""
    _header(8, "Stats and audit trail")

    stats = await engram.stats()
    _result("Total memories", str(stats.get("total_count", 0)))

    by_type = stats.get("by_record_type", {})
    for t, count in by_type.items():
        _result(f"  {t}", str(count))

    namespaces = await engram.list_namespaces()
    _result("Namespaces", ", ".join(namespaces) if namespaces else "none")

    print(f"\n  {BOLD}Recent audit log:{RESET}")
    summary = engram.audit.summary(10)
    for line in summary.split("\n"):
        print(f"  {DIM}{line}{RESET}")

    print(f"\n  {DIM}Full observability: every operation, timestamped, queryable.{RESET}")


# ── Step registry ──────────────────────────────────────────────────

STEPS = {
    1: ("Store incident (episodic)", step_1),
    2: ("Search memory", step_2),
    3: ("Record outcomes + auto-promotion", step_3),
    4: ("Search again — proven procedure ranks first", step_4),
    5: ("Store conflicting memory", step_5),
    6: ("Supersede — knowledge evolves", step_6),
    7: ("View lineage", step_7),
    8: ("Stats and audit", step_8),
}


# ── Runner ─────────────────────────────────────────────────────────


async def _run_step(step: int):
    global _state
    if step not in STEPS:
        print(f"{RED}Invalid step {step}. Valid: 1-{len(STEPS)}{RESET}")
        return

    _state = _load_state()
    engram = await _get_engram()
    try:
        _, fn = STEPS[step]
        await fn(engram)
        _save_state(_state)
    finally:
        await engram.close()


async def _run_all():
    global _state
    _state = _load_state()
    engram = await _get_engram()
    try:
        for step_num in sorted(STEPS):
            _, fn = STEPS[step_num]
            await fn(engram)
            _save_state(_state)
            if step_num < len(STEPS):
                print(f"\n  {DIM}Press Enter for next step...{RESET}", end="")
                input()
    finally:
        await engram.close()


async def _reset():
    if DEMO_DB.exists():
        DEMO_DB.unlink()
    if DEMO_STATE.exists():
        DEMO_STATE.unlink()
    print(f"{GREEN}Demo data cleared.{RESET}")


def _start_ui():
    try:
        import subprocess

        app_path = Path(__file__).parent.parent / "demo" / "app.py"
        if not app_path.exists():
            print(f"{RED}Streamlit app not found at {app_path}{RESET}")
            print(f"{DIM}Install: pip install streamlit{RESET}")
            return
        subprocess.run(["streamlit", "run", str(app_path), "--server.port", "8501"], check=True)
    except FileNotFoundError:
        print(f"{RED}Streamlit not installed. Run: pip install streamlit{RESET}")


# ── CLI subparser ──────────────────────────────────────────────────


def _run_demo(args: argparse.Namespace) -> int:
    if args.reset:
        asyncio.run(_reset())
        return 0

    if args.ui:
        _start_ui()
        return 0

    if args.step:
        asyncio.run(_run_step(args.step))
        return 0

    if args.all:
        asyncio.run(_run_all())
        return 0

    # No flag — show the step list
    print(f"\n{BOLD}Memledger Demo — 8-step SRE scenario{RESET}\n")
    for num, (title, _) in STEPS.items():
        print(f"  {BLUE}{num}{RESET}. {title}")
    print(f"\n  Usage: engram demo --step 1")
    print(f"         engram demo --all")
    print(f"         engram demo --reset")
    print(f"         engram demo --ui")
    return 0


def add_subparsers(subparsers: Any) -> None:
    demo = subparsers.add_parser(
        "demo",
        help="Run the scripted 8-step demo for stakeholder presentations",
    )
    demo.add_argument("--step", type=int, help="Run a specific step (1-8)")
    demo.add_argument("--all", action="store_true", help="Run all 8 steps with pauses between")
    demo.add_argument("--reset", action="store_true", help="Clear demo data and start fresh")
    demo.add_argument("--ui", action="store_true", help="Start the Streamlit dashboard")
    demo.set_defaults(_handler=_run_demo)
