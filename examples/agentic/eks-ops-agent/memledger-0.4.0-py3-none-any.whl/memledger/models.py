"""Core data models for Memledger.

Three typed memory records:
  - SemanticRecord: Facts, knowledge, extracted information
  - EpisodicRecord: Events, experiences with temporal context
  - ProceduralRecord: How-to procedures, runbooks, step-by-step instructions
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal, Optional, Union

from pydantic import BaseModel, Field, field_serializer


class RecordType(str, Enum):
    """Discriminator for typed memory records."""

    SEMANTIC = "semantic"
    EPISODIC = "episodic"
    PROCEDURAL = "procedural"


class MemoryStatus(str, Enum):
    """Lifecycle state of a memory record.

    active     → Full scoring, appears in search results
    deprecated → Superseded by newer memory, hidden from default results
    expired    → TTL passed without access renewal, not returned by default
    archived   → Cold storage, batch access only
    """

    ACTIVE = "active"
    DEPRECATED = "deprecated"
    EXPIRED = "expired"
    ARCHIVED = "archived"


class MemoryRecord(BaseModel):
    """Base memory record stored in any backend.

    All typed records (Semantic, Episodic, Procedural) extend this.
    Can also be used directly for untyped storage.
    """

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    content: str
    record_type: RecordType = RecordType.SEMANTIC
    status: MemoryStatus = MemoryStatus.ACTIVE
    embedding: Optional[list[float]] = None
    namespace: str = "/"
    agent_id: Optional[str] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    importance: float = 0.5  # 0.0-1.0, optional write-time hint; usage overrides over time
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    score: Optional[float] = None  # populated on search results

    # Lifecycle fields
    supersedes: Optional[str] = None  # ID of the memory this one replaces
    derived_from: list[str] = Field(default_factory=list)  # IDs of source memories

    # Provenance — who created this memory, in what context, and why
    created_by: Optional[str] = None  # agent/tool that created this memory
    workflow_id: Optional[str] = None  # workflow/pipeline run that produced it
    triggered_by: Optional[str] = None  # input/event that caused creation (e.g. user query, alert)
    # Agents/workflows that consumed this memory. Historically a list of
    # agent-id strings (populated by backends via record_access). The in-process
    # search() path may also append structured access events of the form
    # {"agent_id": str, "timestamp": str, "query": str | None, "outcome": str | None}
    # so the type is `list[Any]` for forward compatibility. Backend persistence
    # of the structured form is pending — see get_attribution().
    accessed_by: list[Any] = Field(default_factory=list)

    # Scoring signals — tracked per record
    access_count: int = 0
    last_accessed_at: Optional[datetime] = None
    success_count: int = 0
    failure_count: int = 0

    @field_serializer("created_at", "updated_at")
    @classmethod
    def _serialize_dt(cls, v: datetime) -> str:
        return v.isoformat()


class SemanticRecord(MemoryRecord):
    """Facts, knowledge, and extracted information.

    Examples:
      - "OOM kills in payment-service caused by connection pool leak"
      - "User prefers Python for data pipelines"
      - "Default max_connections for pgbouncer is 100"
    """

    record_type: Literal[RecordType.SEMANTIC] = RecordType.SEMANTIC
    confidence: Optional[float] = None  # 0.0-1.0, how confident the source was
    source: Optional[str] = None  # where this fact came from


class EpisodicRecord(MemoryRecord):
    """Events and experiences with temporal context.

    Captures what happened, when, and what the outcome was.
    Examples:
      - "On 2026-03-15, SRE agent diagnosed payment-service pod crash"
      - "Deployment of v2.3.1 caused 5min latency spike, rolled back"
    """

    record_type: Literal[RecordType.EPISODIC] = RecordType.EPISODIC
    event_time: Optional[datetime] = None  # when the event occurred
    duration_ms: Optional[int] = None  # how long the event lasted
    outcome: Optional[str] = None  # what was the result
    actors: list[str] = Field(default_factory=list)  # who/what was involved


class ProceduralRecord(MemoryRecord):
    """How-to procedures, runbooks, and step-by-step instructions.

    Captures reusable operational knowledge.
    Examples:
      - "To fix OOM: 1. Check max_connections 2. Set to 50 3. Restart"
      - "Rollback procedure: helm rollback <release> <revision>"
    """

    record_type: Literal[RecordType.PROCEDURAL] = RecordType.PROCEDURAL
    steps: list[str] = Field(default_factory=list)  # ordered steps
    preconditions: list[str] = Field(default_factory=list)  # what must be true first
    tools_required: list[str] = Field(default_factory=list)  # kubectl, helm, etc.


# Union type for deserialization dispatch
TypedRecord = Union[SemanticRecord, EpisodicRecord, ProceduralRecord]


def record_from_dict(data: dict[str, Any]) -> MemoryRecord:
    """Deserialize a dict into the correct typed record based on record_type."""
    record_type = data.get("record_type", RecordType.SEMANTIC)
    if record_type == RecordType.EPISODIC or record_type == "episodic":
        return EpisodicRecord(**data)
    elif record_type == RecordType.PROCEDURAL or record_type == "procedural":
        return ProceduralRecord(**data)
    else:
        return SemanticRecord(**data)


class SearchResult(BaseModel):
    """A search result with score."""

    records: list[MemoryRecord]
    query: str
    backend: str
    search_time_ms: float
    metadata: dict[str, Any] = Field(default_factory=dict)


class MemoryStats(BaseModel):
    """Statistics about stored memories."""

    total_count: int = 0
    namespaces: list[str] = Field(default_factory=list)
    by_record_type: dict[str, int] = Field(default_factory=dict)
    by_namespace: dict[str, int] = Field(default_factory=dict)
    avg_success_rate: Optional[float] = None
    most_accessed: list[str] = Field(default_factory=list)  # top record IDs
    oldest_memory: Optional[datetime] = None
    newest_memory: Optional[datetime] = None


class BackendConfig(BaseModel):
    """Configuration for a single backend."""

    provider: str  # "pgvector", "opensearch"
    config: dict[str, Any] = Field(default_factory=dict)


class EmbeddingConfig(BaseModel):
    """Configuration for the embedding provider."""

    provider: str = "bedrock"
    model: str = "amazon.titan-embed-text-v2:0"
    dimensions: int = 1024
    api_key: Optional[str] = None  # if None, uses env var


class MemledgerConfig(BaseModel):
    """Top-level Memledger configuration."""

    version: str = "1.0"
    embeddings: EmbeddingConfig = Field(default_factory=EmbeddingConfig)
    backends: dict[str, BackendConfig] = Field(default_factory=dict)
    default_backend: str = "pgvector"
    default_namespace: str = "/"

    # Conflict detection: similarity threshold above which a new memory
    # triggers a conflict warning. Tune per embedding model — Titan V2
    # produces lower scores (~0.7) than OpenAI ada-002 (~0.9) for
    # paraphrased content.
    conflict_threshold: float = 0.65

    # Auto-promotion: number of successful outcomes before an episodic
    # memory is promoted to procedural.
    auto_promote_threshold: int = 3

    # Pluggable intelligence strategies (v0.3.1+).
    #
    # Each entry maps a decision kind to a `{provider: str, config: dict}`
    # spec. Omit the entire field for v0.3.0 behavior — engram falls back
    # to deterministic defaults (FixedImportance, AlwaysStore, HookOnly,
    # PolicyRerank) that exactly preserve the prior release's behavior.
    #
    # Example:
    #   strategies:
    #     importance:
    #       provider: llm
    #       config:
    #         model: anthropic/claude-haiku-4-5
    #     write_policy:
    #       provider: always
    #     conflict_resolver:
    #       provider: llm
    #       config:
    #         model: anthropic/claude-haiku-4-5
    #     reranker:
    #       provider: policy
    strategies: Optional[dict[str, Any]] = None

    # Require created_by on all writes. Enable for trust-layer deployments.
    strict_provenance: bool = False
